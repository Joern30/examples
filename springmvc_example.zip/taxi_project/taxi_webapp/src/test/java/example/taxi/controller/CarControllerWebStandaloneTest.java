package example.taxi.controller;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;

import example.taxi.configuration.WebTestConfig;
import example.taxi.domainobject.Car;
import example.taxi.domainobject.Client;
import example.taxi.domainobject.CustomLocalDateSerializer;
import example.taxi.domainobject.CustomLocalDateTimeSerializer;
import example.taxi.domainobject.Driver;
import example.taxi.domainvalue.OnlineStatus;
import example.taxi.persistence.service.CarService;
import example.taxi.test.utility.UnitTestUtil;

/**
 * @author Jörn Scheffler
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { WebTestConfig.class })
public class CarControllerWebStandaloneTest {

  private MockMvc mockMvc;
  @Autowired
  private CarService carService;
  @Autowired
  private TestCarController controller;

  private Car car1;
  private Driver driver1;

  private Car car2;
  private Driver driver2;

  private Car car3;
  private Driver driver3;

  @Before
  public void setUp(){
    MockitoAnnotations.initMocks(this);
    CustomLocalDateSerializer localDateSerializer = new CustomLocalDateSerializer();
    CustomLocalDateTimeSerializer localDateTimeSerializer = new CustomLocalDateTimeSerializer();
    JavaTimeModule module = new JavaTimeModule();
    module.addSerializer(LocalDateTime.class, localDateTimeSerializer);
    module.addSerializer(LocalDate.class, localDateSerializer);
    module.addDeserializer(LocalDate.class, new LocalDateDeserializer(DateTimeFormatter.ofPattern("yyyy/MM/dd")));
    Jackson2ObjectMapperBuilder builder = new Jackson2ObjectMapperBuilder();
    builder.serializationInclusion(JsonInclude.Include.NON_NULL);
    builder.featuresToDisable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS).failOnUnknownProperties(false);
    builder.propertyNamingStrategy(PropertyNamingStrategy.LOWER_CAMEL_CASE);
    builder.serializationInclusion(Include.NON_EMPTY);
    builder.indentOutput(true).serializerByType(LocalDate.class, localDateSerializer);
    builder.serializerByType(LocalDateTime.class, localDateTimeSerializer);
    LocalDateDeserializer deserLocalDate = new LocalDateDeserializer(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
    builder.deserializerByType(LocalDate.class, deserLocalDate).modulesToInstall(module);

    mockMvc = MockMvcBuilders.standaloneSetup(controller).setControllerAdvice(new GlobalControllerExceptionHandler())
        .setMessageConverters(new MappingJackson2HttpMessageConverter(builder.build())).build();
    car1 = Car.newBuilder().setDateCreated(LocalDate.now()).setManufacturingYear(2010).setLicensePlate("HH-HH 1295")
        .setModel("E-Klasse").setSeats(4).setRating(4.3).build();
    driver1 = Driver.newBuilder().setClient(new Client(5l, "manni", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car1).setOnlineStatus(OnlineStatus.FREE).build();

    car2 = Car.newBuilder().setSeats(5).setManufacturingYear(2010).build();
    driver2 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(1.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE).build();
    car2.addDriver(driver2);

    car3 = Car.newBuilder().setSeats(9).setManufacturingYear(2015).build();
    driver3 = Driver.newBuilder().setId(2L).setClient(new Client(1L, "manni", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(2.1).setCar(car3).setOnlineStatus(OnlineStatus.FREE).build();

  }

  @Test
  public void shouldReturnResponseStatusNotOk() throws Exception{
    when(this.carService.create(Matchers.any(Car.class))).thenReturn(car1);

    ResultActions action = mockMvc
        .perform(
            post("/v1/test/addCar").contentType(UnitTestUtil.APPLICATION_JSON_UTF8).content(
                UnitTestUtil.convertObjectWithLocalDatePropertyToJsonBytes(car1))).andExpect(status().isOk())
        .andExpect(content().contentType(UnitTestUtil.APPLICATION_JSON_UTF8))
        .andExpect(jsonPath("$.manufacturingYear", is(2010))).andExpect(jsonPath("$.model", is("E-Klasse")));

    MvcResult result = action.andReturn();

    result.getResponse();

  }

  @Test
  public void shouldReturnResponseStatusOk() throws Exception{
    when(this.carService.create(Matchers.any(Car.class))).thenReturn(car1);

    ResultActions action = mockMvc
        .perform(
            post("/v1/test/addCar").contentType(UnitTestUtil.APPLICATION_JSON_UTF8).content(
                UnitTestUtil.convertObjectWithLocalDatePropertyToJsonBytes(car1))).andExpect(status().isOk())
        .andExpect(content().contentType(UnitTestUtil.APPLICATION_JSON_UTF8))
        .andExpect(jsonPath("$.manufacturingYear", is(2010))).andExpect(jsonPath("$.model", is("E-Klasse")));

    MvcResult result = action.andReturn();

    result.getResponse();

  }

  @Test
  public void givenBidirectionRelation_whenUsingCustomSerializer_thenCorrect() throws JsonProcessingException{

    String result = new ObjectMapper().writeValueAsString(car2);

    assertThat(result, containsString("2010"));
    assertThat(result, containsString("Manfred"));
    assertThat(result, containsString("drivers"));
  }

  @Test
  public void shouldReturnResponseStatusOkWithDriver() throws Exception{
    when(this.carService.create(Matchers.any(Car.class))).thenReturn(car1);

    ResultActions action = mockMvc
        .perform(
            post("/v1/test/addCar").contentType(UnitTestUtil.APPLICATION_JSON_UTF8).content(
                UnitTestUtil.convertObjectWithLocalDatePropertyToJsonBytes(car2))).andExpect(status().isOk())
        .andExpect(content().contentType(UnitTestUtil.APPLICATION_JSON_UTF8))
        .andExpect(jsonPath("$.manufacturingYear", is(2010))).andExpect(jsonPath("$.model", is("E-Klasse")));

    MvcResult result = action.andReturn();

    result.getResponse();

  }
}
