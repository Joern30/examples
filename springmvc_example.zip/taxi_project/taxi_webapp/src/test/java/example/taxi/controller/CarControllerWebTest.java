package example.taxi.controller;

import static info.solidsoft.mockito.java8.AssertionMatcher.assertArg;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import example.taxi.configuration.SpringServletConfig;
import example.taxi.configuration.TestConfig;
import example.taxi.domainobject.Car;
import example.taxi.domainobject.Client;
import example.taxi.domainobject.Driver;
import example.taxi.domainvalue.OnlineStatus;
import example.taxi.persistence.service.CarService;
import example.taxi.test.utility.UnitTestUtil;

/**
 * @author Jörn Scheffler
 */
// @RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { SpringServletConfig.class, TestConfig.class })
@WebAppConfiguration
@Rollback
public class CarControllerWebTest extends AbstractTransactionalJUnit4SpringContextTests {

  private MockMvc mockMvc;
  @Autowired
  private WebApplicationContext webApplicationContext;

  @Mock
  private CarService mockService;

  @Autowired
  private TestCarController testController;

  private Car car1;
  private Driver driver1;

  private Car car2;
  private Driver driver2;

  private Car car3;
  private Driver driver3;

  @Before
  public void setUp(){

    MockitoAnnotations.initMocks(this);
    this.testController.setCarService(mockService);
    mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();

    car1 = Car.newBuilder().setDateCreated(LocalDate.now()).setManufacturingYear(2010).setLicensePlate("HH-HH 1295")
        .setModel("E-Klasse").setSeats(4).setRating(4.3).build();
    driver1 = Driver.newBuilder().setClient(new Client(5l, "manni", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car1).setOnlineStatus(OnlineStatus.FREE).build();

    car2 = Car.newBuilder().setDateCreated(LocalDate.now()).setManufacturingYear(2010).setLicensePlate("HH-HH 1295")
        .setModel("E-Klasse").setSeats(5).setRating(4.3).build();
    driver2 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(1.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE).build();
    car2.addDriver(driver2);

    car3 = Car.newBuilder().setSeats(9).setManufacturingYear(2015).build();
    driver3 = Driver.newBuilder().setId(2L).setClient(new Client(1L, "manni", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(2.1).setCar(car3).setOnlineStatus(OnlineStatus.FREE).build();

  }

  @Test
  public void shouldReturnResponseStatusNotOk() throws Exception{

    mockMvc.perform(
        post("/v1/addCar").header("host", "localhost:80").contentType(UnitTestUtil.APPLICATION_JSON_UTF8)
            .content(UnitTestUtil.convertObjectWithLocalDatePropertyToJsonBytes(null))).andExpect(status().is(500));
  }

  @Test
  public void shouldReturnResponseStatusOk() throws Exception{

    ResultActions action = mockMvc
        .perform(
            post("/v1/addCar").header("host", "localhost:80").contentType(UnitTestUtil.APPLICATION_JSON_UTF8)
                .content(UnitTestUtil.convertObjectWithLocalDatePropertyToJsonBytes(car1))).andExpect(status().isOk())
        .andExpect(content().contentType(UnitTestUtil.APPLICATION_JSON_UTF8))
        .andExpect(jsonPath("$.manufacturingYear", is(2010))).andExpect(jsonPath("$.model", is("E-Klasse")));

    MvcResult result = action.andReturn();

    result.getResponse();

  }

  @Test
  public void shouldReturnResponseStatusOkWithVerification() throws Exception{

    ResultActions action = mockMvc.perform(
        post("/v1/test/addCar").header("host", "localhost:80").contentType(UnitTestUtil.APPLICATION_JSON_UTF8)
            .content(UnitTestUtil.convertObjectWithLocalDatePropertyToJsonBytes(car1))).andExpect(status().isOk());

    MvcResult result = action.andReturn();

    result.getResponse();
    verify(this.mockService, times(1)).create(assertArg(car -> assertThat(car.getModel(), equalTo("E-Klasse"))));

  }

  @Test
  public void shouldReturnResponseStatusOkWithDriverAndWithVerification() throws Exception{

    ResultActions action = mockMvc.perform(
        post("/v1/test/addCar").header("host", "localhost:80").contentType(UnitTestUtil.APPLICATION_JSON_UTF8)
            .content(UnitTestUtil.convertObjectWithLocalDatePropertyToJsonBytes(car2))).andExpect(status().isOk());

    MvcResult result = action.andReturn();

    result.getResponse();
    verify(this.mockService, times(1)).create(assertArg(car -> assertThat(car.getModel(), equalTo("E-Klasse"))));

  }

  @Test
  public void givenBidirectionRelation_whenUsingCustomSerializer_thenCorrect() throws JsonProcessingException{

    String result = new ObjectMapper().writeValueAsString(car2);

    assertThat(result, containsString("2010"));
    assertThat(result, containsString("Manfred"));
    assertThat(result, containsString("drivers"));
  }

  @Test
  public void shouldReturnResponseStatusOkWithDriver() throws Exception{

    ResultActions action = mockMvc
        .perform(
            post("/v1/addCar").header("host", "localhost:80").contentType(UnitTestUtil.APPLICATION_JSON_UTF8)
                .content(UnitTestUtil.convertObjectWithLocalDatePropertyToJsonBytes(car2))).andExpect(status().isOk())
        .andExpect(content().contentType(UnitTestUtil.APPLICATION_JSON_UTF8))
        .andExpect(jsonPath("$.manufacturingYear", is(2010))).andExpect(jsonPath("$.seats", is(5)))
        .andExpect(jsonPath("$.model", is("E-Klasse")));

    MvcResult result = action.andReturn();

    result.getResponse();

  }
}
