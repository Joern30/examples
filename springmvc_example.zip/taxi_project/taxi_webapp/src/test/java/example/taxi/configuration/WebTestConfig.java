package example.taxi.configuration;

import java.util.List;

import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import example.taxi.controller.TestCarController;
import example.taxi.controller.TestTaxiPoiController;
import example.taxi.domainobject.TaxiPoi;
import example.taxi.persistence.dao.HibernateTaxiPoiDAO;
import example.taxi.persistence.dao.TaxiPoiDAO;
import example.taxi.persistence.service.CarService;
import example.taxi.util.CriteriaFactory;

@Configuration
@Import({ UtilConfig.class })
public class WebTestConfig {

  @Autowired
  private CriteriaFactory<List<TaxiPoi>, Integer, String> criteriaFactory;

  @Bean
  public TestTaxiPoiController taxiPoiController(){
    TestTaxiPoiController controller = new TestTaxiPoiController();
    controller.setTaxiPoiDAO(this.taxiPoiDAO());
    controller.setCriteriaFactory(this.criteriaFactory);
    return controller;
  }

  @Bean
  public TestCarController carController(){
    TestCarController controller = new TestCarController();
    controller.setCarService(this.carService());
    return controller;
  }

  /**
   * ################################### DataAccessObject
   * ###################################
   */

  @Bean
  public TaxiPoiDAO taxiPoiDAO(){
    TaxiPoiDAO mockTaxiDao = Mockito.mock(HibernateTaxiPoiDAO.class);
    return mockTaxiDao;
  }

  @Bean
  public CarService carService(){
    CarService carService = Mockito.mock(CarService.class);
    return carService;
  }
}
