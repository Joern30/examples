package example.taxi.util;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.BlockJUnit4ClassRunner;

import example.taxi.domainobject.Car;
import example.taxi.domainobject.Client;
import example.taxi.domainobject.Coordinate;
import example.taxi.domainobject.Driver;
import example.taxi.domainobject.DriverLocation;
import example.taxi.domainobject.TaxiPoi;
import example.taxi.domainvalue.CriteriaStrategyOrder;
import example.taxi.domainvalue.OnlineStatus;

@RunWith(BlockJUnit4ClassRunner.class)
// @Named("TaxiPoiFilterTest")
public class CriteriaFactoryTest {

  final CriteriaFactory<List<TaxiPoi>, Integer, String> criteriaFactory = new CriteriaFactoryImpl();
  // GIVEN
  private final String driverOnlineStatusLimit = "FREE";

  // @Named("Test TaxiPoi CriteriaFactory CriteriaChain")
  @Test
  public void taxiPoi_CriteriaChainWithCriteriaFactory(){
    // GIVEN
    final LinkedList<TaxiPoi> taxiPois = new LinkedList<TaxiPoi>();
    final int manufYear = 2015;
    final int seats = 9;
    final Double driverRating = new Double("2.1");

    final int driverRatingIndex = 1;
    final int carSeatsIndex = 3;
    final int carManufactoringYearIndex = 4;
    final int driverOnlineStatusIndex = 2;

    final String driverRatingLimit = "2";
    final String driverOnlineStatusLimit = "FREE";
    final String carSeatsLimit = "4";
    final String carManufactoringYearLimit = "6";

    final Map<Integer, String> criterias = new HashMap<Integer, String>();
    final SortedMap<Integer, CriteriaStrategy> sortedCriteriastrategies = new TreeMap<Integer, CriteriaStrategy>();

    final Car car1 = Car.newBuilder().setSeats(4).setManufacturingYear(1988).build();
    final Driver driver1 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(4.5).setCar(car1)
        .setOnlineStatus(OnlineStatus.OCCUPIED).build();

    final TaxiPoi taxiPoi1 = new TaxiPoi(driver1, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
    											.setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());
    taxiPois.add(taxiPoi1);

    final Car car2 = Car.newBuilder().setSeats(5).setManufacturingYear(2010).build();
    final Driver driver2 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(1.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi2 = new TaxiPoi(driver2, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
												.setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());
    taxiPois.add(taxiPoi2);

    final Car car3 = Car.newBuilder().setSeats(9).setManufacturingYear(2015).build();
    final Driver driver3 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(2.1).setCar(car3).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi3 = new TaxiPoi(driver3, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
												  .setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());
    taxiPois.add(taxiPoi3);

    // add criterias to map
    criterias.put(driverRatingIndex, driverRatingLimit);
    criterias.put(driverOnlineStatusIndex, driverOnlineStatusLimit);
    criterias.put(carSeatsIndex, carSeatsLimit);
    criterias.put(carManufactoringYearIndex, carManufactoringYearLimit);

    // assure everything is ok outside 0f the CriteriaFactory
    // sort criterias
    final SortedMap<Integer, String> sortedCriterias = new TreeMap<Integer, String>(criterias);

    // Test
    Assert.assertTrue(sortedCriterias.get(CriteriaStrategyOrder.DRIVERONLINESTATUS.getIndex()).equals(
        driverOnlineStatusLimit));
    // sort existing strategies
    for (CriteriaStrategyOrder strategyOrder : CriteriaStrategyOrder.values()) {

      sortedCriteriastrategies.put(strategyOrder.getIndex(), strategyOrder.getCriteriaStrategy());
    }

    Assert.assertTrue(sortedCriteriastrategies.get(CriteriaStrategyOrder.CARSEATS.getIndex()).equals(
        CriteriaStrategyOrder.CARSEATS.getCriteriaStrategy()));

    // CriteriaFactory testing

    CriteriaFactory<List<TaxiPoi>, Integer, String> critFactory = new CriteriaFactoryImpl();
    List<TaxiPoi> taxiPoisfiltered = critFactory.processCriterias(taxiPois, criterias);

    Assert.assertNotNull(taxiPoisfiltered);
    Assert.assertTrue("", taxiPoisfiltered.size() == 1);
    for (TaxiPoi taxiPoi : taxiPoisfiltered) {

      Assert.assertTrue(taxiPoi.getDriver().getCar().getManufacturingYear() == manufYear);
      Assert.assertTrue(taxiPoi.getDriver().getCar().getSeats() == seats);
      Assert.assertTrue(taxiPoi.getDriver().getOnlineStatus().toString().equals(this.driverOnlineStatusLimit));
      Assert.assertTrue(taxiPoi.getDriver().getRating().equals(driverRating));

    }
  }

  // @Named("Test TaxiPoi CriteriaFactory 2CriteriaChain")
  @Test
  public void taxiPoi_2CriteriaChainWithCriteriaFactory(){
    // GIVEN
    final LinkedList<TaxiPoi> taxiPois = new LinkedList<TaxiPoi>();
    final int manufYear = 2015;
    final int seats = 9;
    final Double driverRating = new Double("2.1");

    final Map<Integer, String> criterias = new HashMap<Integer, String>();
    final String driverRatingLimit = "2";

    final String carSeatsLimit = "4";
    final int driverRatingIndex = 1;
    final int carSeatsgIndex = 3;

    final Car car1 = Car.newBuilder().setSeats(4).setManufacturingYear(1988).build();
    final Driver driver1 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(4.5).setCar(car1)
        .setOnlineStatus(OnlineStatus.OCCUPIED).build();

    final TaxiPoi taxiPoi1 = new TaxiPoi(driver1, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
			.setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());
    taxiPois.add(taxiPoi1);

    final Car car2 = Car.newBuilder().setSeats(5).setManufacturingYear(2010).build();
    final Driver driver2 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(1.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi2 = new TaxiPoi(driver2,DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
			.setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());
    taxiPois.add(taxiPoi2);

    final Car car3 = Car.newBuilder().setSeats(9).setManufacturingYear(2015).build();
    final Driver driver3 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(2.1).setCar(car3).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi3 = new TaxiPoi(driver3, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
			.setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());
    taxiPois.add(taxiPoi3);

    // add criterias to map

    criterias.put(driverRatingIndex, driverRatingLimit);
    criterias.put(carSeatsgIndex, carSeatsLimit);

    // CriteriaFactory testing

    CriteriaFactory<List<TaxiPoi>, Integer, String> critFactory = new CriteriaFactoryImpl();
    List<TaxiPoi> taxiPoisfiltered = critFactory.processCriterias(taxiPois, criterias);

    Assert.assertNotNull(taxiPoisfiltered);
    Assert.assertTrue("", taxiPoisfiltered.size() == 1);
    for (TaxiPoi taxiPoi : taxiPoisfiltered) {

      Assert.assertTrue(taxiPoi.getDriver().getCar().getManufacturingYear() == manufYear);
      Assert.assertTrue(taxiPoi.getDriver().getCar().getSeats() == seats);
      Assert.assertTrue(taxiPoi.getDriver().getOnlineStatus().toString().equals(this.driverOnlineStatusLimit));
      Assert.assertTrue(taxiPoi.getDriver().getRating().equals(driverRating));

    }
  }

  // @Named("Test TaxiPoi CriteriaFactory 1CriteriaChain")
  @Test
  public void taxiPoi_1CriteriaChainWithCriteriaFactory(){
    // GIVEN
    final LinkedList<TaxiPoi> taxiPois = new LinkedList<TaxiPoi>();
    final int seats = 4;
    final String carSeatsLimit = "4";
    final int carSeatsIndex = 3;

    final Map<Integer, String> criterias = new HashMap<Integer, String>();

    final Car car1 = Car.newBuilder().setSeats(4).setManufacturingYear(1988).build();
    final Driver driver1 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(4.5).setCar(car1)
        .setOnlineStatus(OnlineStatus.OCCUPIED).build();

    final TaxiPoi taxiPoi1 = new TaxiPoi(driver1, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
			.setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());
    taxiPois.add(taxiPoi1);

    final Car car2 = Car.newBuilder().setSeats(5).setManufacturingYear(2010).build();
    final Driver driver2 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(1.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi2 = new TaxiPoi(driver2, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
			.setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());
    taxiPois.add(taxiPoi2);

    final Car car3 = Car.newBuilder().setSeats(9).setManufacturingYear(2015).build();
    final Driver driver3 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(2.1).setCar(car3).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi3 = new TaxiPoi(driver3, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
			.setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());
    taxiPois.add(taxiPoi3);

    // add criterias to map

    criterias.put(carSeatsIndex, carSeatsLimit);

    // CriteriaFactory testing

    CriteriaFactory<List<TaxiPoi>, Integer, String> critFactory = new CriteriaFactoryImpl();
    List<TaxiPoi> taxiPoisfiltered = critFactory.processCriterias(taxiPois, criterias);

    Assert.assertNotNull(taxiPoisfiltered);
    Assert.assertTrue("", taxiPoisfiltered.size() == 2);
    for (TaxiPoi taxiPoi : taxiPoisfiltered) {

      Assert.assertTrue(taxiPoi.getDriver().getCar().getSeats() > seats);

    }
  }

  // @Named("Test TaxiPoi CriteriaChain And Empty List")
  @Test
  public void taxiPoi_CriteriaChainWithCriteriaFactoryAndEmptyList(){
    // GIVEN
    final LinkedList<TaxiPoi> taxiPois = new LinkedList<TaxiPoi>();

    final Map<Integer, String> criterias = new HashMap<Integer, String>();

    // add criterias to map
    final String driverRatingLimit = "2";
    final String driverOnlineStatusLimit = "FREE";

    final String carSeatsLimit = "4";
    final String carManufactorinfYearLimit = "6";

    criterias.put(1, driverRatingLimit);
    criterias.put(2, driverOnlineStatusLimit);
    criterias.put(3, carSeatsLimit);
    criterias.put(4, carManufactorinfYearLimit);

    // CriteriaFactory testing

    CriteriaFactory<List<TaxiPoi>, Integer, String> critFactory = new CriteriaFactoryImpl();
    List<TaxiPoi> taxiPoisfiltered = critFactory.processCriterias(taxiPois, criterias);

    Assert.assertNotNull(taxiPoisfiltered);
    Assert.assertTrue("", taxiPoisfiltered.size() == 0);
  }

  // @Named("Test TaxiPoi CriteriaFactory CriteriaChain")
  @Test
  public void taxiPoi_CriteriaChainWithCriteriaFactoryMultiThreading(){
    // GIVEN
    final LinkedList<TaxiPoi> taxiPois = new LinkedList<TaxiPoi>();

    final int driverRatingIndex = 1;
    final int carSeatsIndex = 3;
    final int carManufactoringYearIndex = 4;
    final int driverOnlineStatusIndex = 2;

    final String driverRatingLimit = "2";
    final String driverOnlineStatusLimit = "FREE";
    final String carSeatsLimit = "4";
    final String carManufactoringYearLimit = "6";

    final Car car1 = Car.newBuilder().setSeats(4).setManufacturingYear(1988).build();
    final Driver driver1 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(4.5).setCar(car1)
        .setOnlineStatus(OnlineStatus.OCCUPIED).build();

    final TaxiPoi taxiPoi1 = new TaxiPoi(driver1, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
			.setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());
    taxiPois.add(taxiPoi1);

    final Car car2 = Car.newBuilder().setSeats(5).setManufacturingYear(2010).build();
    final Driver driver2 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(1.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi2 = new TaxiPoi(driver2, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
			.setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());
    taxiPois.add(taxiPoi2);

    final Car car3 = Car.newBuilder().setSeats(9).setManufacturingYear(2015).build();
    final Driver driver3 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(2.1).setCar(car3).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi3 = new TaxiPoi(driver3, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
			.setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());
    taxiPois.add(taxiPoi3);

    // CriteriaFactory testing simulating TaxiPoiConroller concurrency

    new Thread(new Runnable() {
      @Override
      public void run(){
        List<TaxiPoi> taxiPoisfiltered = null;
        System.out.println("Thread 1: started");

        taxiPoisfiltered = this.getTaxisWithinRadiusAndAttributes();
        Assert.assertNotNull(taxiPoisfiltered);
        Assert.assertTrue("", taxiPoisfiltered.size() == 1);

        System.out.println("Thread 1: done");
      }

      public List<TaxiPoi> getTaxisWithinRadiusAndAttributes(){
        List<TaxiPoi> taxiPoisfiltered = null;
        final Map<Integer, String> criterias = new HashMap<Integer, String>();
        criterias.put(driverRatingIndex, driverRatingLimit);
        criterias.put(driverOnlineStatusIndex, driverOnlineStatusLimit);
        criterias.put(carSeatsIndex, carSeatsLimit);
        criterias.put(carManufactoringYearIndex, carManufactoringYearLimit);
        taxiPoisfiltered = criteriaFactory.processCriterias(taxiPois, criterias);
        return taxiPoisfiltered;
      }
    }).start();

    new Thread(new Runnable() {
      @Override
      public void run(){
        List<TaxiPoi> taxiPoisfiltered = null;
        System.out.println("Thread 1: started");
        taxiPoisfiltered = this.getTaxisWithinRadiusAndAttributes();
        Assert.assertNotNull(taxiPoisfiltered);
        Assert.assertTrue("", taxiPoisfiltered.size() == 2);
        System.out.println("Thread 2: done");
      }

      public List<TaxiPoi> getTaxisWithinRadiusAndAttributes(){
        List<TaxiPoi> taxiPoisfiltered = null;
        final Map<Integer, String> criterias = new HashMap<Integer, String>();
        criterias.put(carSeatsIndex, carSeatsLimit);
        taxiPoisfiltered = criteriaFactory.processCriterias(taxiPois, criterias);
        return taxiPoisfiltered;
      }
    }).start();

    new Thread(new Runnable() {
      @Override
      public void run(){
        List<TaxiPoi> taxiPoisfiltered = null;
        System.out.println("Thread 3: started");
        taxiPoisfiltered = this.getTaxisWithinRadiusAndAttributes();
        Assert.assertNotNull(taxiPoisfiltered);
        Assert.assertTrue("", taxiPoisfiltered.size() == 2);
        System.out.println("Thread 3: done");
      }

      public List<TaxiPoi> getTaxisWithinRadiusAndAttributes(){
        List<TaxiPoi> taxiPoisfiltered = null;
        final Map<Integer, String> criterias = new HashMap<Integer, String>();
        criterias.put(carSeatsIndex, carSeatsLimit);
        taxiPoisfiltered = criteriaFactory.processCriterias(taxiPois, criterias);
        return taxiPoisfiltered;
      }
    }).start();

    new Thread(new Runnable() {
      @Override
      public void run(){
        List<TaxiPoi> taxiPoisfiltered = null;
        System.out.println("Thread 4: started");

        taxiPoisfiltered = this.getTaxisWithinRadiusAndAttributes();
        Assert.assertNotNull(taxiPoisfiltered);
        Assert.assertTrue("", taxiPoisfiltered.size() == 1);

        System.out.println("Thread 4: done");
      }

      public List<TaxiPoi> getTaxisWithinRadiusAndAttributes(){
        List<TaxiPoi> taxiPoisfiltered = null;
        final Map<Integer, String> criterias = new HashMap<Integer, String>();
        criterias.put(driverRatingIndex, driverRatingLimit);
        criterias.put(driverOnlineStatusIndex, driverOnlineStatusLimit);
        criterias.put(carSeatsIndex, carSeatsLimit);
        criterias.put(carManufactoringYearIndex, carManufactoringYearLimit);
        taxiPoisfiltered = criteriaFactory.processCriterias(taxiPois, criterias);
        return taxiPoisfiltered;
      }
    }).start();

  }
}
