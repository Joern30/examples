package example.taxi.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;
import java.util.LinkedList;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import example.taxi.configuration.SpringServletConfig;
import example.taxi.configuration.TestConfig;
import example.taxi.configuration.UtilConfig;
import example.taxi.domainobject.Car;
import example.taxi.domainobject.Client;
import example.taxi.domainobject.Coordinate;
import example.taxi.domainobject.Driver;
import example.taxi.domainobject.DriverLocation;
import example.taxi.domainobject.TaxiPoi;
import example.taxi.domainvalue.OnlineStatus;
import example.taxi.persistence.dao.TaxiPoiDAO;

/**
 * @author Jörn Scheffler
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { SpringServletConfig.class, TestConfig.class, UtilConfig.class })
@WebAppConfiguration
public class TaxiControllerWebTest {

  @Autowired
  private WebApplicationContext webApplicationContext;

  @Autowired
  private TaxiPoiDAO taxiPoiDAO;

  private MockMvc mockMvc;

  @Before
  public void setUp(){
    Mockito.reset(taxiPoiDAO);
    mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();

  }

  // @Ignore
  @Test
  public void shouldReturnResponseStatusNotOk() throws Exception{
    // GIVEN
    final LinkedList<TaxiPoi> taxiPois = new LinkedList<TaxiPoi>();

    final Car car1 = Car.newBuilder().setSeats(4).setManufacturingYear(1988).build();
    final Driver driver1 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(4.5).setCar(car1)
        .setOnlineStatus(OnlineStatus.OCCUPIED).build();

    final TaxiPoi taxiPoi1 = new TaxiPoi(driver1, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now()).setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d)
    		.setSpeed(67d).build());
    taxiPois.add(taxiPoi1);

    final Car car2 = Car.newBuilder().setSeats(5).setManufacturingYear(2010).build();
    final Driver driver2 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(1.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi2 = new TaxiPoi(driver2, DriverLocation.newBuilder().setId(driver2.getDriverId()).setDateCreated(LocalDate.now()).setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d)
    		.setSpeed(67d).build());

    taxiPois.add(taxiPoi2);

    final Car car3 = Car.newBuilder().setSeats(9).setManufacturingYear(2015).build();
    final Driver driver3 = Driver.newBuilder().setId(2L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(2.1).setCar(car3).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi3 = new TaxiPoi(driver3, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now()).setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d)
    		.setSpeed(67d).build());
    
    taxiPois.add(taxiPoi3);

    Mockito.stub(this.taxiPoiDAO.findDriversWithin(Matchers.any(Coordinate.class), Matchers.anyDouble())).toReturn(
        taxiPois);

    this.mockMvc.perform(
        get("/test").header("host", "localhost:80").param("p1Lat", "0").param("p1Lon", "0")
            .param("radiusInMeter", "20000")).andExpect(status().is(404));
    this.mockMvc.perform(
        get("/v1/test/taxiCriteriasInRadiusWithHandler").header("host", "localhost:80").param("p1Lat", "0")
            .param("p1Lon", "0").param("radiusInMeter", "20000")).andExpect(status().is(400));

  }

  @Test
  public void shouldReturnResponseStatusOkWithOneArgument() throws Exception{
    final LinkedList<TaxiPoi> taxiPois = new LinkedList<TaxiPoi>();

    final Car car1 = Car.newBuilder().setSeats(4).setManufacturingYear(1988).build();
    final Driver driver1 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(4.5).setCar(car1)
        .setOnlineStatus(OnlineStatus.OCCUPIED).build();

    final TaxiPoi taxiPoi1 = new TaxiPoi(driver1, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now()).setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d)
    		.setSpeed(67d).build());
    taxiPois.add(taxiPoi1);

    final Car car2 = Car.newBuilder().setSeats(5).setManufacturingYear(2010).build();
    final Driver driver2 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(1.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi2 = new TaxiPoi(driver2, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now()).setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d)
    		.setSpeed(67d).build());
    taxiPois.add(taxiPoi2);

    final Car car3 = Car.newBuilder().setSeats(9).setManufacturingYear(2015).build();
    final Driver driver3 = Driver.newBuilder().setId(2L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(2.1).setCar(car3).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi3 = new TaxiPoi(driver3, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now()).setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d)
    		.setSpeed(67d).build());
    taxiPois.add(taxiPoi3);

    Mockito.stub(this.taxiPoiDAO.findDriversWithin(Matchers.any(Coordinate.class), Matchers.anyDouble())).toReturn(
        taxiPois);


    this.mockMvc
        .perform(
            get("/v1/test/taxiCriteriasInRadiusWithHandler").header("host", "localhost:80").param("p1Lat", "0")
                .param("p1Lon", "0").param("radiusInMeter", "20000").param("carSeats", "4")).andExpect(status().isOk())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8));

  }
  @Test
  public void shouldReturnResponseStatusOkWithOneArgument1() throws Exception{
    final LinkedList<TaxiPoi> taxiPois = new LinkedList<TaxiPoi>();

    final Car car1 = Car.newBuilder().setSeats(4).setManufacturingYear(1988).build();
    final Driver driver1 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(4.5).setCar(car1)
        .setOnlineStatus(OnlineStatus.OCCUPIED).build();

    final TaxiPoi taxiPoi1 = new TaxiPoi(driver1, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now()).setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d)
    		.setSpeed(67d).build());
    taxiPois.add(taxiPoi1);

    final Car car2 = Car.newBuilder().setSeats(5).setManufacturingYear(2010).build();
    final Driver driver2 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(1.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi2 = new TaxiPoi(driver2, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now()).setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d)
    		.setSpeed(67d).build());
    taxiPois.add(taxiPoi2);

    final Car car3 = Car.newBuilder().setSeats(9).setManufacturingYear(2015).build();
    final Driver driver3 = Driver.newBuilder().setId(2L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(2.1).setCar(car3).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi3 = new TaxiPoi(driver3, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now()).setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d)
    		.setSpeed(67d).build());
    taxiPois.add(taxiPoi3);

    Mockito.stub(this.taxiPoiDAO.findDriversWithin(Matchers.any(Coordinate.class), Matchers.anyDouble())).toReturn(
        taxiPois);


    this.mockMvc
        .perform(
            get("/v1/taxiCriteriasInRadiusWithHandler").header("host", "localhost:80").param("p1Lat", "0")
                .param("p1Lon", "0").param("radiusInMeter", "20000").param("carSeats", "4")).andExpect(status().isOk())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8));

  }

}
