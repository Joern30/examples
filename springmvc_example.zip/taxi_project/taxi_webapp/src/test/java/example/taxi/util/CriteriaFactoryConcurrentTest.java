package example.taxi.util;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.junit.Assert;

import example.taxi.domainobject.Car;
import example.taxi.domainobject.Client;
import example.taxi.domainobject.Coordinate;
import example.taxi.domainobject.Driver;
import example.taxi.domainobject.DriverLocation;
import example.taxi.domainobject.TaxiPoi;
import example.taxi.domainvalue.OnlineStatus;

public class CriteriaFactoryConcurrentTest {

  public static void main(String[] args){
    taxiPoi_CriteriaChainWithCriteriaFactoryMultiThreading();

  }

  final static CriteriaFactory<List<TaxiPoi>, Integer, String> criteriaFactory = new CriteriaFactoryImpl();

  public static void taxiPoi_CriteriaChainWithCriteriaFactoryMultiThreading(){
    // GIVEN
    final LinkedList<TaxiPoi> taxiPois = new LinkedList<TaxiPoi>();

    final int driverRatingIndex = 1;
    final int carSeatsIndex = 3;
    final int carManufactoringYearIndex = 4;
    final int driverOnlineStatusIndex = 2;

    final String driverRatingLimit = "2";
    final String driverOnlineStatusLimit = "FREE";
    final String carSeatsLimit = "4";
    final String carManufactoringYearLimit = "6";

    final Car car1 = Car.newBuilder().setSeats(4).setManufacturingYear(1988).build();
    final Driver driver1 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(4.5).setCar(car1)
        .setOnlineStatus(OnlineStatus.OCCUPIED).build();

    final TaxiPoi taxiPoi1 = new TaxiPoi(driver1, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
			.setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());
    taxiPois.add(taxiPoi1);

    final Car car2 = Car.newBuilder().setSeats(5).setManufacturingYear(2010).build();
    final Driver driver2 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(1.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi2 = new TaxiPoi(driver2, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
			.setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());
    taxiPois.add(taxiPoi2);

    final Car car3 = Car.newBuilder().setSeats(9).setManufacturingYear(2015).build();
    final Driver driver3 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(2.1).setCar(car3).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi3 = new TaxiPoi(driver3, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
			.setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());
    taxiPois.add(taxiPoi3);

    // CriteriaFactory testing simulating TaxiPoiConroller concurrency

    new Thread(new Runnable() {
      @Override
      public void run(){
        List<TaxiPoi> taxiPoisfiltered = null;
        System.out.println("Thread 1: started");
        try {
          Thread.sleep(1010);
        } catch (InterruptedException e) {
          // TODO Auto-generated catch block
          e.printStackTrace();
        }
        taxiPoisfiltered = this.getTaxisWithinRadiusAndAttributes();
        Assert.assertNotNull(taxiPoisfiltered);
        Assert.assertTrue("", taxiPoisfiltered.size() == 1);

        System.out.println("Thread 1: done");
      }

      public List<TaxiPoi> getTaxisWithinRadiusAndAttributes(){
        List<TaxiPoi> taxiPoisfiltered = null;
        final Map<Integer, String> criterias = new HashMap<Integer, String>();
        criterias.put(driverRatingIndex, driverRatingLimit);
        criterias.put(driverOnlineStatusIndex, driverOnlineStatusLimit);
        criterias.put(carSeatsIndex, carSeatsLimit);
        criterias.put(carManufactoringYearIndex, carManufactoringYearLimit);
        taxiPoisfiltered = criteriaFactory.processCriterias(taxiPois, criterias);
        return taxiPoisfiltered;
      }
    }).start();

    new Thread(new Runnable() {
      @Override
      public void run(){
        List<TaxiPoi> taxiPoisfiltered = null;
        System.out.println("Thread 2: started");
        try {
          Thread.sleep(10);
        } catch (InterruptedException e) {
          // TODO Auto-generated catch block
          e.printStackTrace();
        }
        taxiPoisfiltered = this.getTaxisWithinRadiusAndAttributes();
        System.out.println("taxiPoisfiltered: " + taxiPoisfiltered);
        Assert.assertNotNull(taxiPoisfiltered);
        Assert.assertTrue("", taxiPoisfiltered.size() == 2);
        System.out.println("Thread 2: done");
      }

      public List<TaxiPoi> getTaxisWithinRadiusAndAttributes(){
        List<TaxiPoi> taxiPoisfiltered = null;
        final Map<Integer, String> criterias = new HashMap<Integer, String>();
        criterias.put(carSeatsIndex, carSeatsLimit);
        taxiPoisfiltered = criteriaFactory.processCriterias(taxiPois, criterias);
        return taxiPoisfiltered;
      }
    }).start();

    new Thread(new Runnable() {
      @Override
      public void run(){
        List<TaxiPoi> taxiPoisfiltered = null;
        System.out.println("Thread 3: started");
        try {
          Thread.sleep(301);
        } catch (InterruptedException e) {
          // TODO Auto-generated catch block
          e.printStackTrace();
        }
        taxiPoisfiltered = this.getTaxisWithinRadiusAndAttributes();
        System.out.println("taxiPoisfiltered: " + taxiPoisfiltered);
        Assert.assertNotNull(taxiPoisfiltered);
        Assert.assertTrue("", taxiPoisfiltered.size() == 2);
        System.out.println("Thread 3: done");
      }

      public List<TaxiPoi> getTaxisWithinRadiusAndAttributes(){
        List<TaxiPoi> taxiPoisfiltered = null;
        final Map<Integer, String> criterias = new HashMap<Integer, String>();
        criterias.put(carSeatsIndex, carSeatsLimit);
        taxiPoisfiltered = criteriaFactory.processCriterias(taxiPois, criterias);
        return taxiPoisfiltered;
      }
    }).start();
    new Thread(new Runnable() {
      @Override
      public void run(){
        List<TaxiPoi> taxiPoisfiltered = null;
        System.out.println("Thread 4: started");

        taxiPoisfiltered = this.getTaxisWithinRadiusAndAttributes();
        Assert.assertNotNull(taxiPoisfiltered);
        Assert.assertTrue("", taxiPoisfiltered.size() == 1);

        System.out.println("Thread 4: done");
      }

      public List<TaxiPoi> getTaxisWithinRadiusAndAttributes(){
        List<TaxiPoi> taxiPoisfiltered = null;
        final Map<Integer, String> criterias = new HashMap<Integer, String>();
        criterias.put(driverRatingIndex, driverRatingLimit);
        criterias.put(driverOnlineStatusIndex, driverOnlineStatusLimit);
        criterias.put(carSeatsIndex, carSeatsLimit);
        criterias.put(carManufactoringYearIndex, carManufactoringYearLimit);
        taxiPoisfiltered = criteriaFactory.processCriterias(taxiPois, criterias);
        return taxiPoisfiltered;
      }
    }).start();

  }

}
