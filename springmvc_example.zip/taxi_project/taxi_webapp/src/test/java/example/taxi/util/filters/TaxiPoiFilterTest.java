package example.taxi.util.filters;

import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.BlockJUnit4ClassRunner;
import org.mockito.Mockito;

import example.taxi.domainobject.Car;
import example.taxi.domainobject.Client;
import example.taxi.domainobject.Coordinate;
import example.taxi.domainobject.Driver;
import example.taxi.domainobject.DriverLocation;
import example.taxi.domainobject.TaxiPoi;
import example.taxi.domainvalue.OnlineStatus;

@RunWith(BlockJUnit4ClassRunner.class)
// @Named("TaxiPoiFilterTest")
public class TaxiPoiFilterTest {

  private final Double driverRatingLimit = new Double(2.0);
  private final String driverOnlineStatusLimit = "FREE";
  private final int carSeatsLimit = 4;
  private final int carManufactoringYearLimit = 6;

  // different interface variables for readibility reasons
  private TaxiCriteria<TaxiPoi> driverRatingFilter;
  private TaxiCriteria<TaxiPoi> driverOnlineStatusFilter;
  private TaxiCriteria<TaxiPoi> carSeatsFilter;
  private TaxiCriteria<TaxiPoi> carManufactoringYearFilter;

  @Before
  public void setUp(){
    this.driverRatingFilter = new DriverRatingFilter(this.driverRatingLimit);
    this.driverOnlineStatusFilter = new DriverOnlineStatusFilter(this.driverOnlineStatusLimit);
    this.carSeatsFilter = new CarSeatsFilter(this.carSeatsLimit);
    this.carManufactoringYearFilter = new CarManufactoredFilter(this.carManufactoringYearLimit);
  }

  // @Named("Test TaxiPoi DriverRatingCriteria")
  @Test
  public void taxiPoi_withDriverRatingCriteria(){
    // GIVEN
    final LinkedList<TaxiPoi> taxiPois = new LinkedList<TaxiPoi>();

    final Car car1 = Mockito.mock(Car.class);
    final Driver driver1 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(4.5).setCar(car1)
        .setOnlineStatus(OnlineStatus.OCCUPIED).build();

    final TaxiPoi taxiPoi1 = new TaxiPoi(driver1, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
			.setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());
    taxiPois.add(taxiPoi1);

    final Car car2 = Mockito.mock(Car.class);
    final Driver driver2 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(1.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi2 = new TaxiPoi(driver2, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
			.setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());
    taxiPois.add(taxiPoi2);

    final Car car3 = Mockito.mock(Car.class);
    final Driver driver3 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(2.1).setCar(car3).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi3 = new TaxiPoi(driver3, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
			.setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());
    taxiPois.add(taxiPoi3);

    final List<TaxiPoi> taxiPoisfiltered = this.driverRatingFilter.meetCriteria(taxiPois);
    Assert.assertNotNull(taxiPoisfiltered);
    Assert.assertTrue("", taxiPoisfiltered.size() == 2);
    for (TaxiPoi taxiPoi : taxiPoisfiltered) {

      Assert.assertTrue(taxiPoi.getDriver().getRating().compareTo(this.driverRatingLimit) > 0);

    }
  }

  // @Named("Test TaxiPoi DriverOnlineStatusCriteria")
  @Test
  public void taxiPoi_withDriverOnlineStatusCriteria(){
    // GIVEN
    final LinkedList<TaxiPoi> taxiPois = new LinkedList<TaxiPoi>();

    final Car car1 = Mockito.mock(Car.class);
    final Driver driver1 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(4.5).setCar(car1)
        .setOnlineStatus(OnlineStatus.OCCUPIED).build();

    final TaxiPoi taxiPoi1 = new TaxiPoi(driver1, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
			.setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());
    taxiPois.add(taxiPoi1);

    final Car car2 = Mockito.mock(Car.class);
    final Driver driver2 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(1.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi2 = new TaxiPoi(driver2, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
			.setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());
    taxiPois.add(taxiPoi2);

    final Car car3 = Mockito.mock(Car.class);
    final Driver driver3 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(2.1).setCar(car3).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi3 = new TaxiPoi(driver3, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
			.setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());
    taxiPois.add(taxiPoi3);

    final List<TaxiPoi> taxiPoisfiltered = this.driverOnlineStatusFilter.meetCriteria(taxiPois);
    Assert.assertNotNull(taxiPoisfiltered);
    Assert.assertTrue("", taxiPoisfiltered.size() == 2);
    for (TaxiPoi taxiPoi : taxiPoisfiltered) {

      Assert.assertTrue(taxiPoi.getDriver().getOnlineStatus()
          .compareTo(OnlineStatus.valueOf(this.driverOnlineStatusLimit)) == 0);

    }

  }

  // @Named("Test TaxiPoi DriverOnlineStatusDefaultCriteria")
  @Test
  public void taxiPoi_withDriverOnlineStatusDefaultCriteria(){
    // GIVEN
    final LinkedList<TaxiPoi> taxiPois = new LinkedList<TaxiPoi>();
    this.driverOnlineStatusFilter = new DriverOnlineStatusFilter();

    final Car car1 = Mockito.mock(Car.class);
    final Driver driver1 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(4.5).setCar(car1)
        .setOnlineStatus(OnlineStatus.OCCUPIED).build();

    final TaxiPoi taxiPoi1 = new TaxiPoi(driver1, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
			.setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());
    taxiPois.add(taxiPoi1);

    final Car car2 = Mockito.mock(Car.class);
    final Driver driver2 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(1.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi2 = new TaxiPoi(driver2, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
			.setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());
    taxiPois.add(taxiPoi2);

    final Car car3 = Mockito.mock(Car.class);
    final Driver driver3 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(2.1).setCar(car3).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi3 = new TaxiPoi(driver3, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
			.setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());
    taxiPois.add(taxiPoi3);

    final List<TaxiPoi> taxiPoisfiltered = this.driverOnlineStatusFilter.meetCriteria(taxiPois);
    Assert.assertNotNull(taxiPoisfiltered);
    Assert.assertTrue("", taxiPoisfiltered.size() == 2);

    for (TaxiPoi taxiPoi : taxiPoisfiltered) {

      Assert.assertTrue(taxiPoi.getDriver().getOnlineStatus()
          .compareTo(OnlineStatus.valueOf(this.driverOnlineStatusLimit)) == 0);

    }

  }

  // @Named("Test TaxiPoi DriverOnlineStatusFaultCriteria")
  @Test
  public void taxiPoi_withDriverOnlineStatusFaultCriteria(){
    // GIVEN
    final LinkedList<TaxiPoi> taxiPois = new LinkedList<TaxiPoi>();
    this.driverOnlineStatusFilter = new DriverOnlineStatusFilter("");

    final Car car1 = Mockito.mock(Car.class);
    final Driver driver1 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(4.5).setCar(car1)
        .setOnlineStatus(OnlineStatus.OCCUPIED).build();

    final TaxiPoi taxiPoi1 = new TaxiPoi(driver1, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
			.setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());
    taxiPois.add(taxiPoi1);

    final Car car2 = Mockito.mock(Car.class);
    final Driver driver2 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(1.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi2 = new TaxiPoi(driver2, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
			.setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());
    taxiPois.add(taxiPoi2);

    final Car car3 = Mockito.mock(Car.class);
    final Driver driver3 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(2.1).setCar(car3).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi3 = new TaxiPoi(driver3, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
			.setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());;
    taxiPois.add(taxiPoi3);

    final List<TaxiPoi> taxiPoisfiltered = this.driverOnlineStatusFilter.meetCriteria(taxiPois);
    Assert.assertNotNull(taxiPoisfiltered);
    Assert.assertTrue("", taxiPoisfiltered.size() == 0);
  }

  // @Named("Test TaxiPoi CarSeatsCriteria")
  @Test
  public void taxiPoi_withCarSeatsCriteria(){
    // GIVEN
    final LinkedList<TaxiPoi> taxiPois = new LinkedList<TaxiPoi>();

    final Car car1 = Car.newBuilder().setSeats(4).setManufacturingYear(1988).build();
    final Driver driver1 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(4.5).setCar(car1)
        .setOnlineStatus(OnlineStatus.OCCUPIED).build();

    final TaxiPoi taxiPoi1 = new TaxiPoi(driver1, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
			.setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());
    taxiPois.add(taxiPoi1);

    final Car car2 = Car.newBuilder().setSeats(5).setManufacturingYear(2010).build();
    final Driver driver2 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(1.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi2 = new TaxiPoi(driver2, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
			.setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());
    taxiPois.add(taxiPoi2);

    final Car car3 = Car.newBuilder().setSeats(9).setManufacturingYear(2015).build();
    final Driver driver3 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(2.1).setCar(car3).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi3 = new TaxiPoi(driver3, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
			.setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());
    taxiPois.add(taxiPoi3);

    final List<TaxiPoi> taxiPoisfiltered = this.carSeatsFilter.meetCriteria(taxiPois);
    Assert.assertNotNull(taxiPoisfiltered);
    Assert.assertTrue("", taxiPoisfiltered.size() == 2);
    for (TaxiPoi taxiPoi : taxiPoisfiltered) {

      Assert.assertTrue(taxiPoi.getDriver().getCar().getSeats() > this.carSeatsLimit);

    }

  }

  // @Named("Test TaxiPoi CarManufactoringYearCriteria")
  @Test
  public void taxiPoi_withCarManufactoringYearCriteria(){
    // GIVEN
	
	Integer car2Year = 2010;
	Integer car3Year = 2016;
	Integer now= LocalDate.now().getYear();
    final LinkedList<TaxiPoi> taxiPois = new LinkedList<TaxiPoi>();

    if(now.intValue() - car2Year.intValue() > this.carManufactoringYearLimit ) {
    	car2Year = now;
    }
    if(now.intValue() - car3Year.intValue() > this.carManufactoringYearLimit ) {
    	car3Year = now;
    }

    final Car car1 = Car.newBuilder().setSeats(4).setManufacturingYear(1988).build();
    final Driver driver1 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(4.5).setCar(car1)
        .setOnlineStatus(OnlineStatus.OCCUPIED).build();

    final TaxiPoi taxiPoi1 = new TaxiPoi(driver1, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
			.setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());;
    taxiPois.add(taxiPoi1);

    final Car car2 = Car.newBuilder().setSeats(5).setManufacturingYear(car2Year).build();
    final Driver driver2 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(1.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi2 = new TaxiPoi(driver2, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
			.setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());
    taxiPois.add(taxiPoi2);

    final Car car3 = Car.newBuilder().setSeats(9).setManufacturingYear(car3Year).build();
    final Driver driver3 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(2.1).setCar(car3).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi3 = new TaxiPoi(driver3, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
			.setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());
    taxiPois.add(taxiPoi3);

    final List<TaxiPoi> taxiPoisfiltered = this.carManufactoringYearFilter.meetCriteria(taxiPois);
    Assert.assertNotNull(taxiPoisfiltered);
    Assert.assertTrue("", taxiPoisfiltered.size() == 2);
    for (TaxiPoi taxiPoi : taxiPoisfiltered) {

      Assert.assertTrue(taxiPoi.getDriver().getCar().getManufacturingYear() > this.carManufactoringYearLimit);

    }

  }

  // filters in following order:
  // 1. driver rating
  // 2. driver online status free
  // 3. car manufactoring year
  // 4. car seats amount
  // @Named("Test TaxiPoi FullCriteriaChain")
  @Test
  public void taxiPoi_withFullCriteriaChain(){
    // GIVEN
    final LinkedList<TaxiPoi> taxiPois = new LinkedList<TaxiPoi>();

    final int manufYear = 2015;
    final int seats = 9;
    final Double driverRating = new Double("2.1");

    final Car car1 = Car.newBuilder().setSeats(4).setManufacturingYear(1988).build();
    final Driver driver1 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(4.5).setCar(car1)
        .setOnlineStatus(OnlineStatus.OCCUPIED).build();

    final TaxiPoi taxiPoi1 = new TaxiPoi(driver1, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
			.setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());
    taxiPois.add(taxiPoi1);

    final Car car2 = Car.newBuilder().setSeats(5).setManufacturingYear(2010).build();
    final Driver driver2 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(1.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi2 = new TaxiPoi(driver2, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
			.setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());
    taxiPois.add(taxiPoi2);

    final Car car3 = Car.newBuilder().setSeats(9).setManufacturingYear(2015).build();
    final Driver driver3 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(2.1).setCar(car3).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi3 = new TaxiPoi(driver3, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now())
			.setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d).setSpeed(67d).build());
    taxiPois.add(taxiPoi3);

    List<TaxiPoi> taxiPoisfiltered = this.driverRatingFilter.meetCriteria(taxiPois);
    // filter chain
    taxiPoisfiltered = this.driverOnlineStatusFilter.meetCriteria(taxiPoisfiltered);
    taxiPoisfiltered = this.carManufactoringYearFilter.meetCriteria(taxiPoisfiltered);
    taxiPoisfiltered = this.carSeatsFilter.meetCriteria(taxiPoisfiltered);

    Assert.assertNotNull(taxiPoisfiltered);
    Assert.assertTrue("", taxiPoisfiltered.size() == 1);
    for (TaxiPoi taxiPoi : taxiPoisfiltered) {

      Assert.assertTrue(taxiPoi.getDriver().getCar().getManufacturingYear() == manufYear);
      Assert.assertTrue(taxiPoi.getDriver().getCar().getSeats() == seats);
      Assert.assertTrue(taxiPoi.getDriver().getOnlineStatus().toString().equals(this.driverOnlineStatusLimit));
      Assert.assertTrue(taxiPoi.getDriver().getRating().equals(driverRating));

    }

  }
}
