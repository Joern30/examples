package example.taxi.persistence.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;

import example.taxi.configuration.DatabaseConfiguration;
import example.taxi.domainobject.Car;
import example.taxi.domainobject.Client;
import example.taxi.domainobject.Coordinate;
import example.taxi.domainobject.Driver;
import example.taxi.domainobject.DriverLocation;
import example.taxi.domainvalue.OnlineStatus;

@ContextConfiguration(classes = { DatabaseConfiguration.class })
@Rollback
public class HibernateDriverLocationDAOTest extends AbstractTransactionalJUnit4SpringContextTests {

  @Autowired
  private DriverLocationDAO dao;

  @Autowired
  private DriverDAO driverDao;

  @Autowired
  private CarDAO carDao;

  @Test
  public void save(){
    // GIVEN

    final Car car = Car.newBuilder().setId(1L).setManufacturingYear(2010).setLicensePlate("HH-HH 1295")
        .setModel("E-Klasse").setSeats(4).setRating(4.3).build();
    this.carDao.save(car);

    final Driver driver = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt1")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(4.5).setCar(car).setOnlineStatus(OnlineStatus.FREE)
        .build();
    this.driverDao.save(driver);

    final DriverLocation driverLocation = DriverLocation.newBuilder().setId(driver.getDriverId()).setDateCreated(LocalDate.now())
    		.setCoordinate(new Coordinate(55.123, 8.345)).setAccuracy(50d).setSpeed(80d).build();
    // WHEN
    final DriverLocation savedDriverLocation = dao.save(driverLocation);
    Assert.assertEquals(savedDriverLocation, driverLocation);
    Assert.assertTrue(savedDriverLocation.getDriverId().equals(driver.getDriverId()));
    

    // THEN
    Assert.assertNotNull(driver.getId());
  }

  @Test
  public void findByDriverId(){
    // GIVEN

    final Car car = Car.newBuilder().setId(1L).setManufacturingYear(2010).setLicensePlate("HH-HH 1295")
        .setModel("E-Klasse").setSeats(4).setRating(4.3).build();
    this.carDao.save(car);

    final Driver driver = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt1")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(4.5).setCar(car).setOnlineStatus(OnlineStatus.FREE)
        .build();
    final Driver savedDriver = this.driverDao.save(driver);

    final DriverLocation driverLocation = DriverLocation.newBuilder().setId(driver.getDriverId()).setDateCreated(LocalDate.now())
    		.setCoordinate(new Coordinate(55.123, 8.345)).setAccuracy(50d).setSpeed(80d).build();
    final DriverLocation savedDriverLocation = dao.save(driverLocation);
    // WHEN
    Assert.assertEquals("DriverId", driver.getDriverId(), savedDriver.getDriverId());
    Assert.assertEquals("DriverLocationDriverId", driver.getDriverId(), savedDriverLocation.getDriverId());
 
    final DriverLocation foundDriverLocation = dao.findByDriverId(driver.getDriverId());

    // THEN
    Assert.assertNotNull(driver.getId());

    Assert.assertEquals("DriverLocationDriverId", driver.getDriverId(), foundDriverLocation.getDriverId());
  }

  @Test
  public void findByDriver(){
    // GIVEN

    final Car car = Car.newBuilder().setId(1L).setManufacturingYear(2010).setLicensePlate("HH-HH 1295")
        .setModel("E-Klasse").setSeats(4).setRating(4.3).build();
    this.carDao.save(car);

    final Driver driver = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt1")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(4.5).setCar(car).setOnlineStatus(OnlineStatus.FREE)
        .build();
    this.driverDao.save(driver);

    final DriverLocation driverLocation = DriverLocation.newBuilder().setId(driver.getDriverId()).setDateCreated(LocalDate.now())
    		.setCoordinate(new Coordinate(55.123, 8.345)).setAccuracy(50d).setSpeed(80d).build();
    dao.save(driverLocation);
    // WHEN
    final DriverLocation foundDriverLocation = dao.find(driver);

    // THEN
    Assert.assertNotNull(driver.getId());

    Assert.assertEquals("DriverLocationDriverId", driver.getDriverId(), foundDriverLocation.getDriverId());
  }

  @Test
  public void findOne(){
    // GIVEN

    final Car car = Car.newBuilder().setId(1L).setManufacturingYear(2010).setLicensePlate("HH-HH 1295")
        .setModel("E-Klasse").setSeats(4).setRating(4.3).build();
    this.carDao.save(car);

    final Driver driver = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt1")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(4.5).setCar(car).setOnlineStatus(OnlineStatus.FREE)
        .build();
    this.driverDao.save(driver);

    final DriverLocation driverLocation = DriverLocation.newBuilder().setId(driver.getDriverId()).setDateCreated(LocalDate.now())
    		.setCoordinate(new Coordinate(55.123, 8.345)).setAccuracy(50d).setSpeed(80d).build();
    dao.save(driverLocation);
    // WHEN
    final DriverLocation foundDriverLocation = dao.findOne(driverLocation.getId());

    // THEN
    Assert.assertNotNull(driver.getId());

    Assert.assertEquals("DriverLocationDriverId", driver.getDriverId(), foundDriverLocation.getDriverId());
  }
  @Test
  public void findAll(){
    // GIVEN

    final Car car = Car.newBuilder().setId(1L).setManufacturingYear(2010).setLicensePlate("HH-HH 1295")
        .setModel("E-Klasse").setSeats(4).setRating(4.3).build();
    this.carDao.save(car);

    final Driver driver = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt1")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(4.5).setCar(car).setOnlineStatus(OnlineStatus.FREE)
        .build();
    this.driverDao.save(driver);

    final DriverLocation driverLocation = DriverLocation.newBuilder().setId(driver.getDriverId()).setDateCreated(LocalDate.now())
    		.setCoordinate(new Coordinate(55.123, 8.345)).setAccuracy(50d).setSpeed(80d).build();
    dao.save(driverLocation);
    
    List<Long> idList = new ArrayList<>();
    idList.add(driverLocation.getId());
    // WHEN
    final List<DriverLocation> foundDriverLocations = dao.findAll(idList);

    // THEN
    Assert.assertNotNull(driver.getId());

    Assert.assertEquals("DriverLocationDriverId", driver.getDriverId(), foundDriverLocations.get(0).getDriverId());
  }


}
