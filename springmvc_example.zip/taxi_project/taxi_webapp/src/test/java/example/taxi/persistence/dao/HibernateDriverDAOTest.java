package example.taxi.persistence.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;

import example.taxi.configuration.DatabaseConfiguration;
import example.taxi.domainobject.Car;
import example.taxi.domainobject.Client;
import example.taxi.domainobject.Driver;
import example.taxi.domainvalue.OnlineStatus;

@ContextConfiguration(classes = { DatabaseConfiguration.class })
@Rollback
public class HibernateDriverDAOTest extends AbstractTransactionalJUnit4SpringContextTests {

  @Autowired
  private DriverDAO dao;

  @Autowired
  private CarDAO daoCar;

  private Driver savedDriver;

  @Before
  public void setUp(){
    this.savedDriver = null;
    this.dao.deleteAll();
  }

  @Test
  public void save(){
    // GIVEN

    final Car car = Car.newBuilder().setDateCreated(LocalDate.now()).setManufacturingYear(2010)
        .setLicensePlate("HH-HH 1295").setModel("E-Klasse").setSeats(4).setRating(4.3).build();
    final Driver driver = Driver.newBuilder().setClient(new Client(5l, "manni", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car).setOnlineStatus(OnlineStatus.FREE).build();

    // WHEN
    this.savedDriver = this.dao.save(driver);
    final Car foundCar = this.daoCar.findOne(this.savedDriver.getCar().getId());

    // THEN
    Assert.assertEquals("Driver not equal", driver, savedDriver);
    Assert.assertNotNull(foundCar);
    Assert.assertNotNull(savedDriver.getId());
    Assert.assertNotNull(savedDriver.getCar().getId());
    Assert.assertNotNull(savedDriver.getClient());
    Assert.assertEquals("Car not the same", savedDriver.getCar().getId(), foundCar.getId());
  }

  @Test
  public void save1(){
    // GIVEN

    final Car car = Car.newBuilder().setDateCreated(LocalDate.now()).setManufacturingYear(2010)
        .setLicensePlate("HH-HH 1295").setModel("E-Klasse").setSeats(4).setRating(4.3).build();
    final Driver driver = Driver.newBuilder().setClient(new Client(5l, "manni", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car).setOnlineStatus(OnlineStatus.FREE).build();

    car.setDrivers(Arrays.asList(driver));
    // WHEN
    this.savedDriver = this.dao.save(driver);
    final Car foundCar = this.daoCar.findOne(this.savedDriver.getCar().getId());

    // THEN
    Assert.assertEquals("Driver not equal", driver, savedDriver);
    Assert.assertNotNull(foundCar);
    Assert.assertNotNull(savedDriver.getId());
    Assert.assertNotNull(savedDriver.getCar().getId());
    Assert.assertNotNull(savedDriver.getClient());
    Assert.assertEquals("Car not the same", savedDriver.getCar().getId(), foundCar.getId());
  }

  @Test
  public void saveWithCarNull(){
    // GIVEN

    final Car car = null;
    final Driver driver = Driver.newBuilder().setClient(new Client(5l, "manni", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car).setOnlineStatus(OnlineStatus.FREE).build();

    // WHEN
    this.savedDriver = dao.save(driver);

    // THEN
    Assert.assertEquals("Driver not equal", driver, savedDriver);
    Assert.assertNotNull(savedDriver.getId());
    Assert.assertNull(savedDriver.getCar());
    Assert.assertNotNull(savedDriver.getClient());
    Car driverCar = savedDriver.getCar();
    driverCar = Car.newBuilder().build();

    this.savedDriver.setCar(driverCar);

    // driverCar as detached has to be saved
    this.daoCar.save(driverCar);

    // driverCar = this.daoCar.save(driverCar);
    // this.savedDriver.setCar(driverCar);
    final Driver mergeDriver = this.dao.save(this.savedDriver);
    Assert.assertEquals(mergeDriver.getCar().getId(), this.daoCar.findOne(this.savedDriver.getCar().getId()).getId());
    Assert.assertEquals(mergeDriver.getCar().getDrivers().size(), 1L);
    Assert.assertTrue(this.daoCar.findOne(this.savedDriver.getCar().getId()).getCarId() == null);
  }

  @Test
  public void saveList(){
    // GIVEN

    final List<Driver> drivers = new ArrayList<Driver>();

    final Car car = Car.newBuilder().setDateCreated(LocalDate.now()).setManufacturingYear(2010)
        .setLicensePlate("HH-HH 1295").setModel("E-Klasse").setSeats(4).setRating(4.3).build();
    final Driver driver = Driver.newBuilder().setClient(new Client(5l, "manni", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car).setOnlineStatus(OnlineStatus.FREE).build();

    final Driver driver1 = Driver.newBuilder().setClient(new Client(5l, "manni2", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car).setOnlineStatus(OnlineStatus.FREE).build();
    final Driver driver2 = Driver.newBuilder().setClient(new Client(5l, "manni2", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car).setOnlineStatus(OnlineStatus.FREE).build();

    drivers.add(driver);
    drivers.add(driver1);
    drivers.add(driver2);
    // WHEN
    final List<Driver> savedDrivers = dao.save(drivers);
    Assert.assertEquals("Drivers amount not equal", drivers.size(), savedDrivers.size());
    final List<Driver> foundDrivers = this.dao.findAll();

    // THEN
    Assert.assertEquals("Drivers amount not equal", foundDrivers.size(), this.dao.count());
    Assert.assertEquals(this.daoCar.count(), 1L);
    Assert.assertEquals("Referenced car not the same", this.daoCar.find(driver), this.daoCar.find(driver1));
  }

  @Test
  public void findOne(){
    // GIVEN

    final Car car = Car.newBuilder().setId(1L).setManufacturingYear(2010).setLicensePlate("HH-HH 1295")
        .setModel("E-Klasse").setSeats(4).setRating(4.3).build();
    final Driver driver = Driver.newBuilder().setClient(new Client(null, "manni", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car).setOnlineStatus(OnlineStatus.FREE).build();
    this.savedDriver = this.dao.save(driver);

    // WHEN
    final Driver driverFound = dao.findOne(driver.getId());

    // THEN
    Assert.assertNotNull(driverFound);
    Assert.assertNotNull(driverFound.getId());

    Assert.assertEquals("Driver not equal", driver, driverFound);
  }

  @Test
  public void findOneWithClientIdNull(){
    // GIVEN

    final Car car = Car.newBuilder().setId(1L).setManufacturingYear(2010).setLicensePlate("HH-HH 1295")
        .setModel("E-Klasse").setSeats(4).setRating(4.3).build();
    final Driver driver = Driver.newBuilder().setId(1L).setClient(new Client(null, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt1")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(4.5).setCar(car).setOnlineStatus(OnlineStatus.FREE)
        .build();
    this.savedDriver = this.dao.save(driver);

    // WHEN
    final Driver driverFound = dao.findOne(driver.getId());

    // THEN
    Assert.assertNotNull(driverFound);
    Assert.assertNotNull(driverFound.getId());

    Assert.assertEquals("Driver not equal", driver, driverFound);
    Assert.assertEquals("DriverId not equal to ClientId", driverFound.getDriverId(), driverFound.getClient().getId());
  }

  @Test(expected = Exception.class)
  public void deleteNull(){
    // GIVEN
    final Long deleteId = null;
    // WHEN
    this.dao.delete(deleteId);

    // THEN
    // expected Throwable
  }

  @Test
  public void findByIds(){
    // GIVEN
    final SortedSet<Long> driverIds = new TreeSet<Long>();
    final Car car1 = Car.newBuilder().setId(1L).setManufacturingYear(2010).setLicensePlate("HH-HH 1295")
        .setModel("E-Klasse").setSeats(4).setRating(4.3).build();
    final Driver driver1 = Driver.newBuilder().setClient(new Client(null, "manni", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car1).setOnlineStatus(OnlineStatus.FREE).build();
    this.dao.save(driver1);
    driverIds.add(driver1.getId());

    final Car car2 = Car.newBuilder().setId(2L).setManufacturingYear(2010).setLicensePlate("HH-HH 1292")
        .setModel("E-Klasse2").setSeats(3).setRating(4.2).build();
    final Driver driver2 = Driver.newBuilder().setClient(new Client(null, "manni", "12344")).setFirstName("Manfred2")
        .setLastName("Taximann").setSlogan("App geht die Fahrt").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE).build();
    this.dao.save(driver2);
    driverIds.add(driver2.getId());

    // WHEN
    final List<Driver> driversFound = dao.findAll(driverIds);

    // THEN
    Assert.assertNotNull(driversFound);
    Assert.assertEquals("Count found driver:", driverIds.size(), driversFound.size());

    Assert.assertEquals("Driver 2 not in result list:", driver1, driversFound.get(0));
    Assert.assertEquals("Driver 1 not in result list:", driver2, driversFound.get(1));
    // clean database
    this.dao.deleteAll();
  }

  @Test
  public void findUsername(){
    // GIVEN

    final Car car1 = Car.newBuilder().setId(1L).setManufacturingYear(2010).setLicensePlate("HH-HH 1295")
        .setModel("E-Klasse").setSeats(4).setRating(4.3).build();
    final Driver driver1 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni1", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt1")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(4.5).setCar(car1).setOnlineStatus(OnlineStatus.FREE)
        .build();
    this.dao.save(driver1);

    final Car car2 = Car.newBuilder().setId(2L).setManufacturingYear(2010).setLicensePlate("HH-HH 1292")
        .setModel("E-Klasse2").setSeats(3).setRating(4.2).build();
    final Driver driver2 = Driver.newBuilder().setId(2L).setClient(new Client(2L, "manni2", "12344"))
        .setFirstName("Manfred2").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(4.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE)
        .build();
    this.dao.save(driver2);

    // WHEN
    final Driver driverFound = dao.findByUsername(driver1.getClient().getUsername());

    // THEN
    Assert.assertNotNull(driverFound);
    Assert.assertNotNull(driverFound.getId());

    final Client client = driver1.getClient();
    final Client clientFound = driverFound.getClient();

    Assert.assertEquals("Username", client.getUsername(), clientFound.getUsername());
    Assert.assertEquals("Password", client.getPassword(), clientFound.getPassword());
  }

  @Test
  public void findByClient(){
    // GIVEN
    final Client client1 = new Client(1L, "manni1", "12344");
    final Car car1 = Car.newBuilder().setId(1L).setManufacturingYear(2010).setLicensePlate("HH-HH 1295")
        .setModel("E-Klasse").setSeats(4).setRating(4.3).build();
    final Driver driver1 = Driver.newBuilder().setId(1L).setClient(client1).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car1).setOnlineStatus(OnlineStatus.FREE).build();
    Driver driverSaved = this.dao.save(driver1);

    // WHEN
    Assert.assertEquals("Username", driverSaved.getClient().getUsername(), client1.getUsername());
    final Driver driverFound = dao.find(client1);

    // THEN
    Assert.assertNotNull(driverFound);
    Assert.assertNotNull(driverFound.getId());

    final Client client = driver1.getClient();
    final Client clientFound = driverFound.getClient();

    Assert.assertEquals("Username", client.getUsername(), clientFound.getUsername());
    Assert.assertEquals("Password", client.getPassword(), clientFound.getPassword());
    Assert.assertEquals("Client id", client.getId(), clientFound.getId());
  }

  @After
  public void cleanUp(){
    if (this.savedDriver != null) {
      Assert.assertTrue(this.dao.count() > 0);
      this.dao.delete(savedDriver);
      Assert.assertTrue(this.dao.count() == 0);
    }
  }
}
