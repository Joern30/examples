package example.taxi.configuration;

import org.mockito.Mockito;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import example.taxi.persistence.dao.HibernateTaxiPoiDAO;
import example.taxi.persistence.dao.TaxiPoiDAO;

@Configuration
@Import({ ControllerConfig.class })
// @EnableJpaRepositories(basePackages = "example.taxi.persistence.dao")
public class TestSpringServletConfig {

  // @Bean(destroyMethod = "close")
  // public DataSource dataSource() throws SQLException{
  // final org.apache.tomcat.jdbc.pool.DataSource bean = new
  // org.apache.tomcat.jdbc.pool.DataSource();
  //
  // return bean;
  // }

  // @Bean
  // public FactoryBean<SessionFactory> sessionFactoryMock(final DataSource
  // datasource){
  // final LocalSessionFactoryBean factory =
  // Mockito.mock(LocalSessionFactoryBean.class);
  // return factory;
  // }

  /**
   * ################################### DataAccessObject
   * ###################################
   */

  @Bean
  public TaxiPoiDAO taxiPoiDAO(){
    TaxiPoiDAO mockTaxiDao = Mockito.mock(HibernateTaxiPoiDAO.class);
    return mockTaxiDao;
  }
}
