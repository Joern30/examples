package example.taxi.test.utility;

import java.io.IOException;
import java.nio.charset.Charset;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.http.MediaType;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;

import example.taxi.domainobject.CustomLocalDateSerializer;
import example.taxi.domainobject.CustomLocalDateTimeSerializer;

/**
 * @author Jörn Scheffler
 */
public class UnitTestUtil {

  private static final String CHARACTER = "C";

  public static final MediaType APPLICATION_JSON_UTF8 = new MediaType(MediaType.APPLICATION_JSON.getType(),
      MediaType.APPLICATION_JSON.getSubtype(), Charset.forName("utf8"));

  public static byte[] convertObjectToJsonBytes(Object object) throws IOException{
    ObjectMapper mapper = new ObjectMapper();
    mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
    return mapper.writeValueAsBytes(object);
  }

  public static byte[] convertObjectWithNullPropertyToJsonBytes(Object object) throws IOException{
    ObjectMapper mapper = new ObjectMapper();
    mapper.setSerializationInclusion(JsonInclude.Include.ALWAYS);
    return mapper.writeValueAsBytes(object);
  }

  public static byte[] convertObjectWithLocalDatePropertyToJsonBytes(Object object) throws IOException{
    ObjectMapper mapper = new ObjectMapper();
    CustomLocalDateSerializer localDateSerializer = new CustomLocalDateSerializer();
    CustomLocalDateTimeSerializer localDateTimeSerializer = new CustomLocalDateTimeSerializer();
    // Jackson2ObjectMapperBuilder builder = new Jackson2ObjectMapperBuilder();
    // builder.serializationInclusion(JsonInclude.Include.NON_NULL);
    // builder.featuresToDisable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS).failOnUnknownProperties(false);
    // builder.propertyNamingStrategy(PropertyNamingStrategy.LOWER_CAMEL_CASE);
    // builder.serializationInclusion(Include.NON_EMPTY);
    // builder.indentOutput(true).serializerByType(LocalDate.class,
    // localDateSerializer);
    // builder.serializerByType(LocalDateTime.class, localDateTimeSerializer);

    JavaTimeModule module = new JavaTimeModule();
    module.addSerializer(LocalDateTime.class, localDateTimeSerializer);
    module.addSerializer(LocalDate.class, localDateSerializer);
    module.addDeserializer(LocalDate.class, new LocalDateDeserializer(DateTimeFormatter.ofPattern("yyyy/MM/dd")));

    // builder.configure(mapper);
    mapper.registerModule(module);
    mapper.configure(SerializationFeature.WRITE_DATES_WITH_ZONE_ID, false);
    return mapper.writeValueAsBytes(object);
  }

  public static String createStringWithLength(int length){
    StringBuilder builder = new StringBuilder();
    for (int index = 0; index <= length; index++) {
      builder.append(CHARACTER);
    }
    return builder.toString();
  }
}
