package example.taxi.controller;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.LinkedList;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.SerializationFeature;

import example.taxi.configuration.WebTestConfig;
import example.taxi.domainobject.Car;
import example.taxi.domainobject.Client;
import example.taxi.domainobject.Coordinate;
import example.taxi.domainobject.CustomLocalDateSerializer;
import example.taxi.domainobject.CustomLocalDateTimeSerializer;
import example.taxi.domainobject.Driver;
import example.taxi.domainobject.DriverLocation;
import example.taxi.domainobject.TaxiPoi;
import example.taxi.domainvalue.OnlineStatus;
import example.taxi.persistence.dao.TaxiPoiDAO;

/**
 * @author Jörn Scheffler
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { WebTestConfig.class })
public class TaxiControllerWebStandaloneTest {

  private MockMvc mockMvc;
  @Autowired
  private TaxiPoiDAO taxiPoiDAO;
  @Autowired
  private TestTaxiPoiController controller;
  private LinkedList<TaxiPoi> taxiPois = new LinkedList<TaxiPoi>();

  private Car car1;
  private Driver driver1;

  private TaxiPoi taxiPoi1;

  private Car car2;
  private Driver driver2;

  private TaxiPoi taxiPoi2;

  private Car car3;
  private Driver driver3;

  private TaxiPoi taxiPoi3;

  @Before
  public void setUp(){
    MockitoAnnotations.initMocks(this);
    CustomLocalDateSerializer localDateSerializer = new CustomLocalDateSerializer();
    CustomLocalDateTimeSerializer localDateTimeSerializer = new CustomLocalDateTimeSerializer();
    Jackson2ObjectMapperBuilder builder = new Jackson2ObjectMapperBuilder();
    builder.serializationInclusion(JsonInclude.Include.NON_NULL);
    builder.featuresToDisable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS).failOnUnknownProperties(false);
    builder.propertyNamingStrategy(PropertyNamingStrategy.LOWER_CAMEL_CASE);
    builder.serializationInclusion(Include.NON_EMPTY);
    builder.indentOutput(true).serializerByType(LocalDate.class, localDateSerializer);
    builder.serializerByType(LocalDateTime.class, localDateTimeSerializer);

    mockMvc = MockMvcBuilders.standaloneSetup(controller)
        .setCustomArgumentResolvers(new TaxiPoiControllerMethodArgumentResolver())
        .setControllerAdvice(new GlobalControllerExceptionHandler())
        .setMessageConverters(new MappingJackson2HttpMessageConverter(builder.build())).build();
    taxiPois = new LinkedList<TaxiPoi>();

    car1 = Car.newBuilder().setSeats(4).setManufacturingYear(1988).build();
    driver1 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car1).setOnlineStatus(OnlineStatus.OCCUPIED).build();

    taxiPoi1 = new TaxiPoi(driver1, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now()).setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d)
    		.setSpeed(67d).build());
    taxiPois.add(taxiPoi1);

    car2 = Car.newBuilder().setSeats(5).setManufacturingYear(2010).build();
    driver2 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(1.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE).build();

    taxiPoi2 = new TaxiPoi(driver2, DriverLocation.newBuilder().setId(driver2.getDriverId()).setDateCreated(LocalDate.now()).setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d)
    		.setSpeed(67d).build());

    taxiPois.add(taxiPoi2);

    car3 = Car.newBuilder().setSeats(9).setManufacturingYear(2015).build();
    driver3 = Driver.newBuilder().setId(2L).setClient(new Client(1L, "manni", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(2.1).setCar(car3).setOnlineStatus(OnlineStatus.FREE).build();

    taxiPoi3 = new TaxiPoi(driver3, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now()).setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d)
    		.setSpeed(67d).build());
    
    taxiPois.add(taxiPoi3);

  }

  @Test
  public void shouldReturnResponseStatusNotOk() throws Exception{
    when(this.taxiPoiDAO.findDriversWithin(Matchers.any(Coordinate.class), Matchers.anyDouble())).thenReturn(taxiPois);

    this.mockMvc
        .perform(
            get("/v1/test/taxiCriteriasInRadiusWithHandler").param("p1Lat", "0").param("p1Lon", "0")
                .param("radiusInMeter", "20000"))
        .andExpect(status().is(400))
        .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8))
        .andExpect(jsonPath("$.errors", hasSize(1)))
        .andExpect(
            jsonPath(
                "$.errors[0]",
                is("one of following values must be set: driver rating, car seats, driver onlines status, car manufactoring year")));

  }

  @Test
  public void shouldReturnResponseStatusOk() throws Exception{
    when(this.taxiPoiDAO.findDriversWithin(Matchers.any(Coordinate.class), Matchers.anyDouble())).thenReturn(taxiPois);

    this.mockMvc
        .perform(
            get("/v1/test/taxiCriteriasInRadiusWithHandler").param("p1Lat", "0").param("p1Lon", "0")
                .param("radiusInMeter", "20000").param("carSeats", "4")).andExpect(status().isOk())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8));

  }
}
