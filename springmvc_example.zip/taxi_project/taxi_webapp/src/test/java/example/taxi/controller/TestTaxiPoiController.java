package example.taxi.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.base.Preconditions;

import example.taxi.domainobject.Coordinate;
import example.taxi.domainobject.TaxiPoi;
import example.taxi.domainobject.TaxiPois;
import example.taxi.persistence.dao.TaxiPoiDAO;
import example.taxi.util.CriteriaFactory;

@Controller
public class TestTaxiPoiController {
	
  private static final Logger LOGGER = LoggerFactory.getLogger(TaxiPoiController.class);

  @Autowired
  private TaxiPoiDAO taxiPoiDAO;

  @Autowired
  private CriteriaFactory<List<TaxiPoi>, Integer, String> criteriaFactory;

  private final long maxKilometers = 20000l;
  private final long minKilometers = 0l;

  /**
   * Find taxis in box defined by {@code p1Lat}, {@code p1Lon}, {@code p2Lat}
   * and {@code p2Lon}
   * 
   * @param p1Lat
   * @param p1Lon
   * @param p2Lat
   * @param p2Lon
   * @return found drivers
   */
  @Transactional(readOnly = true)
  @ResponseBody
  public TaxiPois taxisWithin(@RequestParam(required = true) final Float p1Lat,
      @RequestParam(required = true) final Float p1Lon, @RequestParam(required = true) final Float p2Lat,
      @RequestParam(required = true) final Float p2Lon){

    Preconditions.checkArgument(!p1Lat.equals(p2Lat), "Could not span box because p1Lat == p2Lat");
    Preconditions.checkArgument(!p1Lon.equals(p2Lon), "Could not span box because p1Lon == p2Lon");

    final List<example.taxi.domainobject.TaxiPoi> drivers = this.taxiPoiDAO.findDriversWithin(new Coordinate(p1Lat,
        p1Lon), new Coordinate(p2Lat, p2Lon));

    return new TaxiPois(drivers);
  }

  /**
   * Find all taxis within a radius of x meters defined by {radiusInMeter}
   * around a specified point defined by {@code p1Lat} and {@code p1Lon}
   *
   * @param p1Lat
   *          latitude coordinate
   * @param p1Lon
   *          longitude coordinate
   * @param radiusInMeter
   *          radius in meters around p1Lat and p1Lon coordinates
   * @return TaxiPois with found drivers within specified radius
   */
  @Transactional(readOnly = true)
  @ResponseBody
  public TaxiPois getTaxisWithinRadius(@RequestParam(required = true) final Float p1Lat,
      @RequestParam(required = true) final Float p1Lon, @RequestParam(required = true) final long radiusInMeter){

    // require parameters
    final boolean cond = radiusInMeter <= maxKilometers;
    final boolean cond2 = radiusInMeter > minKilometers;

    // check required parameters
    TaxiPoiControllerParameterValueHandler.checkPreCondition(cond,
        "Could not process radius value because radius is bigger than 20 km");
    TaxiPoiControllerParameterValueHandler.checkPreCondition(cond2,
        "Could not process radius value because radius is 0 km or negative");

    final double radius = Long.valueOf(radiusInMeter).doubleValue();
    final List<TaxiPoi> drivers = this.taxiPoiDAO.findDriversWithin(new Coordinate(p1Lat, p1Lon), radius);

    return new TaxiPois(drivers);
  }

  /**
   * Find all taxis within a radius of x meters defined by {@code radiusInMeter}
   * around a specified point defined by {@code p1Lat} and {@code p1Lon}
   *
   * @param p1Lat
   *          latitude coordinate
   * @param p1Lon
   *          longitude coordinate
   * @param radiusInMeter
   *          radius in meters around p1Lat and p1Lon coordinates
   * @param driverRating
   * @param carSeats
   * @param driverOnlineStatus
   * @param carManufactoringYear
   * @return TaxiPois with found drivers within specified radius under given
   *         criterias
   */
  @Transactional(readOnly = true)
  @ResponseBody
  public TaxiPois getTaxisWithinRadiusAndAttributes(@RequestParam(required = true) final Float p1Lat,
      @RequestParam(required = true) final Float p1Lon, @RequestParam(required = true) final long radiusInMeter,

      @RequestParam(required = false) final Float driverRating, @RequestParam(required = false) final Long carSeats,
      @RequestParam(required = false) final String driverOnlineStatus,
      @RequestParam(required = false) final Long carManufactoringYear)

  {

    Map<Integer, String> criteriaMap = new HashMap<Integer, String>();

    // checking optional parameters
    // TaxiPoiControllerHandler
    criteriaMap = TaxiPoiControllerParameterValueHandler.handleParameterValues(radiusInMeter, driverRating, carSeats,
        driverOnlineStatus, carManufactoringYear);
    // type conversion for radius
    final double radius = Long.valueOf(radiusInMeter).doubleValue();
    final List<TaxiPoi> drivers = this.taxiPoiDAO.findDriversWithin(new Coordinate(p1Lat, p1Lon), radius);

    // filter list drivers (in radius) with existing CriteriaStrategies for
    // optional driver rating, driver online status, car seats, car
    // manufactoring year
    List<TaxiPoi> filteredDrivers = this.criteriaFactory.processCriterias(drivers, criteriaMap);

    return new TaxiPois(filteredDrivers);
  }

  /**
   * Find all taxis within a radius of x meters defined by {@code radiusInMeter}
   * around a specified point defined by {@code p1Lat} and {@code p1Lon}
   *
   * @param p1Lat
   *          latitude coordinate
   * @param p1Lon
   *          longitude coordinate
   * @param radiusInMeter
   *          radius in meters around p1Lat and p1Lon coordinates
   * @param driverRating
   * @param carSeats
   * @param driverOnlineStatus
   * @param carManufactoringYear
   * @return TaxiPois with found drivers within specified radius under given
   *         criterias
   */
  @Transactional(readOnly = true)
  @RequestMapping(value = "/v1/test/taxiCriteriasInRadiusWithHandler", method = RequestMethod.GET)
  @ResponseBody
  public TaxiPois getTaxisWithinRadiusAndAttributesWithHandler(@RequestParam(required = true) final Float p1Lat,
      @RequestParam(required = true) final Float p1Lon, @RequestParam(required = true) final long radiusInMeter,
      final TaxiPoiControllerParams params)

  {

    // type conversion for radius
    final double radius = Long.valueOf(params.getRadiusInMeter()).doubleValue();
    final List<TaxiPoi> drivers = this.taxiPoiDAO.findDriversWithin(new Coordinate(p1Lat, p1Lon), radius);

    LOGGER.debug("TestTaxiPoiController: Found list of {} cars ", drivers.size());

    // filter list drivers (in radius) with existing CriteriaStrategies for
    // optional driver rating, driver online status, car seats, car
    // manufactoring year
    List<TaxiPoi> filteredDrivers = this.criteriaFactory.processCriterias(drivers, params.getCriteriaMap());

    return new TaxiPois(filteredDrivers);
  }

  public void setTaxiPoiDAO(TaxiPoiDAO taxiPoiDAO2){
    this.taxiPoiDAO = taxiPoiDAO2;
  }

  public void setCriteriaFactory(final CriteriaFactory<List<TaxiPoi>, Integer, String> criteriaFactory){
    this.criteriaFactory = criteriaFactory;
  }

}
