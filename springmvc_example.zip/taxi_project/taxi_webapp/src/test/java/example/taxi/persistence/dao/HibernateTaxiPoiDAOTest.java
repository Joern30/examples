package example.taxi.persistence.dao;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;

import example.taxi.configuration.DatabaseConfiguration;
import example.taxi.domainobject.Car;
import example.taxi.domainobject.Client;
import example.taxi.domainobject.Coordinate;
import example.taxi.domainobject.Driver;
import example.taxi.domainobject.DriverLocation;
import example.taxi.domainobject.TaxiPoi;
import example.taxi.domainvalue.OnlineStatus;

@ContextConfiguration(classes = { DatabaseConfiguration.class })
@Rollback
public class HibernateTaxiPoiDAOTest extends AbstractTransactionalJUnit4SpringContextTests {

  @Autowired
  private DriverLocationDAO driverLocationDao;

  @Autowired
  private DriverDAO driverDao;

  @Autowired
  private CarDAO carDao;

  @Mock
  private TaxiPoiDAO dao = new HibernateTaxiPoiDAO();
  
  private List<TaxiPoi> taxiPoiList = new ArrayList<>();
  @Before	
  public void setUp() {
	  
	  MockitoAnnotations.initMocks(this);
	  this.taxiPoiList.clear();
	  
  }
  @Test
  public void findDriversWithin(){
 
	  when(dao.findDriversWithin(any(Coordinate.class), any(Coordinate.class))).thenReturn(taxiPoiList);	
	// GIVEN
    // IN
    final Car car1 = Car.newBuilder().setId(1L).setManufacturingYear(2010).setLicensePlate("HH-HH 1295")
        .setModel("E-Klasse").setSeats(4).setRating(4.3).build();
    this.carDao.save(car1);

    final Driver driver1 = Driver.newBuilder().setClient(new Client(null, "manni", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car1).setOnlineStatus(OnlineStatus.FREE).build();
    this.driverDao.save(driver1);

    final DriverLocation driver1Location = DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now()).
    		setCoordinate(new Coordinate(53.5676, 9.9535)).setAccuracy(50d).setSpeed(45d).build();

    this.driverLocationDao.save(driver1Location);
    TaxiPoi taxiPoi = new TaxiPoi(driver1, driver1Location); 
    this.taxiPoiList.add(taxiPoi);

    // IN
    final Car car2 = Car.newBuilder().setId(2L).setManufacturingYear(2010).setLicensePlate("HH-HH 1292")
        .setModel("E-Klasse2").setSeats(3).setRating(4.2).build();
    this.carDao.save(car2);

    final Driver driver2 = Driver.newBuilder().setId(2L).setClient(new Client(2L, "manni", "12344"))
        .setFirstName("Manfred2").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(4.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE)
        .build();
    this.driverDao.save(driver2);

    final DriverLocation driver2Location = DriverLocation.newBuilder().setId(driver2.getDriverId()).setDateCreated(LocalDate.now()).
    		setCoordinate(new Coordinate(53.5608, 9.9584)).setAccuracy(50d).setSpeed(55d).build();
    this.driverLocationDao.save(driver2Location);

    taxiPoi = new TaxiPoi(driver2, driver2Location); 
    this.taxiPoiList.add(taxiPoi);
    // OUT
    final Car car3 = Car.newBuilder().setId(3L).setManufacturingYear(2010).setLicensePlate("HH-HH 1293")
        .setModel("E-Klasse3").setSeats(3).setRating(4.2).build();
    this.carDao.save(car3);

    final Driver driver3 = Driver.newBuilder().setId(3L).setClient(new Client(3L, "manni", "12343"))
        .setFirstName("Manfred3").setLastName("Taximann3").setSlogan("App geht die Fahrt3")
        .setPictureUrl("http://www.manni.de/bild3.jpg").setRating(4.5).setCar(car3).setOnlineStatus(OnlineStatus.FREE)
        .build();
    this.driverDao.save(driver3);

    final DriverLocation driver3Location = DriverLocation.newBuilder().setId(driver3.getDriverId()).setDateCreated(LocalDate.now()).
    		setCoordinate(new Coordinate(53.5705, 10.0236)).setAccuracy(50d).setSpeed(65d).build();
    
    this.driverLocationDao.save(driver3Location);

    // WHEN
    final List<TaxiPoi> taxiPois = dao.findDriversWithin(new Coordinate(53.5744, 9.9352), new Coordinate(53.5520,
        9.9808));

    // THEN
    final List<Driver> drivers = new ArrayList<Driver>(taxiPois.size());
    for (final TaxiPoi taxiPoiLoc : taxiPois) {
      drivers.add(taxiPoiLoc.getDriver());
    }

    Assert.assertTrue("Driver1 not IN result", drivers.contains(driver1));
    Assert.assertTrue("Driver2 not IN result", drivers.contains(driver2));
    Assert.assertFalse("Driver3 should NOT IN result", drivers.contains(driver3));
    Assert.assertTrue("DriverMessage result size must be 2 but was " + taxiPois.size(), taxiPois.size() == 2);
  }
}
