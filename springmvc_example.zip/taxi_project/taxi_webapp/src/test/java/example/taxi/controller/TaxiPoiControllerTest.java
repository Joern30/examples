package example.taxi.controller;

import java.time.LocalDate;
import java.util.LinkedList;

import javax.inject.Named;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import example.taxi.configuration.DatabaseConfiguration;
import example.taxi.configuration.TestSpringServletConfig;
import example.taxi.configuration.UtilConfig;
import example.taxi.domainobject.Car;
import example.taxi.domainobject.Client;
import example.taxi.domainobject.Coordinate;
import example.taxi.domainobject.Driver;
import example.taxi.domainobject.DriverLocation;
import example.taxi.domainobject.TaxiPoi;
import example.taxi.domainobject.TaxiPois;
import example.taxi.domainvalue.OnlineStatus;
import example.taxi.persistence.dao.TaxiPoiDAO;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { TestSpringServletConfig.class, UtilConfig.class, DatabaseConfiguration.class, })
@Named("TaxiPoiFilterTest")
public class TaxiPoiControllerTest {

  @Autowired
  private TaxiPoiController controller;
  @Autowired
  private TaxiPoiDAO taxiPoiDAO;

  // box tests
  @Test
  @Named("Test TaxiPoi Request with Box")
  public void taxiPoi_withBox(){
    // GIVEN
    final LinkedList<TaxiPoi> taxiPois = new LinkedList<TaxiPoi>();

    final Car car1 = Mockito.mock(Car.class);
    final Driver driver1 = Driver.newBuilder().setId(2L).setClient(new Client(1L, "manni1", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(4.5).setCar(car1)
        .setOnlineStatus(OnlineStatus.OCCUPIED).build();

    final TaxiPoi taxiPoi1 = new TaxiPoi(driver1, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now()).setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d)
    		.setSpeed(67d).build());

    taxiPois.add(taxiPoi1);

    final Car car2 = Mockito.mock(Car.class);
    final Driver driver2 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni2", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(4.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi2 = new TaxiPoi(driver2, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now()).setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d)
    		.setSpeed(67d).build());

    taxiPois.add(taxiPoi2);

    //
    Mockito.stub(this.taxiPoiDAO.findDriversWithin(Matchers.any(Coordinate.class), Matchers.any(Coordinate.class)))
        .toReturn(taxiPois);

    // WHEN
    final TaxiPois taxiPoi = this.controller.taxisWithin(1f, 1f, 2f, 2f);

    // THEN
    Assert.assertNotNull(taxiPoi);
    Assert.assertEquals("TaxiCount", new Integer(2), taxiPoi.getTaxiCount());
    // Check values of Driver1
    Assert.assertTrue("Driver1 id", taxiPoi.getTaxis().get(0).getDriver().getDriverId().equals(driver1.getDriverId()));
    Assert.assertEquals("DriverCoordinate latitude Driver1",
        taxiPoi1.getDriverLocation().getCoordinate().getLatitude(), taxiPoi.getTaxis().get(0).getDriverLocation()
            .getCoordinate().getLatitude(), 0.0000001);
    Assert.assertEquals("DriverCoordinate longitude Driver1", taxiPoi1.getDriverLocation().getCoordinate()
        .getLongitude(), taxiPoi.getTaxis().get(0).getDriverLocation().getCoordinate().getLongitude(), 0.0000001);
    Assert.assertEquals("DriverOnlineStatus Driver1", OnlineStatus.OCCUPIED, taxiPoi.getTaxis().get(0).getDriver()
        .getOnlineStatus());

    // Check values of Driver2
    Assert.assertEquals("DriverId Driver2", driver2.getDriverId(), taxiPoi.getTaxis().get(1).getDriver().getDriverId());
    Assert.assertEquals("DriverCoordinate latitude Driver2",
        taxiPoi2.getDriverLocation().getCoordinate().getLatitude(), taxiPoi.getTaxis().get(1).getDriverLocation()
            .getCoordinate().getLatitude(), 0.0000001);
    Assert.assertEquals("DriverCoordinate longitude Driver2", taxiPoi2.getDriverLocation().getCoordinate()
        .getLongitude(), taxiPoi.getTaxis().get(1).getDriverLocation().getCoordinate().getLongitude(), 0.0000001);
    Assert.assertEquals("DriverOnlineStatus Driver2", OnlineStatus.FREE, taxiPoi.getTaxis().get(1).getDriver()
        .getOnlineStatus());
  }

  @Test
  @Named("Test TaxiPoi Request with bigger Radius")
  public void taxiPoi_withBiggerRadius(){
    final Long radius = 50000L;
    final String exceptionMessagePart = "bigger than 20 km";
    try {
      // WHEN, with radius 50 km not alloed
      this.controller.getTaxisWithinRadius(1f, 1f, radius);
      Assert.fail("IllegalArgumentException expected");
    } catch (IllegalArgumentException illegalEx) {
      Assert.assertTrue("Wrong exception caught for TaxiPoiController.getTaxisWithinRadius", illegalEx.getMessage()
          .contains(exceptionMessagePart));

    }

  }

  @Test
  @Named("Test TaxiPoi Request with equal Latitude Coordinates for Box")
  public void taxiPoi_withEqualPLatCoordinatesForBox(){

    final String exceptionMessagePart = "p1Lat == p2Lat";
    try {
      // WHEN, with equal latitude
      controller.taxisWithin(1f, 2f, 1f, 2f);
      Assert.fail("IllegalArgumentException expected");
    } catch (IllegalArgumentException illegalEx) {
      Assert.assertTrue("Wrong exception caught for TaxiPoiController.taxisWithin",
          illegalEx.getMessage().contains(exceptionMessagePart));

    }

  }

  @Test
  @Named("Test TaxiPoi Request with equal Longitude Coordinates for Box")
  public void taxiPoi_withEqualPlongCoordinatesForBox(){

    final String exceptionMessagePart = "p1Lon == p2Lon";
    try {
      // WHEN, with equal longitude
      controller.taxisWithin(1f, 2f, 2f, 2f);
      Assert.fail("IllegalArgumentException expected");
    } catch (IllegalArgumentException illegalEx) {
      Assert.assertTrue("Wrong exception caught for TaxiPoiController.taxisWithin",
          illegalEx.getMessage().contains(exceptionMessagePart));

    }

  }

  // Radius tests
  @Test
  @Named("Test TaxiPoi Request within Radius")
  public void taxiPoi_withinRadius(){
    // GIVEN
    final LinkedList<TaxiPoi> taxiPois = new LinkedList<TaxiPoi>();
    final Long radius = 20000L;

    final Car car1 = Mockito.mock(Car.class);
    final Driver driver1 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(4.5).setCar(car1)
        .setOnlineStatus(OnlineStatus.OCCUPIED).build();

    final TaxiPoi taxiPoi1 = new TaxiPoi(driver1, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now()).setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d)
    		.setSpeed(67d).build());

    taxiPois.add(taxiPoi1);

    final Car car2 = Mockito.mock(Car.class);
    final Driver driver2 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(4.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi2 = new TaxiPoi(driver2, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now()).setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d)
    		.setSpeed(67d).build());

    taxiPois.add(taxiPoi2);

    Mockito.stub(this.taxiPoiDAO.findDriversWithin(Matchers.any(Coordinate.class), Matchers.anyDouble())).toReturn(
        taxiPois);

    // WHEN
    final TaxiPois taxiPoi = controller.getTaxisWithinRadius(1f, 1f, radius);

    // THEN
    Assert.assertNotNull(taxiPoi);
    Assert.assertEquals("TaxiCount", new Integer(2), taxiPoi.getTaxiCount());

    // Check values of Driver1
    Assert.assertEquals("DriverId Driver1", driver1.getDriverId(), taxiPoi.getTaxis().get(0).getDriver().getDriverId());
    Assert.assertEquals("DriverCoordinate latitude Driver1",
        taxiPoi1.getDriverLocation().getCoordinate().getLatitude(), taxiPoi.getTaxis().get(0).getDriverLocation()
            .getCoordinate().getLatitude(), 0.0000001);
    Assert.assertEquals("DriverCoordinate longitude Driver1", taxiPoi1.getDriverLocation().getCoordinate()
        .getLongitude(), taxiPoi.getTaxis().get(0).getDriverLocation().getCoordinate().getLongitude(), 0.0000001);
    Assert.assertEquals("DriverOnlineStatus Driver1", OnlineStatus.OCCUPIED, taxiPoi.getTaxis().get(0).getDriver()
        .getOnlineStatus());

    // Check values of Driver2
    Assert.assertEquals("DriverId Driver2", driver2.getDriverId(), taxiPoi.getTaxis().get(1).getDriver().getDriverId());
    Assert.assertEquals("DriverCoordinate latitude Driver2",
        taxiPoi2.getDriverLocation().getCoordinate().getLatitude(), taxiPoi.getTaxis().get(1).getDriverLocation()
            .getCoordinate().getLatitude(), 0.0000001);
    Assert.assertEquals("DriverCoordinate longitude Driver2", taxiPoi2.getDriverLocation().getCoordinate()
        .getLongitude(), taxiPoi.getTaxis().get(1).getDriverLocation().getCoordinate().getLongitude(), 0.0000001);
    Assert.assertEquals("DriverOnlineStatus Driver2", OnlineStatus.FREE, taxiPoi.getTaxis().get(1).getDriver()
        .getOnlineStatus());
  }

  @Test
  @Named("Test TaxiPoi Request with zero Radius")
  public void taxiPoi_withNegativeRadius(){

    final String exceptionMessagePart = "0 km or negative";
    try {
      // WHEN, with negative radius not alloed
      controller.getTaxisWithinRadius(1f, 1f, -10000L);
      Assert.fail("IllegalArgumentException expected");
    } catch (IllegalArgumentException illegalEx) {
      Assert.assertTrue("Wrong exception caught for TaxiPoiController.getTaxisWithinRadius", illegalEx.getMessage()
          .contains(exceptionMessagePart));

    }

  }

  // general test
  @Test(expected = IllegalArgumentException.class)
  @Named("Test TaxiPoi Request without Box")
  public void taxiPoi_withNoBox(){

    controller.taxisWithin(0f, 0f, 0f, 0f);
  }

  // general test
  @Test(expected = IllegalArgumentException.class)
  @Named("Test TaxiPoi Request with no Radius")
  public void taxiPoi_withNoRadius(){

    this.controller.getTaxisWithinRadius(0f, 0f, 0L);
  }

  @Test
  @Named("Test TaxiPoi Request within Radius with all Attributes")
  public void taxiPoi_withRadiusAttributes(){
    // GIVEN
    final LinkedList<TaxiPoi> taxiPois = new LinkedList<TaxiPoi>();

    final Long radius = 20000L;

    final Float driverRatingLimit = 2f;
    final String driverOnlineStatusLimit = "FREE";

    final Long carSeatsLimit = 4L;
    final Long carManufactoringYearLimit = 6L;

    final Car car1 = Car.newBuilder().setSeats(4).setManufacturingYear(1988).build();
    final Driver driver1 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(4.5).setCar(car1)
        .setOnlineStatus(OnlineStatus.OCCUPIED).build();

    final TaxiPoi taxiPoi1 = new TaxiPoi(driver1, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now()).setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d)
    		.setSpeed(67d).build());
    taxiPois.add(taxiPoi1);

    final Car car2 = Car.newBuilder().setSeats(5).setManufacturingYear(2010).build();
    final Driver driver2 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(1.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi2 = new TaxiPoi(driver2, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now()).setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d)
    		.setSpeed(67d).build());

    taxiPois.add(taxiPoi2);

    final Car car3 = Car.newBuilder().setSeats(9).setManufacturingYear(2015).build();
    final Driver driver3 = Driver.newBuilder().setId(2L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(2.1).setCar(car3).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi3 = new TaxiPoi(driver3, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now()).setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d)
    		.setSpeed(67d).build());
    
    taxiPois.add(taxiPoi3);

    Mockito.stub(this.taxiPoiDAO.findDriversWithin(Matchers.any(Coordinate.class), Matchers.anyDouble())).toReturn(
        taxiPois);

    // WHEN
    final TaxiPois taxiPoi = this.controller.getTaxisWithinRadiusAndAttributes(1f, 1f, radius, driverRatingLimit,
        carSeatsLimit, driverOnlineStatusLimit, carManufactoringYearLimit);

    // THEN
    Assert.assertNotNull(taxiPoi);
    Assert.assertEquals("TaxiCount", new Integer(1), taxiPoi.getTaxiCount());

    // Check values of Driver3
    Assert.assertEquals("DriverId Driver3", driver3.getDriverId(), taxiPoi.getTaxis().get(0).getDriver().getDriverId());
    Assert.assertEquals("DriverCoordinate latitude Driver3",
        taxiPoi3.getDriverLocation().getCoordinate().getLatitude(), taxiPoi.getTaxis().get(0).getDriverLocation()
            .getCoordinate().getLatitude(), 0.0000001);
    Assert.assertEquals("DriverCoordinate longitude Driver3", taxiPoi3.getDriverLocation().getCoordinate()
        .getLongitude(), taxiPoi.getTaxis().get(0).getDriverLocation().getCoordinate().getLongitude(), 0.0000002);
    Assert.assertEquals("DriverOnlineStatus Driver3", OnlineStatus.FREE, taxiPoi.getTaxis().get(0).getDriver()
        .getOnlineStatus());

  }

  @Test(expected = IllegalArgumentException.class)
  @Named("Test TaxiPoi Request within Radius with no Attributes")
  public void taxiPoi_withRadiusNoAttributes(){
    // GIVEN
    final LinkedList<TaxiPoi> taxiPois = new LinkedList<TaxiPoi>();
    final Long radius = 20000L;

    final Float driverRatingLimit = null;
    final String driverOnlineStatusLimit = null;

    final Long carSeatsLimit = null;
    final Long carManufactoringYearLimit = null;

    Mockito.stub(this.taxiPoiDAO.findDriversWithin(Matchers.any(Coordinate.class), Matchers.anyDouble())).toReturn(
        taxiPois);

    // WHEN
    this.controller.getTaxisWithinRadiusAndAttributes(1f, 1f, radius, driverRatingLimit, carSeatsLimit,
        driverOnlineStatusLimit, carManufactoringYearLimit);

  }

  @Test
  @Named("Test TaxiPoi Request within Radius with one Attribute")
  public void taxiPoi_withRadiusWithOneAttribute(){
    // GIVEN
    final LinkedList<TaxiPoi> taxiPois = new LinkedList<TaxiPoi>();

    final Long radius = 20000L;

    final Float driverRatingLimit = null;
    final String driverOnlineStatusLimit = null;

    final Long carSeatsLimit = 4L;
    final Long carManufactoringYearLimit = null;

    final Car car1 = Car.newBuilder().setSeats(4).setManufacturingYear(1988).build();
    final Driver driver1 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(4.5).setCar(car1)
        .setOnlineStatus(OnlineStatus.OCCUPIED).build();

    final TaxiPoi taxiPoi1 = new TaxiPoi(driver1, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now()).setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d)
    		.setSpeed(67d).build());
    taxiPois.add(taxiPoi1);

    final Car car2 = Car.newBuilder().setSeats(5).setManufacturingYear(2010).build();
    final Driver driver2 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(1.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi2 = new TaxiPoi(driver2, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now()).setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d)
    		.setSpeed(67d).build());
    taxiPois.add(taxiPoi2);

    final Car car3 = Car.newBuilder().setSeats(9).setManufacturingYear(2015).build();
    final Driver driver3 = Driver.newBuilder().setId(2L).setClient(new Client(1L, "manni", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(2.1).setCar(car3).setOnlineStatus(OnlineStatus.FREE)
        .build();

    final TaxiPoi taxiPoi3 = new TaxiPoi(driver3, DriverLocation.newBuilder().setId(driver1.getDriverId()).setDateCreated(LocalDate.now()).setCoordinate(new Coordinate(55f, 10f)).setAccuracy(10d)
    		.setSpeed(67d).build());
    taxiPois.add(taxiPoi3);

    Mockito.stub(this.taxiPoiDAO.findDriversWithin(Matchers.any(Coordinate.class), Matchers.anyDouble())).toReturn(
        taxiPois);

    // WHEN
    final TaxiPois taxiPoi = this.controller.getTaxisWithinRadiusAndAttributes(1f, 1f, radius, driverRatingLimit,
        carSeatsLimit, driverOnlineStatusLimit, carManufactoringYearLimit);

    // THEN
    Assert.assertNotNull(taxiPoi);
    Assert.assertEquals("TaxiCount", new Integer(2), taxiPoi.getTaxiCount());

  }

  @Test
  @Named("Test TaxiPoi Request with zero Radius")
  public void taxiPoi_withZeroRadius(){

    final String exceptionMessagePart = "0 km or negative";
    try {
      // WHEN, with radius 0 km not alloed
      this.controller.getTaxisWithinRadius(1f, 1f, 0L);
      Assert.fail("IllegalArgumentException expected");
    } catch (IllegalArgumentException illegalEx) {
      Assert.assertTrue("Wrong exception caught for TaxiPoiController.getTaxisWithinRadius", illegalEx.getMessage()
          .contains(exceptionMessagePart));

    }

  }

}
