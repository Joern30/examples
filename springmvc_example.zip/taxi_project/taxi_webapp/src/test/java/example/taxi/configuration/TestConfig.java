package example.taxi.configuration;

import org.mockito.Mockito;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import example.taxi.persistence.dao.HibernateTaxiPoiDAO;
import example.taxi.persistence.dao.TaxiPoiDAO;

@Configuration
public class TestConfig {

  /**
   * ################################### DataAccessObject
   * ###################################
   */

  @Bean
  public TaxiPoiDAO taxiPoiDAO(){
    TaxiPoiDAO mockTaxiDao = Mockito.mock(HibernateTaxiPoiDAO.class);
    return mockTaxiDao;
  }
}
