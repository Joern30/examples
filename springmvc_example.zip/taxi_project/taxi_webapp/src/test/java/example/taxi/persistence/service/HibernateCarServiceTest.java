package example.taxi.persistence.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;

import example.taxi.configuration.DatabaseConfiguration;
import example.taxi.domainobject.Car;
import example.taxi.domainobject.Client;
import example.taxi.domainobject.Driver;
import example.taxi.domainvalue.OnlineStatus;
import example.taxi.persistence.dao.CarDAO;
import example.taxi.persistence.dao.DriverDAO;

@ContextConfiguration(classes = { DatabaseConfiguration.class })
@Rollback
public class HibernateCarServiceTest extends AbstractTransactionalJUnit4SpringContextTests {

  @Autowired
  private CarDAO dao;

  @Autowired
  private CarService service;

  @Autowired
  private DriverDAO daoDriver;

  private Car savedCar;

  @Before
  public void setUp(){
    this.savedCar = null;
    this.dao.deleteAll();
    this.daoDriver.deleteAll();
  }

  @Test
  public void save(){
    // GIVEN

    final Car car = Car.newBuilder().setDateCreated(LocalDate.now()).setManufacturingYear(2010)
        .setLicensePlate("HH-HH 1295").setModel("E-Klasse").setSeats(4).setRating(4.3).build();
    final Driver driver = Driver.newBuilder().setClient(new Client(5l, "manni", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car).setOnlineStatus(OnlineStatus.FREE).build();

    car.addDriver(driver);

    // WHEN
    this.savedCar = this.service.create(car);

    // THEN
    Assert.assertEquals("car not equal", car, savedCar);
    Assert.assertNotNull(savedCar.getId());
    Assert.assertNotNull(savedCar.getDrivers());
    Assert.assertNotNull(savedCar.getDrivers().get(0).getClient());
  }

  @Test
  public void update(){
    // GIVEN

    final Car car = Car.newBuilder().setDateCreated(LocalDate.now()).setManufacturingYear(2010)
        .setLicensePlate("HH-HH 1295").setModel("E-Klasse").setSeats(4).setRating(4.3).build();
    final Driver driver = Driver.newBuilder().setClient(new Client(5l, "manni", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car).setOnlineStatus(OnlineStatus.FREE).build();

    car.addDriver(driver);

    // WHEN
    this.savedCar = this.service.create(car);

    // THEN
    Assert.assertEquals("car not equal", car, savedCar);
    Assert.assertNotNull(savedCar.getId());
    Assert.assertNotNull(savedCar.getDrivers());
    Assert.assertNotNull(savedCar.getDrivers().get(0).getClient());

    this.savedCar.setModel("VW Passat");

    this.savedCar = this.service.update(this.savedCar);
    Assert.assertEquals(this.savedCar.getModel(), "VW Passat");
    this.savedCar.getDrivers().get(0).setFirstName("Klaus");
    this.savedCar = this.service.update(this.savedCar);
    Assert.assertEquals(this.savedCar.getDrivers().get(0).getFirstName(), "Klaus");
  }

  @Test
  public void save1(){
    // GIVEN

    final Car car = Car.newBuilder().setDateCreated(LocalDate.now()).setManufacturingYear(2010)
        .setLicensePlate("HH-HH 1295").setModel("E-Klasse").setSeats(4).setRating(4.3).build();
    final Driver driver = Driver.newBuilder().setClient(new Client(5l, "manni", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car).setOnlineStatus(OnlineStatus.FREE).build();
    final Driver driver1 = Driver.newBuilder().setClient(new Client(5l, "manni", "12344")).setFirstName("Manfred1")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car).setOnlineStatus(OnlineStatus.FREE).build();
    final Driver driver2 = Driver.newBuilder().setClient(new Client(5l, "manni", "12344")).setFirstName("Manfred2")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car).setOnlineStatus(OnlineStatus.FREE).build();

    car.addDriver(driver);
    car.addDriver(driver1);
    car.addDriver(driver2);

    // WHEN
    this.savedCar = this.service.create(car);

    // THEN
    Assert.assertEquals("car not equal", car, savedCar);
    Assert.assertNotNull(savedCar.getId());
    Assert.assertNotNull(savedCar.getDrivers());
    Assert.assertNotNull(savedCar.getDrivers().get(0).getClient());
    Assert.assertEquals(savedCar.getDrivers().size(), 3L);
  }

  @Test
  public void deleteOne(){
    // GIVEN

    final Car car = Car.newBuilder().setDateCreated(LocalDate.now()).setManufacturingYear(2010)
        .setLicensePlate("HH-HH 1295").setModel("E-Klasse").setSeats(4).setRating(4.3).build();
    final Driver driver = Driver.newBuilder().setClient(new Client(5l, "manni", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car).setOnlineStatus(OnlineStatus.FREE).build();

    car.addDriver(driver);

    // WHEN
    this.savedCar = this.service.create(car);

    // THEN
    Assert.assertEquals("car not equal", car, savedCar);
    Assert.assertNotNull(savedCar.getId());
    Assert.assertNotNull(savedCar.getDrivers());
    Assert.assertNotNull(savedCar.getDrivers().get(0).getClient());

    Assert.assertTrue(this.daoDriver.findAll().contains(driver));
    this.service.delete(savedCar);
    Assert.assertEquals("Dao not empty", this.dao.count(), 0L);
    Assert.assertTrue(!this.daoDriver.findAll().contains(driver));
    Assert.assertTrue(this.daoDriver.count() == 0L);

    this.savedCar = null;
  }

  @Test
  public void saveWithDriverNull(){
    // GIVEN

    final Car car = Car.newBuilder().setDateCreated(LocalDate.now()).setManufacturingYear(2010)
        .setLicensePlate("HH-HH 1295").setModel("E-Klasse").setSeats(4).setRating(4.3).build();
    final Driver driver = null;

    car.addDriver(driver);

    // WHEN
    this.savedCar = this.service.create(car);

    // THEN
    Assert.assertEquals("car not equal", car, savedCar);
    Assert.assertNotNull(savedCar.getId());
    Assert.assertNotNull(savedCar.getDrivers());
    Assert.assertTrue(!savedCar.getDrivers().isEmpty());
    savedCar.getDrivers().stream().forEach((d) -> {
      Long id = d.getId();

      Assert.assertEquals("driver not equal", d, this.daoDriver.findOne(id));
      Assert.assertEquals("driver not equal", d.getCar().getId(), this.daoDriver.findOne(id).getCar().getId());

    });
  }

  @Test
  public void findOne(){
    // GIVEN
    final List<Driver> drivers = new ArrayList<Driver>();
    final Car car = Car.newBuilder().setId(1L).setManufacturingYear(2010).setLicensePlate("HH-HH 1295")
        .setModel("E-Klasse").setSeats(4).setRating(4.3).build();
    final Car car2 = Car.newBuilder().setId(1L).setManufacturingYear(2010).setLicensePlate("HH-HH 1295")
        .setModel("E-Klasse").setSeats(4).setRating(4.3).build();

    final Driver driver = Driver.newBuilder().setClient(new Client(null, "manni", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car).setOnlineStatus(OnlineStatus.FREE).build();

    // driver without car
    final Driver driver2 = Driver.newBuilder().setClient(new Client(null, "manni", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setOnlineStatus(OnlineStatus.FREE).build();
    // driver with wrong car
    final Driver driver3 = Driver.newBuilder().setClient(new Client(null, "manni", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE).build();

    drivers.add(driver);
    drivers.add(driver2);
    drivers.add(driver3);
    car.addDrivers(drivers);
    this.savedCar = this.dao.save(car);

    // WHEN
    final Car carFound = this.service.findOne(car.getId());
    // THEN
    Assert.assertNotNull(carFound);
    Assert.assertNotNull(carFound.getId());
    Assert.assertEquals(carFound.getDrivers().size(), 3L);
    Assert.assertEquals("Car not equal", car, carFound);
    carFound.getDrivers().stream().forEach((d) -> {
      final Integer compareResultExpected = 0;
      Integer compareResult;
      compareResult = Long.compare(d.getCar().getCarId(), car.getCarId());

      Assert.assertEquals("Driver's Car not equal to containing Car", compareResult, compareResultExpected);
    });
  }

  @Test
  public void saveList(){
    // GIVEN
    List<Driver> drivers = new ArrayList<Driver>();
    final List<Car> cars = new ArrayList<Car>();
    final Car car = Car.newBuilder().setId(1L).setManufacturingYear(2010).setLicensePlate("HH-HH 1295")
        .setModel("E-Klasse").setSeats(4).setRating(4.3).build();
    final Car car2 = Car.newBuilder().setId(2L).setManufacturingYear(2010).setLicensePlate("HH-HH 1295")
        .setModel("E-Klasse").setSeats(4).setRating(4.3).build();

    final Driver driver = Driver.newBuilder().setClient(new Client(null, "manni", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car).setOnlineStatus(OnlineStatus.FREE).build();

    // driver without car
    final Driver driver2 = Driver.newBuilder().setClient(new Client(null, "manni1", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setOnlineStatus(OnlineStatus.FREE).build();
    // driver with wrong car
    final Driver driver3 = Driver.newBuilder().setClient(new Client(null, "manni2", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE).build();

    final Driver driver11 = Driver.newBuilder().setClient(new Client(null, "manni3", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car).setOnlineStatus(OnlineStatus.FREE).build();

    // driver without car
    final Driver driver22 = Driver.newBuilder().setClient(new Client(null, "manni4", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setOnlineStatus(OnlineStatus.FREE).build();
    // driver with wrong car
    final Driver driver33 = Driver.newBuilder().setClient(new Client(null, "manni5", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE).build();

    car.addDriver(driver);
    car.addDriver(driver2);
    car.addDriver(driver3);
    car2.addDriver(driver11);
    car2.addDriver(driver22);
    car2.addDriver(driver33);
    cars.add(car);
    cars.add(car2);

    final List<Car> savedCars = this.service.createList(cars);

    // WHEN
    final Car carFound = dao.findOne(car.getId());
    final Car carFound1 = dao.findOne(car2.getId());

    // THEN
    Assert.assertNotNull(carFound);
    Assert.assertNotNull(carFound.getId());
    Assert.assertNotNull(carFound1);
    Assert.assertNotNull(carFound1.getId());

    Assert.assertEquals("Car not equal", car, carFound);
    carFound.getDrivers().stream().forEach((d) -> {
      final Integer compareResultExpected = 0;
      Integer compareResult;
      compareResult = Long.compare(d.getCar().getCarId(), car.getCarId());

      Assert.assertEquals("Driver's Car not equal to containing Car", compareResult, compareResultExpected);
    });
    Assert.assertEquals("Car not equal", car2, carFound1);
    carFound1.getDrivers().stream().forEach((d) -> {
      final Integer compareResultExpected = 0;
      Integer compareResult;
      compareResult = Long.compare(d.getCar().getCarId(), car2.getCarId());

      Assert.assertEquals("Driver's Car not equal to containing Car", compareResult, compareResultExpected);
    });

    Assert.assertEquals("amount of cars", this.dao.count(), 2L);
    Assert.assertEquals("amount of drivers", this.daoDriver.count(), 6L);
  }

  @Test
  public void deleteList(){
    // GIVEN
    final List<Car> cars = new ArrayList<Car>();
    final Car car = Car.newBuilder().setId(1L).setManufacturingYear(2010).setLicensePlate("HH-HH 1295")
        .setModel("E-Klasse").setSeats(4).setRating(4.3).build();
    final Car car2 = Car.newBuilder().setId(2L).setManufacturingYear(2010).setLicensePlate("HH-HH 1295")
        .setModel("E-Klasse").setSeats(4).setRating(4.3).build();

    final Driver driver = Driver.newBuilder().setClient(new Client(null, "manni", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car).setOnlineStatus(OnlineStatus.FREE).build();

    // driver without car
    final Driver driver2 = Driver.newBuilder().setClient(new Client(null, "manni1", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setOnlineStatus(OnlineStatus.FREE).build();
    // driver with wrong car
    final Driver driver3 = Driver.newBuilder().setClient(new Client(null, "manni2", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE).build();

    final Driver driver11 = Driver.newBuilder().setClient(new Client(null, "manni3", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car).setOnlineStatus(OnlineStatus.FREE).build();

    // driver without car
    final Driver driver22 = Driver.newBuilder().setClient(new Client(null, "manni4", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setOnlineStatus(OnlineStatus.FREE).build();
    // driver with wrong car
    final Driver driver33 = Driver.newBuilder().setClient(new Client(null, "manni5", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE).build();

    car.addDriver(driver);
    car.addDriver(driver2);
    car.addDriver(driver3);
    car2.addDriver(driver11);
    car2.addDriver(driver22);
    car2.addDriver(driver33);
    cars.add(car);
    cars.add(car2);

    final List<Car> savedCars = this.dao.save(cars);

    // WHEN
    final Car carFound = dao.findOne(car.getId());
    final Car carFound1 = dao.findOne(car2.getId());

    // THEN
    Assert.assertNotNull(carFound);
    Assert.assertNotNull(carFound.getId());
    Assert.assertNotNull(carFound1);
    Assert.assertNotNull(carFound1.getId());

    Assert.assertEquals("Car not equal", car, carFound);
    carFound.getDrivers().stream().forEach((d) -> {
      final Integer compareResultExpected = 0;
      Integer compareResult;
      compareResult = Long.compare(d.getCar().getCarId(), car.getCarId());

      Assert.assertEquals("Driver's Car not equal to containing Car", compareResult, compareResultExpected);
    });
    Assert.assertEquals("Car not equal", car2, carFound1);
    carFound1.getDrivers().stream().forEach((d) -> {
      final Integer compareResultExpected = 0;
      Integer compareResult;
      compareResult = Long.compare(d.getCar().getCarId(), car2.getCarId());

      Assert.assertEquals("Driver's Car not equal to containing Car", compareResult, compareResultExpected);
    });

    Assert.assertEquals("amount of cars in database", this.dao.count(), 2L);
    Assert.assertEquals("amount of drivers in database", this.daoDriver.count(), 6L);

    this.service.delete(savedCars);
    Assert.assertEquals("amount of cars in database", this.dao.count(), 0L);
    Assert.assertEquals("amount of drivers in database", this.daoDriver.count(), 0L);
  }

  @Test(expected = Exception.class)
  public void deleteNull(){
    // GIVEN
    final Long deleteId = null;
    // WHEN
    this.service.deleteById(deleteId);

    // THEN
    // expected Throwable
  }

  @Test
  public void findByIds(){
    // GIVEN
    final SortedSet<Long> driverIds = new TreeSet<Long>();
    final Car car1 = Car.newBuilder().setId(1L).setManufacturingYear(2010).setLicensePlate("HH-HH 1295")
        .setModel("E-Klasse").setSeats(4).setRating(4.3).build();
    final Driver driver1 = Driver.newBuilder().setClient(new Client(null, "manni", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car1).setOnlineStatus(OnlineStatus.FREE).build();
    this.dao.save(car1);
    driverIds.add(car1.getId());

    final Car car2 = Car.newBuilder().setId(2L).setManufacturingYear(2010).setLicensePlate("HH-HH 1292")
        .setModel("E-Klasse2").setSeats(3).setRating(4.2).build();
    final Driver driver2 = Driver.newBuilder().setClient(new Client(null, "manni", "12344")).setFirstName("Manfred2")
        .setLastName("Taximann").setSlogan("App geht die Fahrt").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE).build();
    this.dao.save(car2);
    driverIds.add(car2.getId());

    // WHEN
    final List<Car> driversFound = this.service.findByIds(driverIds);

    // THEN
    Assert.assertNotNull(driversFound);
    Assert.assertEquals("Count found driver:", driverIds.size(), driversFound.size());

    Assert.assertEquals("car 1 not in result list:", car1, driversFound.get(0));
    Assert.assertEquals("car 2 not in result list:", car2, driversFound.get(1));
    // clean database
    this.dao.deleteAll();
  }

  @Test
  public void finBydCarId(){
    // GIVEN

    final Car car1 = Car.newBuilder().setId(1L).setManufacturingYear(2010).setLicensePlate("HH-HH 1295")
        .setModel("E-Klasse").setSeats(4).setRating(4.3).build();
    final Driver driver1 = Driver.newBuilder().setId(1L).setClient(new Client(1L, "manni1", "12344"))
        .setFirstName("Manfred").setLastName("Taximann").setSlogan("App geht die Fahrt1")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(4.5).setCar(car1).setOnlineStatus(OnlineStatus.FREE)
        .build();
    this.dao.save(car1);

    final Car car2 = Car.newBuilder().setId(2L).setManufacturingYear(2010).setLicensePlate("HH-HH 1292")
        .setModel("E-Klasse2").setSeats(3).setRating(4.2).build();
    final Driver driver2 = Driver.newBuilder().setId(2L).setClient(new Client(2L, "manni2", "12344"))
        .setFirstName("Manfred2").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(4.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE)
        .build();
    this.dao.save(car2);

    // WHEN
    final Car carFound = this.service.findCarById(driver1.getCar().getCarId());
    final Car carFound1 = this.service.findCarById(driver2.getCar().getCarId());

    // THEN
    Assert.assertNotNull(carFound);
    Assert.assertNotNull(carFound.getId());
    Assert.assertNotNull(carFound1);
    Assert.assertNotNull(carFound1.getId());

    Assert.assertEquals("CarId", driver1.getCar().getCarId(), carFound.getCarId());
    Assert.assertEquals("CarId", driver2.getCar().getCarId(), carFound1.getCarId());
  }

  @Test
  public void findByDriverWithReassignment(){
    // GIVEN
    final Client client1 = new Client(1L, "manni1", "12344");
    final Car car1 = Car.newBuilder().setId(1L).setManufacturingYear(2010).setLicensePlate("HH-HH 1295")
        .setModel("E-Klasse").setSeats(4).setRating(4.3).build();
    final Driver driver1 = Driver.newBuilder().setId(1L).setClient(client1).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car1).setOnlineStatus(OnlineStatus.FREE).build();

    // detached
    final Driver driver11 = Driver.newBuilder().setId(11L).setClient(client1).setFirstName("Manfred11")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car1).setOnlineStatus(OnlineStatus.FREE).build();

    car1.addDriver(driver1);
    Car car1Saved = this.dao.save(car1);

    final Car car2 = Car.newBuilder().setId(2L).setManufacturingYear(2010).setLicensePlate("HH-HH 1292")
        .setModel("E-Klasse2").setSeats(3).setRating(4.2).build();
    final Driver driver2 = Driver.newBuilder().setId(2L).setClient(new Client(2L, "manni2", "12344"))
        .setFirstName("Manfred2").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(4.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE)
        .build();
    car2.addDriver(driver2);
    Car car2Saved = this.dao.save(car2);
    // WHEN
    Car carFound = dao.findByCarId(driver1.getCar().getCarId());
    Car carFound1 = dao.findByCarId(driver2.getCar().getCarId());

    Assert.assertEquals(car1Saved, carFound);
    Assert.assertEquals(car2Saved, carFound1);

    // THEN
    // car1
    Assert.assertNotNull(carFound);
    Assert.assertNotNull(carFound.getId());
    Assert.assertTrue(carFound.getDrivers().size() == 1);
    // car2
    Assert.assertNotNull(carFound1);
    Assert.assertNotNull(carFound1.getId());
    Assert.assertTrue(carFound1.getDrivers().size() == 1);

    Assert.assertEquals("CarId", driver1.getCar().getCarId(), carFound.getCarId());
    Assert.assertEquals("CarId", driver2.getCar().getCarId(), carFound1.getCarId());

    // save driver11 to rep because merge is corrupt
    final Driver driverSave = this.daoDriver.save(driver11);
    carFound1.addDriverToDriverList(driverSave);
    final Car carFound1Save = this.service.create(carFound1);

    // Assert.assertTrue(carFound1Save.getDrivers().size() == 2);
    carFound1 = dao.findOne(carFound1Save.getId());
    this.daoDriver.count();

    carFound1 = this.service.findCarByDriver(driver11);
    carFound1 = this.service.findCarByDriver(driver2);
    Assert.assertEquals(car2, carFound1);
    // one more driver in the driver's list of car2
    Assert.assertTrue(carFound1.getDrivers().size() == 2);

    Assert.assertEquals("CarId car2", carFound1.getCarId(), driver11.getCar().getCarId());
    Assert.assertNotEquals("CarId car1", carFound.getCarId(), driver11.getCar().getCarId());
    Assert.assertEquals("CarId car1", carFound.getCarId(), driver1.getCar().getCarId());

    // car1 ?
    carFound = dao.findOne(car1.getId());

    Assert.assertTrue(!carFound.getDrivers().isEmpty());
    Assert.assertTrue(carFound.getDrivers().size() == 1);
  }

  @Test
  public void findByDriver(){
    // GIVEN
    final Client client1 = new Client(1L, "manni1", "12344");
    final Car car1 = Car.newBuilder().setId(1L).setManufacturingYear(2010).setLicensePlate("HH-HH 1295")
        .setModel("E-Klasse").setSeats(4).setRating(4.3).build();
    final Driver driver1 = Driver.newBuilder().setId(1L).setClient(client1).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car1).setOnlineStatus(OnlineStatus.FREE).build();
    car1.addDriver(driver1);
    this.dao.save(car1);

    final Car car2 = Car.newBuilder().setId(2L).setManufacturingYear(2010).setLicensePlate("HH-HH 1292")
        .setModel("E-Klasse2").setSeats(3).setRating(4.2).build();
    final Driver driver2 = Driver.newBuilder().setId(2L).setClient(new Client(2L, "manni2", "12344"))
        .setFirstName("Manfred2").setLastName("Taximann").setSlogan("App geht die Fahrt")
        .setPictureUrl("http://www.manni.de/bild1.jpg").setRating(4.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE)
        .build();
    car2.addDriver(driver2);
    this.dao.save(car2);
    // WHEN
    Car carFound = this.service.findCarByDriver(driver1);
    Car carFound1 = this.service.findCarByDriver(driver2);

    // THEN
    Assert.assertNotNull(carFound);
    Assert.assertNotNull(carFound.getId());

    Assert.assertEquals("CarId", carFound.getCarId(), driver1.getCar().getCarId());
    Assert.assertEquals("CarId", carFound1.getCarId(), driver2.getCar().getCarId());
  }

  @After
  public void cleanUp(){
    if (this.savedCar != null) {
      Assert.assertTrue(this.dao.count() > 0);
      this.dao.delete(savedCar);
      Assert.assertTrue(this.dao.count() == 0);
    }
  }

  @Test
  public void saveList1(){
    // GIVEN
    List<Driver> drivers = new ArrayList<Driver>();
    final List<Car> cars = new ArrayList<Car>();
    final Car car = Car.newBuilder().setId(1L).setManufacturingYear(2010).setLicensePlate("HH-HH 1295")
        .setModel("E-Klasse").setSeats(4).setRating(4.3).build();
    final Car car2 = Car.newBuilder().setId(2L).setManufacturingYear(2010).setLicensePlate("HH-HH 1295")
        .setModel("E-Klasse").setSeats(4).setRating(4.3).build();

    final Driver driver = Driver.newBuilder().setClient(new Client(null, "manni", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car).setOnlineStatus(OnlineStatus.FREE).build();

    // driver without car
    final Driver driver2 = Driver.newBuilder().setClient(new Client(null, "manni1", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setOnlineStatus(OnlineStatus.FREE).build();
    // driver with wrong car
    final Driver driver3 = Driver.newBuilder().setClient(new Client(null, "manni2", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE).build();

    final Driver driver11 = Driver.newBuilder().setClient(new Client(null, "manni3", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car).setOnlineStatus(OnlineStatus.FREE).build();

    // driver without car
    final Driver driver22 = Driver.newBuilder().setClient(new Client(null, "manni4", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setOnlineStatus(OnlineStatus.FREE).build();
    // driver with wrong car
    final Driver driver33 = Driver.newBuilder().setClient(new Client(null, "manni5", "12344")).setFirstName("Manfred")
        .setLastName("Taximann").setSlogan("App geht die Fahrt1").setPictureUrl("http://www.manni.de/bild1.jpg")
        .setRating(4.5).setCar(car2).setOnlineStatus(OnlineStatus.FREE).build();

    drivers.add(driver);
    drivers.add(driver2);
    drivers.add(driver3);
    car.addDrivers(drivers);
    drivers = new ArrayList<Driver>();
    drivers.add(driver11);
    drivers.add(driver22);
    drivers.add(driver33);
    car2.addDrivers(drivers);

    cars.add(car);
    cars.add(car2);

    final List<Car> savedCars = this.service.createList(cars);

    // WHEN
    final Car carFound = dao.findOne(car.getId());
    final Car carFound1 = dao.findOne(car2.getId());

    // THEN
    Assert.assertNotNull(carFound);
    Assert.assertNotNull(carFound.getId());
    Assert.assertNotNull(carFound1);
    Assert.assertNotNull(carFound1.getId());

    Assert.assertEquals("Car not equal", car, carFound);
    carFound.getDrivers().stream().forEach((d) -> {
      final Integer compareResultExpected = 0;
      Integer compareResult;
      compareResult = Long.compare(d.getCar().getCarId(), car.getCarId());

      Assert.assertEquals("Driver's Car not equal to containing Car", compareResult, compareResultExpected);
    });
    Assert.assertEquals("Car not equal", car2, carFound1);
    carFound1.getDrivers().stream().forEach((d) -> {
      final Integer compareResultExpected = 0;
      Integer compareResult;
      compareResult = Long.compare(d.getCar().getCarId(), car2.getCarId());

      Assert.assertEquals("Driver's Car not equal to containing Car", compareResult, compareResultExpected);
    });

    Assert.assertEquals("amount of cars", this.dao.count(), 2L);
    Assert.assertEquals("amount of drivers", this.daoDriver.count(), 6L);
  }
}
