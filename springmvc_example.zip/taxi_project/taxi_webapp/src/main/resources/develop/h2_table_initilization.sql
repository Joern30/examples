drop table car if exists;
drop table driver if exists;
drop table drivers if exists;

DROP SEQUENCE IF EXISTS "BASE_SEQ";

 CREATE SEQUENCE "BASE_SEQ" START WITH 0 INCREMENT BY 2;

 CREATE TABLE "CAR" (ID BIGINT DEFAULT (NEXT VALUE FOR "BASE_SEQ") not null primary key,
        DATE_CREATED DATE,DATE_MODIFIED DATE,
        VERSION INT,
        LICENSE_PLATE VARCHAR(255),
        manufacturing_year INT,
        car_model VARCHAR(255),
        car_rating FLOAT ,
        car_seats INT not null
    );
      CREATE TABLE "DRIVER" (
    	ID BIGINT DEFAULT (NEXT VALUE FOR "BASE_SEQ") not null primary key,
        DATE_CREATED DATE,
        DATE_MODIFIED DATE,
        VERSION INT,
        DRIVER_NO BIGINT,
        car_id BIGINT,
        pass_word VARCHAR(255),
        user_name VARCHAR(255),
        first_name VARCHAR(255),
        last_name VARCHAR(255),
        online_status INT,
        phone_number VARCHAR(255),
        photo VARCHAR(255),
        driver_rating FLOAT,
        parole VARCHAR(255),
        FOREIGN KEY (car_id) REFERENCES CAR(id));
    
    ALTER TABLE "DRIVER"
    ADD FOREIGN KEY (car_id) 
    REFERENCES public.CAR(id) ;