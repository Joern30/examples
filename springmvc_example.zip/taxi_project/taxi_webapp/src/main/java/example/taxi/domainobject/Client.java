package example.taxi.domainobject;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Transient;

import com.google.common.base.Preconditions;

@Embeddable
public class Client {
  private Long id;
  private String username;
  private String password;

  protected Client() {
    this.id = null;
    this.username = null;
    this.password = null;
  }

  public Client(final Long id, final String username, final String password) {
    this.setId(id);
    this.username = username;
    this.password = password;
  }

  @Transient
  public Long getId(){
    return this.id;
  }

  public void setId(final Long id){
    Preconditions.checkArgument(id == null || id > 0);
    this.id = id;
  }

  @Column(name = "USER_NAME")
  public String getUsername(){
    return this.username;
  }

  @Column(name = "PASS_WORD")
  public String getPassword(){
    return this.password;
  }

  public void setUsername(String username){
    this.username = username;
  }

  public void setPassword(String password){
    this.password = password;
  }

}
