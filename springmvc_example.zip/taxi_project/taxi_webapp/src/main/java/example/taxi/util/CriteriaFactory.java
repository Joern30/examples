package example.taxi.util;

import java.util.Map;

/**
 * 
 * CriteriaFactory is a generic interface implemented by
 * {@link CriteriaFactoryImpl_old}
 *
 * @param <T>
 * @param <K>
 * @param <V>
 */

public interface CriteriaFactory<T, K, V> {

  /**
   * processes Criterias on an given object
   * 
   * @param taxis
   *          object to filter (e. g. a list)
   * @param criterias
   *          a map of criterias
   * @return filtered objEct
   */
  T processCriterias(T taxis, Map<K, V> criterias);
}
