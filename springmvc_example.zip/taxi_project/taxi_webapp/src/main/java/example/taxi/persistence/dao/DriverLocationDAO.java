package example.taxi.persistence.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import example.taxi.domainobject.Driver;
import example.taxi.domainobject.DriverLocation;

public interface DriverLocationDAO extends JpaRepository<DriverLocation, Long>,JpaSpecificationExecutor<DriverLocation> {
	  @Query("SELECT dr FROM DriverLocation dr WHERE dr.driverId = :driverId")
	  DriverLocation findByDriverId(@Param("driverId") final Long driverId);

	  @Query("SELECT dr FROM DriverLocation dr WHERE dr.driverId = :#{#driver.driverId}")
	  DriverLocation find(@Param("driver") final Driver driver);

}
