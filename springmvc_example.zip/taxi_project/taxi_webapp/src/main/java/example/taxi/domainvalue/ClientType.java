package example.taxi.domainvalue;

public enum ClientType {
  PASSENGER,
  DRIVER
}
