package example.taxi.domainvalue;

import example.taxi.util.CarManufactoredStrategy;
import example.taxi.util.CarSeatsStrategy;
import example.taxi.util.CriteriaStrategy;
import example.taxi.util.DriverOnlineStatusStrategy;
import example.taxi.util.DriverRatingStrategy;

public enum CriteriaStrategyOrder {
  DRIVERRATING(1, new DriverRatingStrategy()), DRIVERONLINESTATUS(2, new DriverOnlineStatusStrategy()), CARSEATS(3,
      new CarSeatsStrategy()), CARMANUFACTORED(4, new CarManufactoredStrategy());
  private Integer index;
  private CriteriaStrategy strategy;

  private CriteriaStrategyOrder(Integer index, CriteriaStrategy strategy) {
    this.index = index;
    this.strategy = strategy;
  }

  public CriteriaStrategy getCriteriaStrategy(){
    return this.strategy;
  }

  public Integer getIndex(){
    return this.index;
  }

}
