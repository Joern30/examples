package example.taxi.util.filters;

import java.util.List;

/**
 * 
 * Interface for TaxiPoi filters implemented f. e. by link{CarSeatsFilter}
 *
 */

public interface TaxiCriteria<T> {

  /**
   * 
   * @param taxis
   * @return a filtered list
   */
  public List<T> meetCriteria(List<T> taxis);
}