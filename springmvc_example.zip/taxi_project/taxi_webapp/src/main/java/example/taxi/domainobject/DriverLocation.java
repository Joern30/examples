package example.taxi.domainobject;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name = "Drivers")
public class DriverLocation extends AbstractEntity implements Serializable {
  /**
   * version id
   */
  private static final long serialVersionUID = 1L;
  private Long driverId;
  private Coordinate coordinate;
  private Double speed;
  private Double accuracy;

  protected DriverLocation() {
    super();
    this.driverId = null;
    this.coordinate = null;
    this.speed = null;
    this.accuracy = null;
  }

  protected DriverLocation(final Long id, final LocalDate localDate, final Coordinate coordinate, final Double accuracy, final Double speed) {
    super(localDate);
    this.driverId = id;
    this.coordinate = coordinate;
    this.accuracy = accuracy;
    this.speed = speed;
  }

  @Column(name = "DRIVER_ID")
  public Long getDriverId(){
    return this.driverId;
  }

  @Column(name = "DRIVER_SPEED")
  public Double getSpeed(){
    return this.speed;
  }

  @Column(name = "ACCURACY")
  public Double getAccuracy(){
    return this.accuracy;
  }

  @Embedded
  @Lob
  public Coordinate getCoordinate(){
    return this.coordinate;
  }

  @Override
  public int hashCode(){
    final int prime = 31;
    int result = 1;
    result = prime * result + ((accuracy == null) ? 0 : accuracy.hashCode());
    result = prime * result + ((coordinate == null) ? 0 : coordinate.hashCode());
    result = prime * result + ((driverId == null) ? 0 : driverId.hashCode());
    result = prime * result + ((speed == null) ? 0 : speed.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj){
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    DriverLocation other = (DriverLocation)obj;
    if (accuracy == null) {
      if (other.accuracy != null)
        return false;
    } else if (!accuracy.equals(other.accuracy))
      return false;
    if (coordinate == null) {
      if (other.coordinate != null)
        return false;
    } else if (!coordinate.equals(other.coordinate))
      return false;
    if (driverId == null) {
      if (other.driverId != null)
        return false;
    } else if (!driverId.equals(other.driverId))
      return false;
    if (speed == null) {
      if (other.speed != null)
        return false;
    } else if (!speed.equals(other.speed))
      return false;
    return true;
  }

  public void setDriverId(Long driverId){
    this.driverId = driverId;
  }

  public void setCoordinate(Coordinate coordinate){
    this.coordinate = coordinate;
  }

  public void setSpeed(Double speed){
    this.speed = speed;
  }

  public void setAccuracy(Double accuracy){
    this.accuracy = accuracy;
  }
  public static Builder newBuilder(){
	    return new Builder();
	  }

	  public static class Builder {

		  private Long Id;
		  private Coordinate coordinate;
		  private Double speed;
		  private Double accuracy;
		  private LocalDate dateCreated;

	    public DriverLocation build(){
	      return new DriverLocation(this.Id, this.dateCreated, this.coordinate,
	    	      this.accuracy, this.speed);
	    }
	    public Long getId(){
	      return this.Id;
	    }

	    public Builder setId(final Long id){
	      this.Id = id;
	      return this;
	    }

	    public Coordinate getCoordinate(){
	      return this.coordinate;
	    }

	    public Builder setCoordinate(final Coordinate coordinate){
	      this.coordinate = coordinate;
	      return this;
	    }

	    public Double getSpeed(){
	      return this.speed;
	    }

	    public Builder setSpeed(final Double speed){
	      this.speed = speed;
	      return this;
	    }

	    public Double getAccuracy(){
	      return this.accuracy;
	    }

	    public Builder setAccuracy(final Double accuracy){
	      this.accuracy = accuracy;
	      return this;
	    }

	    public LocalDate getDateCreated(){
	      return this.dateCreated;
	    }

	    public Builder setDateCreated(final LocalDate dateCreated){
	      this.dateCreated = dateCreated;
	      return this;
	    }
	  }

}
