package example.taxi.util;

import example.taxi.domainobject.TaxiPoi;
import example.taxi.util.filters.CarSeatsFilter;
import example.taxi.util.filters.TaxiCriteria;

/**
 * 
 * CarSeatsStrategy creates link{CarSeatsFilter} objects
 *
 */

public class CarSeatsStrategy implements CriteriaStrategy {

  /**
   * implementation of link{CriteriaStrategy} interface
   */
  @Override
  public TaxiCriteria<TaxiPoi> createCriteria(String criteria){

    return new CarSeatsFilter(Integer.parseInt(criteria));
  }
}
