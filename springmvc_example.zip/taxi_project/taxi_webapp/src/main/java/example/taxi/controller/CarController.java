package example.taxi.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import example.taxi.domainobject.Car;
import example.taxi.persistence.service.CarService;

/**
 * @author Jörn Scheffler
 */
@RestController
public class CarController {

  private static final Logger LOGGER = LoggerFactory.getLogger(CarController.class);

  @Autowired
  private CarService carService;
  @RequestMapping(value = "/v1/addCar", method = RequestMethod.POST)
  public Car addCar(@RequestBody Car car){
    LOGGER.debug("Received car: {}", car);
    return this.carService.create(car);
  }
}
