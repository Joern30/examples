package example.taxi.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan({ "example.taxi.controller" })
public class ControllerConfig {

  public ControllerConfig() {
    super();
    System.out.println("ControllerConfig started with componentscan");
  }

}