package example.taxi.persistence.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.google.common.base.Preconditions;

import example.taxi.domainobject.Coordinate;
import example.taxi.domainobject.Driver;
import example.taxi.domainobject.DriverLocation;
import example.taxi.domainobject.TaxiPoi;

public class HibernateTaxiPoiDAO implements TaxiPoiDAO {

  private final HibernateDriverDAO driverDAO;
  private final HibernateDriverLocationDAO driverLocationDAO;

  @Autowired
  public HibernateTaxiPoiDAO() {
    this.driverDAO = new HibernateDriverDAO();
    this.driverLocationDAO = new HibernateDriverLocationDAO();

  }

  /**
   * Find drivers in box defined by {@code upperLeftCoordinate} and
   * {@code lowerRightCoordinate}
   * 
   * @param upperLeftCoordinate
   * @param lowerRightCoordinate
   * @return drivers within
   */
  @Override
  public List<TaxiPoi> findDriversWithin(final Coordinate upperLeftCoordinate, final Coordinate lowerRightCoordinate){

    final List<DriverLocation> driverLocations = this.driverLocationDAO.findWithin(upperLeftCoordinate,
        lowerRightCoordinate);
    final Map<Long, DriverLocation> driverLocationMap = this.toDriverLocationMap(driverLocations);
    final List<Driver> drivers = this.driverDAO.find(driverLocationMap.keySet());

    return this.makeTaxiPoiList(drivers, driverLocationMap);

  }

  /**
   * Find drivers in radius defined by {@code upperLeftCoordinate} and
   * {@code radius}
   * 
   * @param upperLeftCoordinate
   * @param radius
   * @return drivers within
   */
  @Override
  public List<TaxiPoi> findDriversWithin(final Coordinate upperLeftCoordinate, final double radius){

    final List<DriverLocation> driverLocations = this.driverLocationDAO.findWithin(upperLeftCoordinate, radius);
    final Map<Long, DriverLocation> driverLocationMap = this.toDriverLocationMap(driverLocations);
    final List<Driver> drivers = this.driverDAO.find(driverLocationMap.keySet());

    return this.makeTaxiPoiList(drivers, driverLocationMap);

  }

  private List<TaxiPoi> makeTaxiPoiList(final List<Driver> drivers, final Map<Long, DriverLocation> driverLocationMap){
    final ArrayList<TaxiPoi> result = new ArrayList<TaxiPoi>(drivers.size());
    for (final Driver driver : drivers) {
      final DriverLocation driverLocation = driverLocationMap.get(driver.getId());
      Preconditions.checkArgument(driver.getId().equals(driverLocation.getDriverId()));
      result.add(new TaxiPoi(driver, driverLocation));
    }
    return result;
  }

  private Map<Long, DriverLocation> toDriverLocationMap(final List<DriverLocation> driverLocations){
    final Map<Long, DriverLocation> result = new HashMap<Long, DriverLocation>(driverLocations.size());

    for (final DriverLocation driverLocation : driverLocations) {
      result.put(driverLocation.getId(), driverLocation);
    }

    return result;
  }

}
