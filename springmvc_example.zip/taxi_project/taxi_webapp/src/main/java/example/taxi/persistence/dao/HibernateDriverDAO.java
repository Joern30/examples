package example.taxi.persistence.dao;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import example.taxi.domainobject.Client;
import example.taxi.domainobject.Driver;

public class HibernateDriverDAO extends HibernateDAO<Driver, Long> {

  public HibernateDriverDAO() {
    super(Driver.class, null);
  }

  Driver findByUsername(final String username){

    final Criteria criteria = this.createCriteria();

    criteria.add(Restrictions.eq("client.username", username).ignoreCase());

    return (Driver)criteria.uniqueResult();
  }

  public Driver find(final Client client){
    final Criteria criteria = this.createCriteria();

    criteria.add(Restrictions.eq("client.id", client.getId()));

    return (Driver)criteria.uniqueResult();
  }

  @SuppressWarnings("unchecked")
  public List<Driver> find(final Collection<Long> driverIds){
    if (driverIds.isEmpty()) {
      return Collections.EMPTY_LIST;
    }

    final Criteria criteria = this.createCriteria();

    criteria.add(Restrictions.in("id", driverIds));

    criteria.addOrder(Order.desc("id"));

    return criteria.list();
  }

}
