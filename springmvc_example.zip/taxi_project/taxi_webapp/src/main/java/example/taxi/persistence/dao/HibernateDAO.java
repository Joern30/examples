package example.taxi.persistence.dao;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class HibernateDAO<T1, T2> {


  public Session getCurrentSession(){
    return null;
  }


  public HibernateDAO(final Class<T1> clazz, final SessionFactory sessionFactory) {

  }

  protected Criteria createCriteria(){

    return null;

  }

  public void save(T1 obj){

  }

}
