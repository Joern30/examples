package example.taxi.util.filters;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import example.taxi.domainobject.TaxiPoi;

/**
 * CarManufactoredFilter filters cars from a list of TaxiPoi objects with an
 * manufactoring year not older than a given year.
 * 
 */

public class CarManufactoredFilter implements TaxiCriteria<TaxiPoi> {

  private Integer limitYear;

  public CarManufactoredFilter() {

  }

  public CarManufactoredFilter(final Integer limitYear) {
    this.limitYear = limitYear;
  }

  /**
   * implementation of link{TaxiCriteria} interface
   */
  @Override
  public List<TaxiPoi> meetCriteria(List<TaxiPoi> taxis){
    LocalDateTime now = LocalDateTime.now();
    int currentYear = now.getYear();

    List<TaxiPoi> filteredDrivers = new ArrayList<TaxiPoi>();
    for (TaxiPoi taxi : taxis) {
      // add taxi if the difference between now and manufactoring year is
      // less/equal input year
      if ((currentYear - (taxi.getDriver().getCar().getManufacturingYear())) <= limitYear) {
        filteredDrivers.add(taxi);
      }
    }
    return filteredDrivers;
  }
}