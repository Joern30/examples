package example.taxi.domainobject;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.SequenceGenerator;
import javax.persistence.Version;

import org.hibernate.annotations.Generated;
import org.hibernate.annotations.GenerationTime;

@MappedSuperclass
public abstract class AbstractEntity {

  private Long id;

  @Version
  protected Integer version;

  private LocalDate dateCreated;

  private LocalDate dateModified;

  public AbstractEntity() {
    this.dateCreated = null;
    this.dateModified = null;
    this.id = null;

  }

  public AbstractEntity(final LocalDate localDate) {
    // super(id, dateCreated);
    this.dateCreated = localDate;
    this.dateModified = null;

  }

  @Id
  @SequenceGenerator(name = "BASE_SEQ_GENERATOR", sequenceName = "BASE_SEQ", initialValue = 0, allocationSize = 2)
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "BASE_SEQ_GENERATOR")
  @Column(name = "id", insertable = false, updatable = false)
  public Long getId(){
    return id;
  }

  public void setId(Long id){
    this.id = id;
  }

  public LocalDate getDateCreated(){
    return dateCreated;
  }

  @Column(name = "date_modified", updatable = false, insertable = false)
  @Generated(GenerationTime.ALWAYS)
  public LocalDate getDateModified(){
    return this.dateModified;
  }

  public void setDateModified(LocalDate dateModified){
    this.dateModified = dateModified;
  }

  public void setDateCreated(LocalDate dateCreated){
    this.dateCreated = dateCreated;
  }

}
