package example.taxi.util;

import example.taxi.domainobject.TaxiPoi;
import example.taxi.util.filters.TaxiCriteria;

/**
 * 
 * CriteriaStrategy interface for several Strategies implemented by
 * {@link DriverOnlineStatusStrategy}
 *
 */
public interface CriteriaStrategy {

  /**
   * 
   * @param criteria
   *          to use inside the TaxiCriteria object to filter with
   * @return a new created TaxiCriteria object
   */
  public TaxiCriteria<TaxiPoi> createCriteria(final String criteria);

}
