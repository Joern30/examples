package example.taxi.persistence.dao;

import java.util.Collection;
import java.util.List;

public interface DAO<DRIVER, LONG> {

  List<DRIVER> find(Collection<LONG> ids);

}
