package example.taxi.persistence.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;

import example.taxi.domainobject.Car;
import example.taxi.domainobject.Driver;
import example.taxi.persistence.dao.CarDAO;
import example.taxi.persistence.service.CarService;
import example.taxi.persistence.service.common.AbstractService;

@Service
@Transactional
public class CarServiceImpl extends AbstractService<Car> implements CarService {

  @Autowired
  private CarDAO dao;

  public CarServiceImpl() {
    super();
  }

  // API

  @Override
  protected PagingAndSortingRepository<Car, Long> getDao(){
    return this.dao;
  }

  // custom methods

  @Override
  @Transactional(readOnly = true)
  public List<Car> findAll(){
    return Lists.newArrayList(getDao().findAll());
  }

  @Override
  @Transactional(readOnly = true)
  public Car findCarById(final Long carId){
    return this.dao.findByCarId(carId);
  }

  @Override
  @Transactional(readOnly = true)
  public Car findCarByDriver(final Driver driver){
    return this.dao.find(driver);
  }

  @Override
  @Transactional(readOnly = true)
  public List<Car> findByIds(Iterable<Long> ids){
    return this.dao.findAll(ids);
  }

}
