package example.taxi.domainobject;


public class TaxiPoi {

  private final Driver driver;
  private final DriverLocation driverLocation;

  protected TaxiPoi() {
    this.driver = null;
    this.driverLocation = null;
  }

  public TaxiPoi(final Driver driver, final DriverLocation driverLocation) {
    this.driver = driver;
    this.driverLocation = driverLocation;
  }


  public Driver getDriver() {
    return this.driver;
  }

  public DriverLocation getDriverLocation() {
    return this.driverLocation;
  }

}
