package example.taxi.domainobject;

import java.util.List;

/**
 * wrapper class for taxis
 * 
 * @author Jörn
 *
 */
public class TaxiPois {

  private final List<TaxiPoi> taxis;

  protected TaxiPois() {
    this.taxis = null;
  }

  public TaxiPois(final List<TaxiPoi> taxis) {
    this.taxis = taxis;
  }

  public List<TaxiPoi> getTaxis(){
    return this.taxis;
  }

  public Integer getTaxiCount(){
    return this.taxis.size();
  }

}
