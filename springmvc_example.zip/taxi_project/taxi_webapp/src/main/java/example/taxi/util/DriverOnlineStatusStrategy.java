package example.taxi.util;

import example.taxi.domainobject.TaxiPoi;
import example.taxi.util.filters.DriverOnlineStatusFilter;
import example.taxi.util.filters.TaxiCriteria;

/**
 * 
 * DriverOnlineStatusStrategy creates link{DriverOnlineStatusFilter} objects
 *
 */
public class DriverOnlineStatusStrategy implements CriteriaStrategy {

  /**
   * implementation of link{CriteriaStrategy}
   */
  @Override
  public TaxiCriteria<TaxiPoi> createCriteria(String criteria){

    return new DriverOnlineStatusFilter(criteria);
  }
}
