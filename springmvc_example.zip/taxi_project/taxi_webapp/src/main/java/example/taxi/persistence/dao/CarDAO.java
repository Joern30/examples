package example.taxi.persistence.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import example.taxi.domainobject.Car;
import example.taxi.domainobject.Driver;

public interface CarDAO extends JpaRepository<Car, Long>, JpaSpecificationExecutor<Car> {

  @Query("SELECT c FROM Car c WHERE c.carId = :carId")
  Car findByCarId(@Param("carId") final Long carId);

  @Query("SELECT c FROM Car c WHERE c.carId = :#{#driver.car.carId}")
  Car find(@Param("driver") final Driver driver);

}
