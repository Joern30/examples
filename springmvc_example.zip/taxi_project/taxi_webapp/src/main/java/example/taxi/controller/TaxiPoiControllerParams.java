package example.taxi.controller;

import java.util.Map;

/**
 * @author Jörn Scheffler
 */
public class TaxiPoiControllerParams {

  public TaxiPoiControllerParams(String radiusInMeter, String driverRating, String carSeats, String driverOnlineStatus,
      String carManufactoringYear) {
    super();
    this.radiusInMeter = radiusInMeter;
    this.driverRating = driverRating;
    this.carSeats = carSeats;
    this.driverOnlineStatus = driverOnlineStatus;
    this.carManufactoringYear = carManufactoringYear;
  }

  private String radiusInMeter;
  private String driverRating;
  private String carSeats;
  private String driverOnlineStatus;
  private String carManufactoringYear;
  private Map<Integer, String> criteriaMap;

  public String getRadiusInMeter(){
    return radiusInMeter;
  }

  public String getDriverRating(){
    return driverRating;
  }

  public String getCarSeats(){
    return carSeats;
  }

  public String getDriverOnlineStatus(){
    return driverOnlineStatus;
  }

  public String getCarManufactoringYear(){
    return carManufactoringYear;
  }

  @Override
  public String toString(){
    return "TaxiPoiControllerParams [radiusInMeter=" + radiusInMeter + ", driverRating=" + driverRating + ", carSeats="
        + carSeats + ", driverOnlineStatus=" + driverOnlineStatus + ", carManufactoringYear=" + carManufactoringYear
        + "]";
  }

  public void setCriteriaMap(Map<Integer, String> criteriaMap){
    this.criteriaMap = criteriaMap;

  }

  public Map<Integer, String> getCriteriaMap(){
    return criteriaMap;
  }

}
