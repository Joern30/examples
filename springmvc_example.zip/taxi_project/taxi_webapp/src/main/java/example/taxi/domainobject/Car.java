package example.taxi.domainobject;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@Entity
@Table(name = "Car")
public class Car extends AbstractEntity implements Serializable {

  /**
   * version id
   */
  private static final long serialVersionUID = 3242181984742488967L;

  private Long carId;
  private int manufacturingYear;
  private String licensePlate;
  private String model;
  private int seats;
  private double rating;
  @JsonSerialize(using = DriverListSerializer.class)
  private List<Driver> drivers;

  protected Car() {
    super();
    this.drivers = new CopyOnWriteArrayList<Driver>();
    this.carId = null;
    this.manufacturingYear = 0;
    this.licensePlate = null;
    this.model = null;
    this.seats = 0;
    this.rating = 0;
  }

  protected Car(final Long id, final LocalDate dateCreated, final Integer manufacturingYear, final String licensePlate,
      final String model, final Integer seats, final Double rating) {
    super(dateCreated);
    this.drivers = new CopyOnWriteArrayList<Driver>();
    this.carId = id;
    this.manufacturingYear = manufacturingYear;
    this.licensePlate = licensePlate;
    this.model = model;
    this.seats = seats;
    this.rating = rating;
  }

  @OneToMany(mappedBy = "car", targetEntity = Driver.class, fetch = FetchType.EAGER, cascade = CascadeType.ALL)
  public List<Driver> getDrivers(){
    // return Collections.unmodifiableList(this.drivers);
    return this.drivers;
  }

  public void setDrivers(final List<Driver> drivers){

    this.drivers = drivers;
  }

  // used by driver.setCar()
  public void internalAddDriver(Driver driver){
    this.drivers.add(driver);
  }

  // used by driver.setCar()
  public void internalRemoveDriver(Driver driver){
    this.drivers.remove(driver);
  }

  public void removeDriver(final Driver driver){
    if (driver != null) {
      driver.setCar(null);
    }
  }

  public void addDriver(final Driver driver){
    Driver localDriver = driver;
    if (localDriver == null) {

      localDriver = Driver.newBuilder().setCar(this).build();
    }
    adjustDriver(localDriver);
  }

  public void addDrivers(final List<Driver> drivers){
    this.drivers.clear();
    drivers.stream().forEach(s -> {
      if (s == null) {

        s = Driver.newBuilder().setCar(this).build();
      }

      s.setCar((this));
    });
    this.drivers = drivers;

  }

  public void addDriverToDriverList(final Driver driver){
    driver.addCar(this);
    this.drivers.add(driver);

  }

  private void adjustDriver(final Driver driver){
    if (driver != null) {

      driver.setCar(this);
    }
  }

  @Column(name = "CAR_NO")
  public Long getCarId(){
    return carId;
  }

  public void setCarId(Long id){
    this.carId = id;
  }

  @Column(name = "LICENSE_PLATE")
  public String getLicensePlate(){
    return this.licensePlate;
  }

  @Column(name = "CAR_MODEL")
  public String getModel(){
    return this.model;
  }

  @Column(name = "MANUFACTORING_YEAR")
  public int getManufacturingYear(){
    return this.manufacturingYear;
  }

  @Column(name = "CAR_SEATS")
  public int getSeats(){
    return this.seats;
  }

  @Column(name = "CAR_RATING")
  public double getRating(){
    return this.rating;
  }

  public static Builder newBuilder(){
    return new Builder();
  }

  public static class Builder {

    private Long id;
    private int manufacturingYear;
    private String licensePlate;
    private String model;
    private int seats;
    private double rating;
    private LocalDate dateCreated;

    public Car build(){
      return new Car(this.id, this.dateCreated, this.manufacturingYear, this.licensePlate, this.model, this.seats,
          this.rating);
    }

    public Long getId(){
      return this.id;
    }

    public Builder setId(final Long id){
      this.id = id;
      return this;
    }

    public int getManufacturingYear(){
      return this.manufacturingYear;
    }

    public Builder setManufacturingYear(final int manufacturingYear){
      this.manufacturingYear = manufacturingYear;
      return this;
    }

    public String getLicensePlate(){
      return this.licensePlate;
    }

    public Builder setLicensePlate(final String licensePlate){
      this.licensePlate = licensePlate;
      return this;
    }

    public String getModel(){
      return this.model;
    }

    public Builder setModel(final String model){
      this.model = model;
      return this;
    }

    public int getSeats(){
      return this.seats;
    }

    public Builder setSeats(final int seats){
      this.seats = seats;
      return this;
    }

    public double getRating(){
      return this.rating;
    }

    public Builder setRating(final double rating){
      this.rating = rating;
      return this;
    }

    public LocalDate getDateCreated(){
      return this.dateCreated;
    }

    public Builder setDateCreated(final LocalDate dateCreated){
      this.dateCreated = dateCreated;
      return this;
    }

  }

  @Override
  public int hashCode(){
    final int prime = 31;
    int result = 1;
    result = prime * result + ((licensePlate == null) ? 0 : licensePlate.hashCode());
    result = prime * result + manufacturingYear;
    result = prime * result + ((model == null) ? 0 : model.hashCode());
    long temp;
    temp = Double.doubleToLongBits(rating);
    result = prime * result + (int)(temp ^ (temp >>> 32));
    result = prime * result + seats;
    return result;
  }

  @Override
  public boolean equals(Object obj){
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    Car other = (Car)obj;
    if (licensePlate == null) {
      if (other.licensePlate != null)
        return false;
    } else if (!licensePlate.equals(other.licensePlate))
      return false;
    if (manufacturingYear != other.manufacturingYear)
      return false;
    if (model == null) {
      if (other.model != null)
        return false;
    } else if (!model.equals(other.model))
      return false;
    if (Double.doubleToLongBits(rating) != Double.doubleToLongBits(other.rating))
      return false;
    if (seats != other.seats)
      return false;
    return true;
  }

  public void setManufacturingYear(int manufacturingYear){
    this.manufacturingYear = manufacturingYear;
  }

  public void setLicensePlate(String licensePlate){
    this.licensePlate = licensePlate;
  }

  public void setModel(String model){
    this.model = model;
  }

  public void setSeats(int seats){
    this.seats = seats;
  }

  public void setRating(double rating){
    this.rating = rating;
  }

}
