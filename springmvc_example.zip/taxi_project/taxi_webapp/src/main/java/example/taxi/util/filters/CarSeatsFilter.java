package example.taxi.util.filters;

import java.util.ArrayList;
import java.util.List;

import example.taxi.domainobject.TaxiPoi;

/**
 * CarSeatsFilter filters cars from a list of TaxiPoi objects with an amount of
 * seats higher than a given amount.
 *
 */

public class CarSeatsFilter implements TaxiCriteria<TaxiPoi> {

  private Integer limitSeats;

  public CarSeatsFilter() {

  }

  public CarSeatsFilter(final Integer limitSeats) {
    this.limitSeats = limitSeats;
  }

  /**
   * implementation of link{TaxiCriteria} interface
   */
  @Override
  public List<TaxiPoi> meetCriteria(List<TaxiPoi> taxis){
    List<TaxiPoi> filteredDrivers = new ArrayList<TaxiPoi>();
    for (TaxiPoi taxi : taxis) {
      // add taxi if seats greater input seats
      if (taxi.getDriver().getCar().getSeats() > limitSeats) {
        filteredDrivers.add(taxi);
      }
    }
    return filteredDrivers;
  }
}