package example.taxi.persistence;

import java.io.Serializable;
import java.util.List;

//import org.springframework.data.domain.Page;

public interface Operations<T extends Serializable> {

  // read - one

  T findOne(final long id);

  // read - all

  List<T> findAll();

  // Page<T> findPaginated(int page, int size);

  // write

  T create(final T entity);

  List<T> createList(final Iterable<T> cars);

  T update(final T entity);

  void delete(final T entity);

  void deleteAll();

  void delete(final Iterable<T> entities);

  void deleteById(final long entityId);

}
