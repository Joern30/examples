package example.taxi.domainobject;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import example.taxi.domainvalue.OnlineStatus;

@Entity
@Table(name = "Driver")
public class Driver extends AbstractEntity implements Serializable {
  /**
   * version id
   */
  private static final long serialVersionUID = 3242181984742488967L;

  private Client client;
  private Long driverId;
  private String firstName;
  private String lastName;
  private String slogan;
  private String pictureUrl;
  private String phoneNumber;
  private Double rating;
  private Car car;
  private OnlineStatus onlineStatus;

  protected Driver() {
    super();
    this.driverId = null;
    this.client = null;
    this.firstName = null;
    this.lastName = null;
    this.slogan = null;
    this.pictureUrl = null;
    this.phoneNumber = null;
    this.rating = null;
    this.car = null;
    this.onlineStatus = null;
  }

  protected Driver(final Long id, final LocalDate dateCreated, final Client client, final String firstName,
      final String lastName, final String slogan, final String pictureUrl, final String phoneNumber,
      final Double rating, final Car car, final OnlineStatus onlineStatus) {
    super(dateCreated);
    this.driverId = id;
    this.client = client;
    this.firstName = firstName;
    this.lastName = lastName;
    this.slogan = slogan;
    this.pictureUrl = pictureUrl;
    this.phoneNumber = phoneNumber;
    this.rating = rating;
    this.car = car;
    this.onlineStatus = onlineStatus;
  }

  @Embedded
  public Client getClient(){
    return this.client;
  }

  @Column(name = "DRIVER_NO")
  public Long getDriverId(){
    if (this.client != null) {
      this.client.setId(driverId);
    }
    return driverId;
  }

  @Column(name = "FIRST_NAME")
  public String getFirstName(){
    return this.firstName;
  }

  public void setFirstName(final String firstName){
    this.firstName = firstName;
  }

  @Column(name = "LAST_NAME")
  public String getLastName(){
    return this.lastName;
  }

  public void setLastName(final String lastName){
    this.lastName = lastName;
  }

  @Column(name = "PAROLE")
  public String getSlogan(){
    return this.slogan;
  }

  public void setSlogan(final String slogan){
    this.slogan = slogan;
  }

  @Column(name = "PHOTO")
  public String getPictureUrl(){
    return this.pictureUrl;
  }

  public void setPictureUrl(final String pictureUrl){
    this.pictureUrl = pictureUrl;
  }

  @Column(name = "PHONE_NUMBER")
  public String getPhoneNumber(){
    return this.phoneNumber;
  }

  public void setPhoneNumber(final String phoneNumber){
    this.phoneNumber = phoneNumber;
  }

  @Column(name = "DRIVER_RATING")
  public Double getRating(){
    return this.rating;
  }

  public void setRating(final Double rating){
    this.rating = rating;
  }

  @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
  @JoinColumn(name = "CAR_ID")
  public Car getCar(){
    return this.car;
  }

  public void setCar(final Car car){
    if (this.car != null) {
      this.car.internalRemoveDriver(this);
    }
    this.car = car;
    if (car != null) {
      this.car.internalAddDriver(this);
    }
    if (car == null) {
      this.car = new Car();
      this.car.internalAddDriver(this);
    }
  }

  public void addCar(final Car car){
    if (car == null) {
      this.car = new Car();
    } else {
      this.car = car;
    }
  }

  @Column(name = "ONLINE_STATUS")
  @Basic
  @Enumerated(EnumType.STRING)
  public OnlineStatus getOnlineStatus(){
    return this.onlineStatus;
  }

  public void setOnlineStatus(final OnlineStatus onlineStatus){
    this.onlineStatus = onlineStatus;
  }

  public static Builder newBuilder(){
    return new Builder();
  }

  public static class Builder {

    private Long id;
    private Client client;
    private String firstName;
    private String lastName;
    private String slogan;
    private String pictureUrl;
    private String phoneNumber;
    private double rating;
    private Car car;
    private LocalDate dateCreated;
    private OnlineStatus onlineStatus;

    public Driver build(){
      return new Driver(this.id, this.dateCreated, this.client, this.firstName, this.lastName, this.slogan,
          this.pictureUrl, this.phoneNumber, this.rating, this.car, this.onlineStatus);
    }

    public Long getId(){
      return this.id;
    }

    public Builder setId(final Long id){
      this.id = id;
      return this;
    }

    public Client getClient(){
      return this.client;
    }

    public Builder setClient(final Client client){
      this.client = client;
      return this;
    }

    public String getFirstName(){
      return this.firstName;
    }

    public Builder setFirstName(final String firstName){
      this.firstName = firstName;
      return this;
    }

    public String getLastName(){
      return this.lastName;
    }

    public Builder setLastName(final String lastName){
      this.lastName = lastName;
      return this;
    }

    public String getSlogan(){
      return this.slogan;
    }

    public Builder setSlogan(final String slogan){
      this.slogan = slogan;
      return this;
    }

    public String getPictureUrl(){
      return this.pictureUrl;
    }

    public Builder setPictureUrl(final String pictureUrl){
      this.pictureUrl = pictureUrl;
      return this;
    }

    public String getPhoneNumber(){
      return this.phoneNumber;
    }

    public Builder setPhoneNumber(final String phoneNumber){
      this.phoneNumber = phoneNumber;
      return this;
    }

    public double getRating(){
      return this.rating;
    }

    public Builder setRating(final double rating){
      this.rating = rating;
      return this;
    }

    public Car getCar(){
      return this.car;
    }

    public Builder setCar(final Car car){
      this.car = car;
      return this;
    }

    public LocalDate getDateCreated(){
      return this.dateCreated;
    }

    public Builder setDateCreated(final LocalDate dateCreated){
      this.dateCreated = dateCreated;
      return this;
    }

    public OnlineStatus getOnlineStatus(){
      return this.onlineStatus;
    }

    public Builder setOnlineStatus(final OnlineStatus onlineStatus){
      this.onlineStatus = onlineStatus;
      return this;
    }

  }

  @Override
  public int hashCode(){
    final int prime = 31;
    int result = 1;
    result = prime * result + ((car == null) ? 0 : car.hashCode());
    result = prime * result + ((client == null) ? 0 : client.hashCode());
    result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
    result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
    result = prime * result + ((onlineStatus == null) ? 0 : onlineStatus.hashCode());
    result = prime * result + ((phoneNumber == null) ? 0 : phoneNumber.hashCode());
    result = prime * result + ((pictureUrl == null) ? 0 : pictureUrl.hashCode());
    result = prime * result + ((rating == null) ? 0 : rating.hashCode());
    result = prime * result + ((slogan == null) ? 0 : slogan.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj){
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    Driver other = (Driver)obj;
    if (car == null) {
      if (other.car != null)
        return false;
    } else if (!car.equals(other.car))
      return false;
    if (client == null) {
      if (other.client != null)
        return false;
    } else if (!client.equals(other.client))
      return false;
    if (firstName == null) {
      if (other.firstName != null)
        return false;
    } else if (!firstName.equals(other.firstName))
      return false;
    if (lastName == null) {
      if (other.lastName != null)
        return false;
    } else if (!lastName.equals(other.lastName))
      return false;
    if (onlineStatus != other.onlineStatus)
      return false;
    if (phoneNumber == null) {
      if (other.phoneNumber != null)
        return false;
    } else if (!phoneNumber.equals(other.phoneNumber))
      return false;
    if (pictureUrl == null) {
      if (other.pictureUrl != null)
        return false;
    } else if (!pictureUrl.equals(other.pictureUrl))
      return false;
    if (rating == null) {
      if (other.rating != null)
        return false;
    } else if (!rating.equals(other.rating))
      return false;
    if (slogan == null) {
      if (other.slogan != null)
        return false;
    } else if (!slogan.equals(other.slogan))
      return false;
    return true;
  }

  public void setClient(Client client){
    this.client = client;
  }

  public void setDriverId(Long driverId){
    this.driverId = driverId;
  }

}
