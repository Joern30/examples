package example.taxi.util;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.SortedMap;
import java.util.TreeMap;

import org.springframework.stereotype.Component;

import example.taxi.domainobject.TaxiPoi;
import example.taxi.domainvalue.CriteriaStrategyOrder;
import example.taxi.util.filters.TaxiCriteria;

/**
 * 
 * CriteriaFactoryImpl processes Filters on a list of TaxiPoi objects in a given
 * order and returns a filtered list that correspond to the filter criterias.
 * Implements {@link CriteriaFactory} interface
 *
 */
@Component
public class CriteriaFactoryImpl implements CriteriaFactory<List<TaxiPoi>, Integer, String> {

  final SortedMap<Integer, CriteriaStrategy> sortedCriteriaStrategies = new TreeMap<Integer, CriteriaStrategy>();
  {
    // sort existing strategies
    // from threadsafe enum
    for (CriteriaStrategyOrder strategyOrder : CriteriaStrategyOrder.values()) {

      this.sortedCriteriaStrategies.put(strategyOrder.getIndex(), strategyOrder.getCriteriaStrategy());
    }

  }

  // filters in following order:
  // 1. driver rating
  // 2. driver online status free
  // 3. car manufactoring year
  // 4. car seats amount
  // different interface variables for readibility reasons

  /**
   * implementation of {@link CriteriaFactory} interface
   */
  @Override
  public List<TaxiPoi> processCriterias(final List<TaxiPoi> taxis, final Map<Integer, String> criterias){

    // sort criterias
    final SortedMap<Integer, String> sortedCriterias = new TreeMap<Integer, String>(criterias);

    List<TaxiPoi> taxiPoisfiltered = taxis;

    // sort existing strategies
    final SortedMap<Integer, CriteriaStrategy> sortedCriteriastrategies = this.sortStrategies(sortedCriterias);

    // execution of criterias
    taxiPoisfiltered = criteriaExecution(sortedCriterias, taxiPoisfiltered, sortedCriteriastrategies);

    return taxiPoisfiltered;
  }

  private List<TaxiPoi> criteriaExecution(final SortedMap<Integer, String> sortedCriterias,
      List<TaxiPoi> taxiPoisfiltered, final SortedMap<Integer, CriteriaStrategy> sortedCriteriastrategies){
    for (Map.Entry<Integer, CriteriaStrategy> entry : sortedCriteriastrategies.entrySet()) {
      CriteriaStrategy strategy = entry.getValue();
      TaxiCriteria<TaxiPoi> taxiPoiFilter = strategy.createCriteria(sortedCriterias.get(entry.getKey()));
      taxiPoisfiltered = this.executeTaxiCriteria(taxiPoiFilter, taxiPoisfiltered);
    }
    return taxiPoisfiltered;
  }

  private SortedMap<Integer, CriteriaStrategy> sortStrategies(final SortedMap<Integer, String> sortedCriterias){
    final SortedMap<Integer, CriteriaStrategy> selectedSortedCriteriastrategies = new TreeMap<Integer, CriteriaStrategy>();
    for (Entry<Integer, String> entry : sortedCriterias.entrySet()) {

      selectedSortedCriteriastrategies.put(entry.getKey(), this.sortedCriteriaStrategies.get(entry.getKey()));
    }
    return selectedSortedCriteriastrategies;
  }

  private List<TaxiPoi> executeTaxiCriteria(final TaxiCriteria<TaxiPoi> taxiPoiFilter, final List<TaxiPoi> taxis){

    return taxiPoiFilter.meetCriteria(taxis);

  }
}
