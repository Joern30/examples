package example.taxi.domainvalue;

public enum OnlineStatus {
  FREE,
  OCCUPIED
}
