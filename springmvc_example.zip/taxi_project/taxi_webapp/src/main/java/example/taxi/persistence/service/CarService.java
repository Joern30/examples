package example.taxi.persistence.service;

import java.util.List;

import example.taxi.domainobject.Car;
import example.taxi.domainobject.Driver;
import example.taxi.persistence.Operations;

public interface CarService extends Operations<Car> {

  Car findCarById(final Long carId);

  Car findCarByDriver(final Driver driver);

  List<Car> findByIds(Iterable<Long> ids);

}
