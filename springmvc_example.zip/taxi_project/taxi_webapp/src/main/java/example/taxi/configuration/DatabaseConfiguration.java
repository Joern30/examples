package example.taxi.configuration;

import java.io.IOException;
import java.net.URL;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.configuration.PropertiesConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.google.common.base.Charsets;
import com.google.common.base.Preconditions;
import com.google.common.io.Resources;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

@EnableTransactionManagement
@PropertySource({ "classpath:persistence-${envTarget:h2}.properties" })
@ComponentScan({ "example.taxi.persistence" })
@EnableJpaRepositories(basePackages = "example.taxi.persistence.dao")
@Configuration
public class DatabaseConfiguration {

  private static final Logger log = LoggerFactory.getLogger(DatabaseConfiguration.class);

  private static final String dataSourceDriverDefault = org.h2.Driver.class.getName();
  private static final String dataSourceUrlDefault = "jdbc:h2:mem:test_%1$;DB_CLOSE_DELAY=-1;";
  private static final String dataSourceUsernameDefault = "anonymous";
  private static final String dataSourcePasswordDefault = "anonymous";
  private static final String hibernateDialectDefault = "org.hibernate.spatial.dialect.h2geodb.GeoDBDialect";
  private static final String hibernateHbm2ddlAutoDefault = "create";

  @Autowired
  private Environment env;

  private final PropertiesConfiguration databaseProperties = new PropertiesConfiguration();
  {
    final String databasePropertiesFileName = "database.properties";
    try {
      this.databaseProperties.load(databasePropertiesFileName);
      DatabaseConfiguration.log.info(databasePropertiesFileName
          + ("\n" + Resources.toString(this.databaseProperties.getURL(), Charsets.UTF_8) + "\n").trim());
    } catch (final Exception ex) {
      DatabaseConfiguration.log.warn(ex.getMessage());
    }
  }

  // @Bean(destroyMethod = "close")
  // public DataSource dataSource() throws SQLException{
  // final PoolProperties p = new PoolProperties();
  //
  // p.setUrl(this.databaseProperties.getString("datasource.url",
  // DatabaseConfiguration.dataSourceUrlDefault));
  // final String driverClassName =
  // this.databaseProperties.getString("datasource.driver",
  // DatabaseConfiguration.dataSourceDriverDefault);
  // p.setDriverClassName(driverClassName);
  // p.setUsername(this.databaseProperties.getString("datasource.username",
  // DatabaseConfiguration.dataSourceUsernameDefault));
  // p.setPassword(this.databaseProperties.getString("datasource.password",
  // DatabaseConfiguration.dataSourcePasswordDefault));
  //
  // p.setJmxEnabled(true);
  // p.setTestWhileIdle(true);
  // p.setTestOnBorrow(true);
  // p.setValidationQuery("SELECT 1");
  // p.setTestOnReturn(false);
  // p.setValidationInterval(30000);
  // p.setTimeBetweenEvictionRunsMillis(30000);
  //
  // p.setMaxActive(5);
  // p.setMaxIdle(5);
  // p.setInitialSize(2);
  // p.setMaxWait(10000);
  // p.setRemoveAbandonedTimeout(300);
  // p.setMinEvictableIdleTimeMillis(30000);
  // p.setMinIdle(2);
  //
  // p.setLogAbandoned(true);
  // p.setRemoveAbandoned(true);
  //
  // p.setJdbcInterceptors("org.apache.tomcat.jdbc.pool.interceptor.ConnectionState;"
  // + "org.apache.tomcat.jdbc.pool.interceptor.StatementFinalizer");
  //
  // final org.apache.tomcat.jdbc.pool.DataSource bean = new
  // org.apache.tomcat.jdbc.pool.DataSource();
  // bean.setPoolProperties(p);
  //
  // // if
  // // (driverClassName.equals(DatabaseConfiguration.dataSourceDriverDefault))
  // {
  // // DatabaseConfiguration.log.info("Init GeoDB");
  // // GeoDB.InitGeoDB(bean.getConnection());
  // // }
  //
  // return bean;
  // }

  public Properties getHibernateProperties(){
    final Properties hibernateProperties = new Properties();
    hibernateProperties.setProperty("hibernate.dialect",
        this.databaseProperties.getString("hibernate.dialect", DatabaseConfiguration.hibernateDialectDefault));
    // hibernateProperties.setProperty("hibernate.jdbc.fetch_size", "100");
    // hibernateProperties.setProperty("hibernate.jdbc.batch_size", "200");
    // # Enable Hibernate's automatic session context management
    // hibernateProperties.setProperty("hibernate.current_session_context_class",
    // "thread");
    // # Disable the second-level cache
    // hibernateProperties.setProperty("hibernate.cache.provider_class",
    // "org.hibernate.cache.internal.NoCacheProvider");
    // # Echo all executed SQL to stdout
    hibernateProperties.setProperty("hibernate.show_sql", "true");
    // # Drop and re-create the database schema on startup
    hibernateProperties.setProperty("hibernate.hbm2ddl.auto",
        this.databaseProperties.getString("hibernate.hbm2ddl.auto", DatabaseConfiguration.hibernateHbm2ddlAutoDefault));
    // hibernateProperties.setProperty(
    // "hibernate.transaction.factory_class",
    // "net.sf.hibernate.transaction.JDBCTransactionFactory");

    return hibernateProperties;
  }

  // /////////////////////////////////////////////////////////////////////////////////////////////////////////
  @Bean
  public LocalContainerEntityManagerFactoryBean entityManagerFactory(){
    final LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
    em.setDataSource(dataSource());
    // em.setPackagesToScan(new String[] { "example.taxi.domainobject" });
    em.setPackagesToScan(new String[] { "example.taxi.domainobject" });
    final HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
    // vendorAdapter.set
    em.setJpaVendorAdapter(vendorAdapter);
    em.setJpaProperties(additionalProperties());

    return em;
  }

  // Hikari CP Datasource
  @Bean(destroyMethod = "close")
  DataSource dataSource(){
    HikariConfig dataSourceConfig = new HikariConfig();
    dataSourceConfig.setDriverClassName(Preconditions.checkNotNull(env.getRequiredProperty("db.driver")));
    dataSourceConfig.setJdbcUrl(Preconditions.checkNotNull(env.getRequiredProperty("db.url")));
    dataSourceConfig.setUsername(Preconditions.checkNotNull(env.getRequiredProperty("db.username")));
    dataSourceConfig.setPassword(Preconditions.checkNotNull(env.getRequiredProperty("db.password")));

    return new HikariDataSource(dataSourceConfig);
  }

  // DriverManagerDataSource for Test
  // @Bean
  // public DataSource dataSource(){
  // final DriverManagerDataSource dataSource = new DriverManagerDataSource();
  // dataSource.setDriverClassName(Preconditions.checkNotNull(env.getProperty("jdbc.driverClassName")));
  // dataSource.setUrl(Preconditions.checkNotNull(env.getProperty("jdbc.url")));
  // dataSource.setUsername(Preconditions.checkNotNull(env.getProperty("jdbc.user")));
  // dataSource.setPassword(Preconditions.checkNotNull(env.getProperty("jdbc.pass")));
  //
  // return dataSource;
  // }

  @Bean
  public PlatformTransactionManager transactionManager(){
    final JpaTransactionManager transactionManager = new JpaTransactionManager();
    transactionManager.setEntityManagerFactory(entityManagerFactory().getObject());

    return transactionManager;
  }

  @Bean
  public PersistenceExceptionTranslationPostProcessor exceptionTranslation(){
    return new PersistenceExceptionTranslationPostProcessor();
  }

  // @Bean
  // @Lazy(false)
  // public ResourceDatabasePopulator populateDatabase() throws SQLException{
  // ResourceDatabasePopulator populator = new ResourceDatabasePopulator();
  // populator.addScript(new ClassPathResource("h2_table_initilization.sql"));
  // Connection connection = null;
  // try {
  // connection = DataSourceUtils.getConnection(dataSource());
  // populator.populate(connection);
  // } finally {
  // if (connection != null) {
  // DataSourceUtils.releaseConnection(connection, dataSource());
  // }
  // }
  // return populator;
  // }

  final Properties additionalProperties(){
    // final Properties hibernateProperties = new Properties();
    // hibernateProperties.setProperty("hibernate.hbm2ddl.auto",
    // env.getProperty("hibernate.hbm2ddl.auto"));
    // hibernateProperties.setProperty("hibernate.dialect",
    // env.getProperty("hibernate.dialect"));
    // hibernateProperties.setProperty("hibernate.show_sql", "true");
    // hibernateProperties.setProperty("spring.jpa.hibernate.naming_strategy",
    // env.getProperty("hibernate.naming_strategy"));
    // hibernateProperties.setProperty("hibernate.globally_quoted_identifiers",
    // "true");

    Properties jpaProperties = new Properties();

    // Configures the used database dialect. This allows Hibernate to create SQL
    // that is optimized for the used database.
    jpaProperties.put("hibernate.dialect", env.getRequiredProperty("hibernate.dialect"));

    // Specifies the action that is invoked to the database when the Hibernate
    // SessionFactory is created or closed.
    jpaProperties.put("hibernate.hbm2ddl.auto", env.getRequiredProperty("hibernate.hbm2ddl.auto"));

    // Configures the naming strategy that is used when Hibernate creates
    // new database objects and schema elements
    jpaProperties.put("hibernate.ejb.naming_strategy", env.getRequiredProperty("hibernate.ejb.naming_strategy"));

    // If the value of this property is true, Hibernate writes all SQL
    // statements to the console.
    jpaProperties.put("hibernate.show_sql", env.getRequiredProperty("hibernate.show_sql"));

    // If the value of this property is true, Hibernate will format the SQL
    // that is written to the console.
    jpaProperties.put("hibernate.format_sql", env.getRequiredProperty("hibernate.format_sql"));
    jpaProperties.setProperty("hibernate.hbm2ddl.import_files_sql_extractor",
        "org.hibernate.tool.hbm2ddl.MultipleLinesSqlCommandExtractor");
    Resource script = new ClassPathResource("h2_table_initilization.sql");
    script.getFilename();
    URL script_Url = null;
    try {
      script_Url = script.getURL();
    } catch (IOException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    String path = script_Url.getPath();
    jpaProperties.setProperty("hibernate.hbm2ddl.import_files", path);
    // return hibernateProperties;
    return jpaProperties;
  }
}
