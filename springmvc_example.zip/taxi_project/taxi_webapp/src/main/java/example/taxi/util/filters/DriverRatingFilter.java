package example.taxi.util.filters;

import java.util.ArrayList;
import java.util.List;

import example.taxi.domainobject.TaxiPoi;

/**
 * DriverRatingFilter filters driver ratings for drivers from a list of TaxiPoi
 * objects higher than a given rating.
 * 
 * 
 *
 */

public class DriverRatingFilter implements TaxiCriteria<TaxiPoi> {

  private Double limitRating;

  public DriverRatingFilter() {

  }

  public DriverRatingFilter(final Double limitRating) {
    this.limitRating = limitRating;
  }

  /**
   * implementation of {TaxiCriteria} interface
   */
  @Override
  public List<TaxiPoi> meetCriteria(List<TaxiPoi> taxis){
    List<TaxiPoi> filteredDrivers = new ArrayList<TaxiPoi>();
    for (TaxiPoi taxi : taxis) {
      // add taxi if rating greater input rating
      if (taxi.getDriver().getRating().compareTo(limitRating) > 0) {
        filteredDrivers.add(taxi);
      }
    }
    return filteredDrivers;
  }
}