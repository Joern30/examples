package example.taxi.controller;

import java.util.HashMap;
import java.util.Map;

import com.google.common.base.Preconditions;

import example.taxi.domainvalue.CriteriaStrategyOrder;

/**
 * 
 * TaxiPoiControllerParameterValueHandler analyzes required and option
 * parameters of TaxiPoi controller requests.
 * 
 *
 */
public class TaxiPoiControllerParameterValueHandler {
  private static final long maxKilometers = 20000l;
  private static final long minKilometers = 0l;
  private static final long minCarSeats = 0l;
  private static final String defaultOnlineStatus = "FREE";

  /**
   * handleParameterValues
   * 
   * @param radiusInMeter
   * @param driverRating
   * @param carSeats
   * @param driverOnlineStatus
   * @param carManufactoringYear
   * @return a map with criteria to filter the list of TaxPoi objects
   */
  public static Map<Integer, String> handleParameterValues(final long radiusInMeter, final Float driverRating,
      final Long carSeats, final String driverOnlineStatus, final Long carManufactoringYear){
    final Map<Integer, String> criteriaMap = new HashMap<Integer, String>();

    final boolean condOptinalParamsOverAll = driverRating != null || carSeats != null || driverOnlineStatus != null
        || carManufactoringYear != null;
    final boolean condMaxRadius = radiusInMeter <= maxKilometers;
    final boolean condMinRadius = radiusInMeter > minKilometers;

    // over all validation as guard
    checkPreCondition(condOptinalParamsOverAll,
        "one of following values must be set: driver rating, car seats, driver onlines status, car manufactoring year");
    // check required parameters

    checkPreCondition(condMaxRadius, "Could not process radius value because radius is bigger than 20 km");
    checkPreCondition(condMinRadius, "Could not process radius value because radius is 0 km or negative");

    // online status special treatment:
    if (driverOnlineStatus != null) {
      final boolean condOnlineStautus = driverOnlineStatus.toUpperCase().equals(defaultOnlineStatus);
      checkPreCondition(driverOnlineStatus.toUpperCase(), condOnlineStautus,
          "Could not process driver online status value because driver online status is not set to 'free'",
          CriteriaStrategyOrder.DRIVERONLINESTATUS, criteriaMap);
    }

    // driver rating
    if (driverRating != null) {
      final boolean condDriverRating = driverRating >= minCarSeats;
      checkPreCondition(driverRating, condDriverRating,
          "Could not process driver rating value because driver rating is negative",
          CriteriaStrategyOrder.DRIVERRATING, criteriaMap);
    }
    // car seats
    if (carSeats != null) {
      final boolean condCarSeats = carSeats > minCarSeats;
      checkPreCondition(carSeats, condCarSeats,
          "Could not process car seats value because seats value is zero or negative", CriteriaStrategyOrder.CARSEATS,
          criteriaMap);
    }

    // carManufactoringYear
    if (carManufactoringYear != null) {
      final boolean condCarManufactered = carManufactoringYear >= minCarSeats;
      checkPreCondition(carManufactoringYear, condCarManufactered,
          "Could not process car age value because the car age is negative", CriteriaStrategyOrder.CARMANUFACTORED,
          criteriaMap);
    }

    return criteriaMap;
  }

  /**
   * handleParameterValues
   * 
   * @param radiusInMeter
   * @param driverRating
   * @param carSeats
   * @param driverOnlineStatus
   * @param carManufactoringYear
   * @return a map with criteria to filter the list of TaxPoi objects
   */
  public static Map<Integer, String> handleParameterValues(final String radiusInMeter, final String driverRating,
      final String carSeats, final String driverOnlineStatus, final String carManufactoringYear){
    final Map<Integer, String> criteriaMap = new HashMap<Integer, String>();

    final boolean condOptinalParamsOverAll = driverRating != null || carSeats != null || driverOnlineStatus != null
        || carManufactoringYear != null;
    final boolean condMaxRadius = Long.valueOf(radiusInMeter) <= maxKilometers;
    final boolean condMinRadius = Long.valueOf(radiusInMeter) > minKilometers;

    // over all validation as guard
    checkPreCondition(condOptinalParamsOverAll,
        "one of following values must be set: driver rating, car seats, driver onlines status, car manufactoring year");
    // check required parameters

    checkPreCondition(condMaxRadius, "Could not process radius value because radius is bigger than 20 km");
    checkPreCondition(condMinRadius, "Could not process radius value because radius is 0 km or negative");

    // online status special treatment:
    if (driverOnlineStatus != null) {
      final boolean condOnlineStautus = driverOnlineStatus.toUpperCase().equals(defaultOnlineStatus);
      checkPreCondition(driverOnlineStatus.toUpperCase(), condOnlineStautus,
          "Could not process driver online status value because driver online status is not set to 'free'",
          CriteriaStrategyOrder.DRIVERONLINESTATUS, criteriaMap);
    }

    // driver rating
    if (driverRating != null) {
      final boolean condDriverRating = Float.valueOf(driverRating) >= minCarSeats;
      checkPreCondition(driverRating, condDriverRating,
          "Could not process driver rating value because driver rating is negative",
          CriteriaStrategyOrder.DRIVERRATING, criteriaMap);
    }
    // car seats
    if (carSeats != null) {
      final boolean condCarSeats = Long.valueOf(carSeats) > minCarSeats;
      checkPreCondition(carSeats, condCarSeats,
          "Could not process car seats value because seats value is zero or negative", CriteriaStrategyOrder.CARSEATS,
          criteriaMap);
    }

    // carManufactoringYear
    if (carManufactoringYear != null) {
      final boolean condCarManufactered = Long.valueOf(carManufactoringYear) >= minCarSeats;
      checkPreCondition(carManufactoringYear, condCarManufactered,
          "Could not process car age value because the car age is negative", CriteriaStrategyOrder.CARMANUFACTORED,
          criteriaMap);
    }

    return criteriaMap;
  }

  private static <T> void checkPreCondition(final T paramValue, final boolean condition, final String errorMessage,
      final CriteriaStrategyOrder paramOrder, final Map<Integer, String> criteriaMap){
    if (paramValue != null) {
      checkPreCondition(condition, errorMessage);
      // type conversion for driver rating to String
      String convert = String.valueOf(paramValue);
      // fill criteria map with criteria parameters
      criteriaMap.put(paramOrder.getIndex(), convert);
    }

  }

  // required parameters
  public static <T> boolean checkPreCondition(final T condition, final String errorMessage){
    Preconditions.checkArgument((Boolean)condition, errorMessage);

    return true;
  }

}
