package example.taxi.persistence.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import example.taxi.domainobject.Client;
import example.taxi.domainobject.Driver;

public interface DriverDAO extends JpaRepository<Driver, Long>, JpaSpecificationExecutor<Driver> {

  @Query("SELECT d FROM Driver d WHERE LOWER(d.client.username) = LOWER(:username)")
  Driver findByUsername(@Param("username") final String username);

  @Query("SELECT d FROM Driver d WHERE d.driverId = :#{#client.id}")
  Driver find(@Param("client") final Client client);

}
