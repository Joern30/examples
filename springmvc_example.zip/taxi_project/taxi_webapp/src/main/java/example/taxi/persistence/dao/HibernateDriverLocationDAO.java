package example.taxi.persistence.dao;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import example.taxi.domainobject.Coordinate;
import example.taxi.domainobject.DriverLocation;

public class HibernateDriverLocationDAO extends HibernateDAO<DriverLocation, Long>  {

  @Autowired
  public HibernateDriverLocationDAO() {
    super(DriverLocation.class, null);
  }

  
  public DriverLocation findByDriverId(final Long driverId){
    final Criteria criteria = this.createCriteria();

    criteria.add(Restrictions.eq("driverId", driverId));
    criteria.addOrder(Order.desc("id"));

    return (DriverLocation)criteria.uniqueResult();
  }

  @SuppressWarnings("unchecked")
  public List<DriverLocation> findByDriverId(final Collection<Long> driverIds){

    if (driverIds.isEmpty()) {
      return Collections.EMPTY_LIST;
    }

    final Criteria criteria = this.createCriteria();

    criteria.add(Restrictions.in("driverId", driverIds));
    criteria.addOrder(Order.desc("id"));

    return criteria.list();
  }

  @Override
  @Transactional
  public void save(final DriverLocation obj){
    this.getCurrentSession().update(obj);
  }

 
  public List<DriverLocation> findWithin(final Coordinate coordinate, final double radius){

    return null;
  }

  public List<DriverLocation> findWithin(final Coordinate upperLeftCoordinate, final Coordinate lowerRightCoordinate){


    return null;
  }

  
  public List<DriverLocation> find(Collection<Long> ids){
    return null;
  }

}
