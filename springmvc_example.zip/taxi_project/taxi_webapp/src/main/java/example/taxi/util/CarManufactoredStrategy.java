package example.taxi.util;

import example.taxi.domainobject.TaxiPoi;
import example.taxi.util.filters.CarManufactoredFilter;
import example.taxi.util.filters.TaxiCriteria;

/**
 * 
 * CarManufactoredStrategy creates link{CarManufactoredFilter} objects
 *
 */

public class CarManufactoredStrategy implements CriteriaStrategy {

  /**
   * implementation of link{CriteriaStrategy) interface
   */
  @Override
  public TaxiCriteria<TaxiPoi> createCriteria(String criteria){

    return new CarManufactoredFilter(Integer.parseInt(criteria));
  }
}
