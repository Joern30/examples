package example.taxi.util;

import example.taxi.domainobject.TaxiPoi;
import example.taxi.util.filters.DriverRatingFilter;
import example.taxi.util.filters.TaxiCriteria;

/**
 * 
 * DriverRatingStrategy creates link{DriverRatingFilter} objects
 *
 */

public class DriverRatingStrategy implements CriteriaStrategy {

  /**
   * implementation of link{CriteriaStrategy}
   * 
   * @param criteria
   * 
   * @return DriverRatingFiltera object
   */

  @Override
  public TaxiCriteria<TaxiPoi> createCriteria(String criteria){

    return new DriverRatingFilter(Double.parseDouble(criteria));
  }
}
