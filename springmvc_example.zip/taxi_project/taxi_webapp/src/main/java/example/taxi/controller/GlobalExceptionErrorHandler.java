package example.taxi.controller;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

@ControllerAdvice
class GlobalControllerExceptionHandler {

  @ExceptionHandler
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  @ResponseBody
  ErrorMessage handleException(IllegalArgumentException ex){
    ErrorMessage errorMessage = createErrorMessage(ex);
    return errorMessage;
  }

  private ErrorMessage createErrorMessage(Throwable ex){
    return new ErrorMessage(ex.getMessage());
  }

  @ExceptionHandler
  @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
  @ResponseBody
  ErrorMessage handleException(Throwable ex){
    ErrorMessage errorMessage = createErrorMessage(ex);
    return errorMessage;
  }
}