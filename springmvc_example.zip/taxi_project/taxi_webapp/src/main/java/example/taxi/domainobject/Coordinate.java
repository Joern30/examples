package example.taxi.domainobject;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.FetchType;
import javax.persistence.Lob;
import javax.persistence.Transient;

import org.springframework.data.geo.Point;

@Embeddable
public class Coordinate {

  @Transient
  private Float longitude;
  @Transient
  private Float latitude;
  private Point point;

  public Coordinate() {

    this.latitude = null;
    this.longitude = null;

  }

  public Coordinate(final Float latitude, final Float longitude) {

    this.latitude = latitude;
    this.longitude = longitude;
    this.point = new Point(latitude, longitude);

  }

  public Coordinate(Double latitude, Double longitude) {
    this.latitude = latitude.floatValue();
    this.longitude = longitude.floatValue();
    this.point = new Point(latitude, longitude);
  }

  public Coordinate(Integer latitude, Integer longitude) {
    this.latitude = latitude.floatValue();
    this.longitude = longitude.floatValue();
    this.point = new Point(latitude, longitude);
  }

  @Column(name = "LOCATION")
  @Lob
  @Basic(fetch = FetchType.EAGER)
  public Point getPoint(){
    return point;
  }

  public void setPoint(Point point){
    this.point = point;
  }

  public Float getLongitude(){
    return longitude;
  }

  public Float getLatitude(){
    return latitude;
  }

  public void setLongitude(Float longitude){
    this.longitude = longitude;
  }

  public void setLatitude(Float latitude){
    this.latitude = latitude;
  }

}
