package example.taxi.domainobject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

public class DriverListSerializer extends JsonSerializer<List<Driver>> {

  @Override
  public void serialize(List<Driver> drivers, JsonGenerator generator, SerializerProvider serializers)
      throws IOException, JsonProcessingException{
    List<Driver> carDrivers = null;
    for (Driver item : drivers) {
      carDrivers = item.getCar().getDrivers();
      carDrivers = new ArrayList<Driver>();
      item.getCar().setDrivers(carDrivers);
    }

    generator.writeObject(drivers);

  }

}