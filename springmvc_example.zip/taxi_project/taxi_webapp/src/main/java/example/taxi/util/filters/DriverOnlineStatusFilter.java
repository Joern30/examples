package example.taxi.util.filters;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import example.taxi.configuration.DatabaseConfiguration;
import example.taxi.domainobject.TaxiPoi;
import example.taxi.domainvalue.OnlineStatus;

/**
 * DriverOnlineStatusFilter filters online status for drivers, e. g.
 * (FREE/OCCUPIED) from a list of TaxiPoi objects. It provides a default filter
 * implementation for status FREE.
 * 
 * If a wrong status string is passed in, an IllegalArgumentException will be
 * caught and an empty list is returned.
 *
 */

public class DriverOnlineStatusFilter implements TaxiCriteria<TaxiPoi> {

  private static final Logger log = LoggerFactory.getLogger(DatabaseConfiguration.class);

  private String limitOnLineStatus = OnlineStatus.FREE.toString();

  public DriverOnlineStatusFilter() {

  }

  public DriverOnlineStatusFilter(final String limitOnLineStatus) {
    this.limitOnLineStatus = limitOnLineStatus;
  }

  @Override
  /**
   * implementation of link{TaxiCriteria} interface
   */
  public List<TaxiPoi> meetCriteria(final List<TaxiPoi> taxis){
    final List<TaxiPoi> filteredDrivers = new ArrayList<TaxiPoi>();
    final OnlineStatus status;
    // guard
    if (this.limitOnLineStatus == null) {
      return taxis;
    }
    try {
      status = OnlineStatus.valueOf(limitOnLineStatus);
      for (TaxiPoi taxi : taxis) {
        // add taxi if online status equal to input status
        if (taxi.getDriver().getOnlineStatus().compareTo(status) == 0) {
          filteredDrivers.add(taxi);
        }
      }
    } catch (IllegalArgumentException ex) {
      log.trace("DriverOnlineStatusFilter: online status not available. " + ex.getMessage());

    }
    return filteredDrivers;
  }
}
