package example.taxi.persistence.dao;

import java.util.List;

import example.taxi.domainobject.Coordinate;
import example.taxi.domainobject.TaxiPoi;

public interface TaxiPoiDAO {

  /**
   * Find drivers in box defined by {@code upperLeftCoordinate} and
   * {@code lowerRightCoordinate}
   * 
   * @param upperLeftCoordinate
   * @param lowerRightCoordinate
   * @return drivers within
   */
  List<TaxiPoi> findDriversWithin(Coordinate upperLeftCoordinate, Coordinate lowerRightCoordinate);

  /**
   * Find drivers in box defined by {@code upperLeftCoordinate} and
   * {@code radius}
   * 
   * @param upperLeftCoordinate
   * @param radius
   * @return drivers within
   */
  List<TaxiPoi> findDriversWithin(Coordinate upperLeftCoordinate, double radius);

}
