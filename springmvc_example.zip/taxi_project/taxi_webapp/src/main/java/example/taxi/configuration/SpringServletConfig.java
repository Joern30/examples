package example.taxi.configuration;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.LinkedList;
import java.util.List;

import org.resthub.web.springmvc.router.RouterHandlerMapping;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;

import example.taxi.controller.TaxiPoiControllerMethodArgumentResolver;
import example.taxi.domainobject.CustomLocalDateSerializer;
import example.taxi.domainobject.CustomLocalDateTimeSerializer;
import example.taxi.interceptor.LoggingInterceptor;
import example.taxi.persistence.dao.HibernateDriverLocationDAO;
import example.taxi.persistence.dao.HibernateTaxiPoiDAO;
import example.taxi.persistence.dao.TaxiPoiDAO;

@Import({ DatabaseConfiguration.class, UtilConfig.class, ControllerConfig.class })
@Configuration
public class SpringServletConfig extends WebMvcConfigurationSupport {

  @Bean
  public PathMatchingResourcePatternResolver resourceResolver(){
    return new PathMatchingResourcePatternResolver();
  }

  @Bean
  public ReloadableResourceBundleMessageSource messageSource(){
    final ReloadableResourceBundleMessageSource bean = new ReloadableResourceBundleMessageSource();
    bean.setBasename("classpath:messages");
    bean.setDefaultEncoding("UTF-8");
    return bean;
  }

  /**
   * ################################### 
   *             Spring MVC
   * ###################################
   */

  @Override
  public void configureMessageConverters(List<HttpMessageConverter<?>> converters){
    CustomLocalDateSerializer localDateSerializer = new CustomLocalDateSerializer();
    CustomLocalDateTimeSerializer localDateTimeSerializer = new CustomLocalDateTimeSerializer();

    JavaTimeModule module = new JavaTimeModule();
    module.addSerializer(LocalDateTime.class, localDateTimeSerializer);
    module.addSerializer(LocalDate.class, localDateSerializer);
    module.addDeserializer(LocalDate.class, new LocalDateDeserializer(DateTimeFormatter.ofPattern("yyyy/MM/dd")));

    Jackson2ObjectMapperBuilder builder = new Jackson2ObjectMapperBuilder();
    builder.serializationInclusion(JsonInclude.Include.NON_NULL);
    builder.featuresToDisable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS).failOnUnknownProperties(false);
    builder.propertyNamingStrategy(PropertyNamingStrategy.LOWER_CAMEL_CASE);
    builder.serializationInclusion(Include.NON_EMPTY);
    builder.indentOutput(true).serializerByType(LocalDate.class, localDateSerializer);
    builder.serializerByType(LocalDateTime.class, localDateTimeSerializer);
    builder.deserializerByType(LocalDate.class, new LocalDateDeserializer(DateTimeFormatter.ofPattern("yyyy/MM/dd")));
    builder.modulesToInstall(module);

    converters.add(new MappingJackson2HttpMessageConverter(builder.build()));

    ObjectMapper mapper = new ObjectMapper();

    // builder.configure(mapper);
    mapper.registerModule(module);
    mapper.configure(SerializationFeature.WRITE_DATES_WITH_ZONE_ID, true);

  }

  @Override
  public void addInterceptors(final InterceptorRegistry registry){
    registry.addInterceptor(new LoggingInterceptor());
  }

  /**
   * Choose HandlerMapping. RouterHandlerMapping loads routes configuration from
   * a file. Router adapted from Play! Framework. @see
   * http://www.playframework.org/documentation/1.2.4/routes#syntax for route
   * configuration syntax. Example: GET /home PageController.showPage(id:'home')
   * GET /page/{id} PageController.showPage
   */
  @Bean
  public RouterHandlerMapping handlerMapping(){
    final RouterHandlerMapping routerHandlerMapping = new RouterHandlerMapping();
    final LinkedList<String> routes = new LinkedList<String>();
    routes.add("/WEB-INF/routes.conf");
    routerHandlerMapping.setRouteFiles(routes);
    // dynamically reload routes when route files are modified. Can be a
    // good idea in develop mode, not so much in production!
    routerHandlerMapping.setAutoReloadEnabled(true);
    routerHandlerMapping.setInterceptors(this.getInterceptors());
    return routerHandlerMapping;
  }

  @Override
  public void addArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers){
    argumentResolvers.add(new TaxiPoiControllerMethodArgumentResolver());
  }

  /**
   * ################################### 
   *         DataAccessObject
   * ###################################
   */

  @Bean
  public TaxiPoiDAO taxiPoiDAO(){
    return new HibernateTaxiPoiDAO();
  }

  @Bean
  public HibernateDriverLocationDAO driverLocationDAO(){
    return new HibernateDriverLocationDAO();
  }

}
