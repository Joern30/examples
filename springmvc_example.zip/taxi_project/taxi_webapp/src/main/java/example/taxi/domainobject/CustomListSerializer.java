package example.taxi.domainobject;

import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

public abstract class CustomListSerializer<T> extends JsonSerializer<List<T>> {

  @Override
  public void serialize(List<T> items, JsonGenerator generator, SerializerProvider provider) throws IOException,
      JsonProcessingException{
    generator.writeObject(items);
  }
}