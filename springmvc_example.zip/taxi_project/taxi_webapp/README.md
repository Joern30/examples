# WebApp_Template
This is a demo web app based on spring mvc and spring data.