package tasks.task5;

class LimousineDemo1 implements Runnable {
	   private Thread t;
	   private String threadName;
	   
	   public LimousineDemo1( String name){
	       threadName = name;
	       System.out.println("Creating " +  threadName );
	   }
	   public void run() {
	      System.out.println("Running " +  threadName );
	      try {
	         for(int i = 4; i > 0; i--) {
	            System.out.println("Thread: " + threadName + ", " + i);
	            // Let the thread sleep for a while.
	            Thread.sleep(50);
	         }
	         Factory factory = ThreadsafeCarFactory1.uniqueInstance;
	         CarType carType = factory.createCars("limousine");
	         System.out.println(carType.print()+ " by " + threadName);
	         System.out.println("cars produced " + factory.counter());
	         
	     } catch (InterruptedException e) {
	         System.out.println("Thread " +  threadName + " interrupted.");
	     } catch (Exception e) {
	    	 System.out.println("Thread " +  threadName + " error.");
		}
	     System.out.println("Thread " +  threadName + " exiting.");
	   }
	   
	   public void start ()
	   {
	      System.out.println("Starting " +  threadName );
	      if (t == null)
	      {
	         t = new Thread (this, threadName);
	         t.start ();
	      }
	   }

	}
