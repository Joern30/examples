package tasks.task5;

public class SingletonTest {
	   public static void main(String args[]) {
	   
		  LimousineDemo R1 = new LimousineDemo( "Thread-1");
	      R1.start();
	      
	      MiniVanDemo R2 = new MiniVanDemo( "Thread-2");
	      R2.start();

	      LimousineDemo R3 = new LimousineDemo( "Thread-3");
	      R3.start();
	      
	      MiniVanDemo R4 = new MiniVanDemo( "Thread-4");
	      R4.start();
	   }   
	}
