package tasks.task5.J18;

import tasks.task5.CarType;
import tasks.task5.Factory;
import tasks.task5.ThreadsafeCarFactory;

public class SingletonTest {
	public static void main(String args[]) {

		Runnable miniVan = () -> {
			final String car = "miniVan";
			Carproduction.executeCarProduction(car);
		};

		Runnable limousine = () -> {
			final String car = "limousine";
			Carproduction.executeCarProduction(car);
		};

		Thread R1 = new Thread(miniVan, "Thread-1");
		R1.start();

		Thread R2 = new Thread(limousine, "Thread-2");
		R2.start();

		Thread R3 = new Thread(limousine, "Thread-3");
		R3.start();

		Thread R4 = new Thread(miniVan, "Thread-4");
		R4.start();
	}

	public final static class Carproduction {
		public static void executeCarProduction(final String car) {
			System.out.println("Running " + Thread.currentThread().getName());
			try {
				for (int i = 4; i > 0; i--) {
					System.out.println("Thread: "
							+ Thread.currentThread().getName() + ", " + i);
					// Let the thread sleep for a while.
					Thread.sleep(50);
				}
				produceCar(car);

			} catch (InterruptedException e) {
				System.out.println("Thread " + Thread.currentThread().getName()
						+ " interrupted.");
			} catch (Exception e) {
				System.out.println("Thread " + Thread.currentThread().getName()
						+ " error.");
			}
			System.out.println("Thread " + Thread.currentThread().getName()
					+ " exiting.");
		}

		private static void produceCar(final String car) throws Exception {
			Factory factory = ThreadsafeCarFactory.getUniqueInstance();
			CarType carType = factory.createCars(car);
			System.out.println(carType.print() + " by "
					+ Thread.currentThread().getName());
			System.out.println("cars produced " + factory.counter());
		}
	}
}
