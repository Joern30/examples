package tasks.task5;

public class SingletonTest1 {
	   public static void main(String args[]) {
	   
		  LimousineDemo1 R1 = new LimousineDemo1( "Thread-1");
	      R1.start();
	      
	      MiniVanDemo1 R2 = new MiniVanDemo1( "Thread-2");
	      R2.start();

	      LimousineDemo1 R3 = new LimousineDemo1( "Thread-3");
	      R3.start();
	      
	      MiniVanDemo1 R4 = new MiniVanDemo1( "Thread-4");
	      R4.start();
	   }   
	}
