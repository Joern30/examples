package tasks.task7;

import org.junit.Assert;
import org.junit.Test;

/**
 * Unit test for RotN.
 */
public class RotNTest


{
	private String compare = "HELLO, WORLD";
	private String input = "Hello, World";
	private final int displacement = 13;
	
	private RotN rot = new RotN(displacement);
	/**
	 *
	 */
	@Test
	public void doRotN() {
		
		String testString = this.rot.rotN(this.rot.rotN(input));
		
		Assert.assertTrue(testString.equals(compare));

	}

}
