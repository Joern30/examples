package tasks.task4;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.namespace.QName;
import javax.xml.transform.stream.StreamSource;

import org.junit.Test;

import tasks.task4.Country;
import tasks.task4.State;

/**
 * Unit test for XML processing with JAXB.
 */
public class XMLProcessingTest

{

	/**
	 *
	 */
	@Test
	public void doXMLProcessing() {

		// creating country object
		Country countryGermany = new Country();
		countryGermany.setCountryName("Germany");
		countryGermany.setCountryPopulation(5000000);

		// Creating listOfStates
		List<State> stateList = new ArrayList<State>();
		State hamburg = new State("Hamburg", 2000000);
		stateList.add(hamburg);
		State bremen = new State("Bremen", 500000);
		stateList.add(bremen);

		countryGermany.setListOfStates(stateList);

		try {

			// create JAXB context and initializing Marshaller
			JAXBContext jaxbContext = JAXBContext.newInstance(Country.class);
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

			// for getting nice formatted output
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,
					Boolean.TRUE);

			// specify the location and name of xml file to be created
			File XMLfile = new File("Country.xml");
			// Writing to XML file
			jaxbMarshaller.marshal(countryGermany, XMLfile);
			// Writing to console
			jaxbMarshaller.marshal(countryGermany, System.out);

			// // unmarshalling /////
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();

			// this will create Java object - country from the XML file
			Country countryGermany1 = (Country) jaxbUnmarshaller
					.unmarshal(XMLfile);

			System.out.println("Country Name: "
					+ countryGermany1.getCountryName());
			System.out.println("Country Population: "
					+ countryGermany1.getCountryPopulation());

			List<State> listOfStates = countryGermany1.getListOfStates();

			assertTrue(listOfStates.size() == stateList.size());

			int i = 0;
			for (State state : listOfStates) {
				assertTrue(stateList.get(i).getStateName()
						.equals(state.getStateName()));
				i++;
				System.out.println("State:" + i + ' ' + state.getStateName());
			}
			XMLfile.deleteOnExit();
		} catch (JAXBException e) {
			// some exception occured
			e.printStackTrace();
			fail();
		}

	}

	/**
	 *
	 */
	@Test
	public void doXMLProcessingWithCodeGeneration() {

		// creating city,ForeignCountry object
		City foreignCity = new City();
		foreignCity.setName("Sydney");
		foreignCity.setFoundation(20000);
		ForeignCountry countryAustralia = new ForeignCountry();
		countryAustralia.setCapital(foreignCity);
		try {

			// create JAXB context and initializing Marshaller
			JAXBContext jaxbContext = JAXBContext
					.newInstance(ForeignCountry.class);
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

			// for getting nice formatted output
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,
					Boolean.TRUE);

			// specify the location and name of xml file to be created
			File XMLfile = new File("ForeignCountry.xml");
			// Writing to console
			jaxbMarshaller.marshal(new JAXBElement<ForeignCountry>(new QName(
					"uri", "local"), ForeignCountry.class, countryAustralia),
					System.out);
			// Writing to XML file
			jaxbMarshaller.marshal(new JAXBElement<ForeignCountry>(new QName(
					"uri", "local"), ForeignCountry.class, countryAustralia),
					XMLfile);

			// // unmarshalling /////
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();

			// this will create Java object - ForeignCountry from the XML file
			JAXBElement<ForeignCountry> userElement = jaxbUnmarshaller
					.unmarshal(new StreamSource(XMLfile), ForeignCountry.class);
			ForeignCountry countryAustralia1 = userElement.getValue();

			assertTrue(foreignCity.getName().equals(
					countryAustralia1.getCapital().getName()));
			XMLfile.deleteOnExit();
		} catch (JAXBException e) {
			// some exception occured
			e.printStackTrace();
			fail();
		}
	}

}
