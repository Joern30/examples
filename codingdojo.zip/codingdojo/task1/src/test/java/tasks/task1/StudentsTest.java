package tasks.task1;

import static org.junit.Assert.assertTrue;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class StudentsTest {

	private String expectedStudentName;
	private int expectedStudentNr;

	@Before
	public void setUp() {
		expectedStudentName = "Albert Einstein";
		expectedStudentNr = 5421;

	}

	/**
     * 
     */
	@Test
	public void sortStudents() {
		Student[] students = new Student[3];

		Student einstein = new Student(0054, "Albert Einstein");
		Student leibniz = new Student(1234, "Gottfried Wilhelm Leibniz");
		Student gauss = new Student(5421, "Carl Friedrich Gauss");

		students[0] = einstein;
		students[1] = leibniz;
		students[2] = gauss;
		System.out.println("ascending sort order:");
		//ascending sort order
		Arrays.sort(students);

		int i = 0;
		assertTrue(students[i].getName().equals(expectedStudentName));
		for (Student stud : students) {
			System.out.println("Students " + ++i + " : " + stud.getId()
					+ ", Name : " + stud.getName());
		}

	}

	/**
     * 
     */
	@Test
	public void sortStudentsWithComparator() {
		Student[] students = new Student[3];

		Student einstein = new Student(0054, "Albert Einstein");
		Student leibniz = new Student(1234, "Gottfried Wilhelm Leibniz");
		Student gauss = new Student(5421, "Carl Friedrich Gauss");

		students[0] = einstein;
		students[1] = leibniz;
		students[2] = gauss;
		System.out.println("descending sort order:");
		//descending sort order
		Arrays.sort(students, Student.StudenttNameComparator);
		int i = 0;
		assertTrue(students[1].getId() == expectedStudentNr);
		for (Student stud : students) {
			System.out.println("Students " + ++i + " : " + stud.getId()
					+ ", Name : " + stud.getName());
		}

	}

}
