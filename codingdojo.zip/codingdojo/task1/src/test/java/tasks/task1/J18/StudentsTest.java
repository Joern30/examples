package tasks.task1.J18;

import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;

import org.junit.Before;
import org.junit.Test;

import tasks.task1.Student;

/**
 * Unit test for simple App.
 */
public class StudentsTest {

	private Integer counter = 0;
	private String expectedStudentName;
	private int expectedStudentNr;

	@Before
	public void setUp() {
		expectedStudentName = "Albert Einstein";
		expectedStudentNr = 5421;

	}

	/**
     * 
     */
	@Test
	public void sortStudents() {
		Student[] students = new Student[3];

		Student einstein = new Student(0054, "Albert Einstein");
		Student leibniz = new Student(1234, "Gottfried Wilhelm Leibniz");
		Student gauss = new Student(5421, "Carl Friedrich Gauss");

		students[0] = einstein;
		students[1] = leibniz;
		students[2] = gauss;
		System.out.println("ascending sort order by name:");
		//ascending sort order
		Arrays.sort(students);

		int i = 0;
		assertTrue(students[i].getName().equals(expectedStudentName));
		assertTrue(students[i+1].getId()==(expectedStudentNr));
		for (Student stud : students) {
			System.out.println("Students " + ++i + " : " + stud.getId()
					+ ", Name : " + stud.getName());
		}

		Arrays.asList(students).stream().forEach(student -> System.out.println("Student: " + ++counter + " : "+ student.getId()  + ", Name : "
								+ student.getName()));
	}

	/**
     * 
     */
	@Test
	public void sortStudentsWithComparator() {
		Student[] students = new Student[3];

		Student einstein = new Student(0054, "Albert Einstein");
		Student leibniz = new Student(1234, "Gottfried Wilhelm Leibniz");
		Student gauss = new Student(5421, "Carl Friedrich Gauss");

		students[0] = einstein;
		students[1] = leibniz;
		students[2] = gauss;
		System.out.println("descending sort order by name:");
		//descending sort order
		Arrays.sort(students, (student1, student2) -> String.CASE_INSENSITIVE_ORDER.compare(student2.getName().toUpperCase(), student1.getName().toUpperCase()));
		int i = 0;
		assertTrue(students[1].getId() == expectedStudentNr);
		for (Student stud : students) {
			System.out.println("Students " + ++i + " : " + stud.getId()
					+ ", Name : " + stud.getName());
		}
		Arrays.sort(students, (student1, student2) -> Student.StudenttNameComparator.compare(student1, student2));
		i = 0;
		for (Student stud : students) {
			System.out.println("Students " + ++i + " : " + stud.getId()
					+ ", Name : " + stud.getName());
		}
	}

	/**
     * 
     */
	@Test
	public void sortStudentsWithComparator1() {
		Function<Student, Integer> studentIdFunction = (Student stud)->{ return stud.getId();};
		Student[] students = new Student[3];

		Student einstein = new Student(0054, "Albert Einstein");
		Student leibniz = new Student(1234, "Gottfried Wilhelm Leibniz");
		Student gauss = new Student(5421, "Carl Friedrich Gauss");

		students[0] = einstein;
		students[1] = leibniz;
		students[2] = gauss;
		System.out.println("descending sort order by id:");
		//descending sort order
		List<Student> people = Arrays.asList(students);
		
		Comparator<Student> comp = Comparator.comparing(Student::getId).reversed();
		people.sort(comp);
		assertTrue(people.get(0).getId() == expectedStudentNr);
		people.stream().forEach((person) -> System.out.format("Student: %s\n" , person.getName()));
		
		people.stream().map(studentIdFunction).forEach(id->System.out.println("Student id: " + id));
		
		System.out.println("descending sort order by name:");
		Arrays.sort(students,  Comparator.comparing(Student::getName).reversed());
		for (Student stud : students) {
			System.out.println("Student" + " : " + stud.getId()
					+ ", Name : " + stud.getName());
		}
		
		people.stream().map(s->s.getName()).forEach(string->System.out.println(string));
	}

}
