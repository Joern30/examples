package tasks.task3;

import javax.xml.bind.DatatypeConverter;

import org.junit.Assert;
import org.junit.Test;

/**
 * Unit test for Base64.
 */
public class Base64Test


{
	String s1 = "Testing DatatypeConverter.printBase64Binary";

	/**
	 *
	 */
	@Test
	public void doBase64() {
		
		String testString = this.base64ToString(this.stringToBase64(s1));
		
		Assert.assertTrue(testString.equals(s1));

	}

	private String stringToBase64(final String toConver){

		String encodeds1 = DatatypeConverter.printBase64Binary(s1.getBytes());
		System.out.println(encodeds1);
		return encodeds1;
	}
	private String base64ToString(final String convertFrom){
		byte[] decodeds1= DatatypeConverter.parseBase64Binary(convertFrom);
		System.out.println(new String(decodeds1));
		return (new String(decodeds1));
	}
}
