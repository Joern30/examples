package tasks.task8;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class OrderedJobTest {

	public OrderedJobTest() {
	}

	@Test
	public void sortTest() {
		OrderedJobsRegistry registry = new OrderedJobsRegistry();
		registry.register('a');
		registry.register('b', 'a');
		registry.register('a');
		registry.register('c', 'd');
		registry.register('a', 'b');
		registry.register('k');

		System.out.println("unsorted");
		for (Job theJob : registry.getRegisteredJobs()) {
			System.out.println(theJob);

		}
		
		assertTrue(registry.sort().equals("abcdk"));
		
	}
	@Test
	public void sortTest1() {
		OrderedJobsRegistry registry = new OrderedJobsRegistry();
		registry.register('k');
		registry.register('a', 'b');
		registry.register('c', 'd');
		registry.register('a');
		registry.register('b', 'a');
		registry.register('a');
		registry.register('a', 'd');
		registry.register('k', 'd');
		registry.register('a', 'b');

		System.out.println("unsorted");
		for (Job theJob : registry.getRegisteredJobs()) {
			System.out.println(theJob);

		}
		
		assertTrue(registry.sort().equals("abcdk"));
		
	}
}

