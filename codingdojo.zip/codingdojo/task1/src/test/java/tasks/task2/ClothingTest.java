package tasks.task2;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Unit test for Clothing.
 */
public class ClothingTest

{

	/**
	 * Rigourous Test :-)
	 */
	@Test
	public void showClothing() {
		Clothing showClothing = new Clothing(5, "leather", "coat", "handmade",
				250);
		assertTrue(showClothing.description.equals("handmade"));
		System.out.println(showClothing);

	}
}
