package tasks.task9;

import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * BoundedBlockingQueueSemaphoreWithExecutorTest using Executor framework and
 * BlockingQueue using semaphors from java.concurrent package
 * 
 * @author Jörn Scheffler
 *
 */
public class BoundedBlockingQueueSemaphoreWithExecutorTest extends
		BoundedBlockingQueueWithExecutorTest {

	private final int capacity = 2;

	private BoundedBlockingQueueSemaphore<Job> blockQueue;
	private Job jobWrite;
	private Job jobWrite1;
	private Job jobWrite2;
	private Job jobWrite3;
	private JobDemo[] jobs;
	private ExecutorService executor;
	private Random random;
	private Semaphore notFull;
	private Semaphore notEmpty;

	@Before
	public void setUp() {
		System.out
				.println("///// in  BoundedBlockingQueueSemaphoreWithExecutorTest using Executor framework and"
						+ System.getProperty("line.separator")
						+ "BlockingQueue using semaphors from java.concurrent package setUp //////");
		blockQueue = new BlockingQueueSemaphore<Job>(capacity);
		notFull = blockQueue.getWriteSemaphore();
		notEmpty = blockQueue.getReadSemaphore();

		jobWrite = new Job('a', 'b');
		jobWrite1 = new Job('b', 'c');
		jobWrite2 = new Job('d', 'd');
		jobWrite3 = new Job('e', 'f');
		// Create an executor of thread pool size 3
		executor = Executors.newFixedThreadPool(3);

	}

	@Test
	public void threadsWriteTest() {
		System.out.println(Thread.currentThread().getName() + " is started");
		System.out.println("///////  threadsWriteTest TEST //////////");

		WriteJobDemo writeRunnable1 = new WriteJobDemo("WriteJobDemo-1",
				blockQueue, jobWrite);
		WriteJobDemo writeRunnable2 = new WriteJobDemo("WriteJobDemo-2",
				blockQueue, jobWrite1);
		WriteJobDemo writeRunnable3 = new WriteJobDemo("WriteJobDemo-3",
				blockQueue, jobWrite2);
		WriteJobDemo writeRunnable4 = new WriteJobDemo("WriteJobDemo-4",
				blockQueue, jobWrite3);
		jobs = new JobDemo[] { writeRunnable1, writeRunnable2, writeRunnable3,
				writeRunnable4 };

		// Sum up wait times to know when to shutdown
		int waitTime = 600;
		this.execution(waitTime, executor, jobs, blockQueue);

	}

	@Test
	public void threadsWriteTestWithExecutionSubmit() {
		System.out.println(Thread.currentThread().getName() + " is started");
		System.out
				.println("///////  threadsWriteTestWithExecutionSubmit() TEST //////////");

		WriteJobDemo writeRunnable1 = new WriteJobDemo("WriteJobDemo-1",
				blockQueue, jobWrite);
		WriteJobDemo writeRunnable2 = new WriteJobDemo("WriteJobDemo-2",
				blockQueue, jobWrite1);
		WriteJobDemo writeRunnable3 = new WriteJobDemo("WriteJobDemo-3",
				blockQueue, jobWrite2);
		WriteJobDemo writeRunnable4 = new WriteJobDemo("WriteJobDemo-4",
				blockQueue, jobWrite3);
		jobs = new JobDemo[] { writeRunnable1, writeRunnable2, writeRunnable3,
				writeRunnable4 };

		// Sum up wait times to know when to shutdown
		int waitTime = 600;
		this.executionSubmit(waitTime);

	}

	@Test
	public void threadsReadTest() {
		System.out.println("/////// threadsReadTest()  TEST //////////");
		jobWrite = new Job('a', 'b');
		int waitTime = 600;
		ReadJobDemo readRunnable1 = new ReadJobDemo("ReadJobDemo-1", blockQueue);
		ReadJobDemo readRunnable2 = new ReadJobDemo("ReadJobDemo-2", blockQueue);
		jobs = new JobDemo[] { readRunnable1, readRunnable2, };
		execution(waitTime, executor, jobs, blockQueue);
		assertTrue(this.blockQueue.size() == 0);
		this.cleanUpJobDemos(jobs, notFull, notEmpty);
		// Create an executor of thread pool size 3
		executor = Executors.newFixedThreadPool(3);

		blockQueue = new BlockingQueueSemaphore<Job>(capacity);
		notFull = blockQueue.getWriteSemaphore();
		notEmpty = blockQueue.getReadSemaphore();

		WriteJobDemo writeRunnable1 = new WriteJobDemo("WriteJobDemo-1",
				blockQueue, jobWrite);
		WriteJobDemo writeRunnable2 = new WriteJobDemo("WriteJobDemo-2",
				blockQueue, jobWrite1);
		WriteJobDemo writeRunnable3 = new WriteJobDemo("WriteJobDemo-3",
				blockQueue, jobWrite);
		WriteJobDemo writeRunnable4 = new WriteJobDemo("WriteJobDemo-4",
				blockQueue, jobWrite1);
		jobs = new JobDemo[] { writeRunnable1, writeRunnable2, writeRunnable3,
				writeRunnable4 };
		waitTime = waitTime * 2;
		// Sum up wait times to know when to shutdown
		execution(waitTime, executor, jobs, blockQueue);
	}

	@Test
	public void threadsReadTestWithExecutionSubmit() {
		System.out
				.println("/////// threadsReadTestWitExecutionSubmit  TEST //////////");
		jobWrite = new Job('a', 'b');
		int waitTime = 600;
		ReadJobDemo readRunnable1 = new ReadJobDemo("ReadJobDemo-1", blockQueue);
		ReadJobDemo readRunnable2 = new ReadJobDemo("ReadJobDemo-2", blockQueue);
		jobs = new JobDemo[] { readRunnable1, readRunnable2 };

		this.executionSubmit(waitTime);
		assertTrue(this.blockQueue.size() == 0);
		this.cleanUpJobDemos(jobs, notFull, notEmpty);
		// Create an executor of thread pool size 3
		executor = Executors.newFixedThreadPool(3);

		blockQueue = new BlockingQueueSemaphore<Job>(capacity);
		notFull = blockQueue.getWriteSemaphore();
		notEmpty = blockQueue.getReadSemaphore();
		WriteJobDemo writeRunnable1 = new WriteJobDemo("WriteJobDemo-1",
				blockQueue, jobWrite);
		WriteJobDemo writeRunnable2 = new WriteJobDemo("WriteJobDemo-2",
				blockQueue, jobWrite1);
		WriteJobDemo writeRunnable3 = new WriteJobDemo("WriteJobDemo-3",
				blockQueue, jobWrite);
		WriteJobDemo writeRunnable4 = new WriteJobDemo("WriteJobDemo-4",
				blockQueue, jobWrite1);
		jobs = new JobDemo[] { writeRunnable1, writeRunnable2, writeRunnable3,
				writeRunnable4 };
		// Sum up wait times to know when to shutdown
		this.executionSubmit(waitTime);
	}

	@Test
	public void threadsReadWriteTest() {
		System.out.println("/////// threadsReadTest  TEST //////////");
		jobWrite = new Job('a', 'b');
		WriteJobDemo writeRunnable1 = new WriteJobDemo("WriteJobDemo-1",
				blockQueue, jobWrite);
		WriteJobDemo writeRunnable2 = new WriteJobDemo("WriteJobDemo-2",
				blockQueue, jobWrite1);
		WriteJobDemo writeRunnable3 = new WriteJobDemo("WriteJobDemo-3",
				blockQueue, jobWrite2);
		ReadJobDemo readRunnable1 = new ReadJobDemo("ReadJobDemo-1", blockQueue);
		WriteJobDemo writeRunnable4 = new WriteJobDemo("WriteJobDemo-4",
				blockQueue, jobWrite3);
		ReadJobDemo readRunnable2 = new ReadJobDemo("ReadJobDemo-2", blockQueue);
		jobs = new JobDemo[] { writeRunnable1, writeRunnable2, writeRunnable3,
				readRunnable1, writeRunnable4, readRunnable2 };
		// Sum up wait times to know when to shutdown
		int waitTime = 600;
		this.execution(waitTime, executor, jobs, blockQueue);
	}

	@Test
	public void threadsReadWriteTestWithExecutionSubmit() {
		System.out.println("/////// threadsReadTest  TEST //////////");
		jobWrite = new Job('a', 'b');
		WriteJobDemo writeRunnable1 = new WriteJobDemo("WriteJobDemo-1",
				blockQueue, jobWrite);
		WriteJobDemo writeRunnable2 = new WriteJobDemo("WriteJobDemo-2",
				blockQueue, jobWrite1);
		WriteJobDemo writeRunnable3 = new WriteJobDemo("WriteJobDemo-3",
				blockQueue, jobWrite2);
		ReadJobDemo readRunnable1 = new ReadJobDemo("ReadJobDemo-1", blockQueue);
		WriteJobDemo writeRunnable4 = new WriteJobDemo("WriteJobDemo-4",
				blockQueue, jobWrite3);
		ReadJobDemo readRunnable2 = new ReadJobDemo("ReadJobDemo-2", blockQueue);
		jobs = new JobDemo[] { writeRunnable1, writeRunnable2, writeRunnable3,
				readRunnable1, writeRunnable4, readRunnable2 };
		// Sum up wait times to know when to shutdown
		int waitTime = 600;
		this.executionSubmit(waitTime);
	}

	private void executionSubmit(int waitTime) {

		final List<Future<?>> results = new ArrayList<Future<?>>();
		random = this.createRandom();
		for (JobDemo jobDemo : jobs) {

			int time = random.nextInt(500);
			waitTime += time;
			System.out.println("Adding: " + jobDemo.getName() + " / " + time);
			results.add(executor.submit(jobDemo));

		}
		try {
			Thread.sleep(waitTime * 10);
			// cleanup waiting threads
			this.cleanUpJobDemos(jobs, notFull, notEmpty);
			for (Future<?> future : results) {
				try {
					assertNull(future.get(waitTime, TimeUnit.SECONDS));
				} catch (ExecutionException e) {
					e.printStackTrace();
				} catch (TimeoutException e) {
					e.printStackTrace();
				}

			}
			executor.shutdown();
			executor.awaitTermination(waitTime, TimeUnit.MILLISECONDS);
		} catch (InterruptedException ignored) {
			ignored.printStackTrace();
		}
	}

	@After
	public void tearDown() {

		System.out.println("///////   tearDown //////////");
		System.out.println("jobs list capacity in tearDown() "
				+ this.blockQueue.size());
		assertTrue(this.blockQueue.size() == 2);
		this.cleanUpJobDemos(jobs, notFull, notEmpty);
		assertTrue(this.blockQueue.size() == 2);
	}

	private void cleanUpJobDemos(final JobDemo[] jobs, final Semaphore notFull,
			final Semaphore notEmpty) {

		System.out.println("///////  cleanUpJobDemos //////////");
		for (JobDemo jobDemo : jobs) {

			jobDemo.requestStop();

			notFull.release();
			notEmpty.release();

		}

	}

}
