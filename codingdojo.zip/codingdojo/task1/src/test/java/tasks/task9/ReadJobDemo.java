package tasks.task9;

public class ReadJobDemo extends JobDemo implements Runnable {
	private Thread t;
	private String threadName;
	private Job jobRead;

	public ReadJobDemo(String name, BoundedBlockingQueue<Job> blockQueue) {
		super(blockQueue);
		threadName = name;
		System.out.println("Creating " + threadName);
	}

	public ReadJobDemo(String name, Runnable run,
			BoundedBlockingQueue<Job> blockQueue) {
		super(blockQueue);
		threadName = name;
		this.r = run;
		System.out.println("Creating " + threadName + "with Runnable");
	}

	public void run() {
		if (this.r == null) {
			System.out.println("Running " + threadName);
			this.jobRead = this.blockingQueue.remove();
		} else {
			this.r.run();
		}

	}

	public void start() {
		System.out.println("Starting " + threadName);
		if (t == null) {
			t = new Thread(this, threadName);
			t.start();
		}
	}

}
