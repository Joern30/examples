package tasks.task9;

import java.util.concurrent.BlockingDeque;

class WriteJobDemoBlockingDeque extends JobDemoDeque implements Runnable {
	private Thread t;
	private String threadName;
	private Job jobWrite;
	private int capacity;

	public WriteJobDemoBlockingDeque(String name,
			BlockingDeque<Job> blockQueue, Job jobWrite, int capacity) {
		super(blockQueue);
		threadName = name;
		System.out.println("Creating " + threadName);
		this.jobWrite = jobWrite;
		this.capacity = capacity;
	}

	public void run() {
		System.out.println("Running " + threadName);
		synchronized (blockingQueue) {
			try {
				while (blockingQueue.size() == this.capacity && !this.stop) {
					System.out.println(Thread.currentThread().getName()
							+ " waiting in add");
					try {
						blockingQueue.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				if (!this.stop) {
					System.out.println(Thread.currentThread().getName()
							+ " adds a Job to BlockingDeque");
					this.blockingQueue.add(this.jobWrite);
				}
				System.out.println("Thread " + threadName
						+ " exiting run method.");
			} finally {
				blockingQueue.notifyAll();
			}
		}
	}

	public void start() {
		System.out.println("Starting " + threadName);
		if (t == null) {
			t = new Thread(this, threadName);
			t.start();
		}
	}

	public JobDemoDeque add() {
		System.out.println("Running add " + threadName);
		lock.lock();
		System.out.println(Thread.currentThread().getName() + " blockingQueue.size(): " + blockingQueue.size());
		try {
			while (blockingQueue.size() == this.capacity && !this.stop) {
				try {
					System.out.println(Thread.currentThread().getName()
							+ " waiting in add");
					notFull.await();

				} catch (InterruptedException e) {
				}
			}

			if (!this.stop) {
				// bottom
				System.out.println(Thread.currentThread().getName()
						+ " adds a Job to BlockingDeque");
				this.blockingQueue.add(this.jobWrite);

				System.out.println("call notEmpty.signal() in add "
						+ Thread.currentThread().getName());
			}
			this.printReleaseMessage();
			notEmpty.signalAll();
		} finally {
			lock.unlock();
		}
		return this;
	}

}
