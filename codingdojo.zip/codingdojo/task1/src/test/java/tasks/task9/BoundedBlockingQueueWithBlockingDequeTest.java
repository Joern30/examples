package tasks.task9;

import static org.junit.Assert.assertTrue;

import java.util.concurrent.BlockingDeque;
import java.util.concurrent.LinkedBlockingDeque;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 *   BoundedBlockingQueueWithBlockingDequeTest using thread execution and LinkedBlockingDeque
 *  
 * @author Jörn Scheffler
 *
 */

public class BoundedBlockingQueueWithBlockingDequeTest {

	private final int capacity = 2;

	private BlockingDeque<Job> blockQueue;
	private Job jobWrite;
	private Job jobWrite1;
	private Job jobWrite2;
	private Job jobWrite3;
	private JobDemoDeque[] jobs;

	@Before
	public void setUp() {
		System.out.println("///// in  BoundedBlockingQueueWithBlockingDequeTest using thread execution and LinkedBlockingDeque setUp //////");
		blockQueue = new LinkedBlockingDeque<Job>(capacity);
		jobWrite = new Job('a', 'b');
		jobWrite1 = new Job('b', 'c');
		jobWrite2 = new Job('d', 'd');
		jobWrite3 = new Job('e', 'f');
	}

	@Test
	public void threadsWriteTest() {
		System.out.println(Thread.currentThread().getName() + " is started");
		System.out.println("///////  threadsWriteTest TEST //////////");

		WriteJobDemoBlockingDeque writeRunnable1 = new WriteJobDemoBlockingDeque("WriteJobDemoBlockingDeque-1",
				blockQueue, jobWrite, capacity);
		WriteJobDemoBlockingDeque writeRunnable2 = new WriteJobDemoBlockingDeque("WriteJobDemoBlockingDeque-2",
				blockQueue, jobWrite1, capacity);
		WriteJobDemoBlockingDeque writeRunnable3 = new WriteJobDemoBlockingDeque("WriteJobDemoBlockingDeque-3",
				blockQueue, jobWrite2, capacity);
		WriteJobDemoBlockingDeque writeRunnable4 = new WriteJobDemoBlockingDeque("WriteJobDemoBlockingDeque-4",
				blockQueue, jobWrite3, capacity);
		jobs = new JobDemoDeque[] { writeRunnable1, writeRunnable2, writeRunnable3,
				writeRunnable4 };
		execution();

	}

	private void cleanUpJobDemos(final JobDemoDeque[] jobs) {

		for (JobDemoDeque jobDemo : jobs) {

			jobDemo.requestStop();
			synchronized (blockQueue) {
				blockQueue.notifyAll();
			}

		}

	}

	@Test
	public void threadsReadTest() {
		System.out.println("/////// threadsReadTestSimple  TEST //////////");
		jobWrite = new Job('a', 'b');
		ReadJobDemoBlockingDeque readRunnable1 = new ReadJobDemoBlockingDeque("ReadJobDemoBlockingDeque-1", blockQueue);
		readRunnable1.start();
		ReadJobDemoBlockingDeque readRunnable2 = new ReadJobDemoBlockingDeque("ReadJobDemoBlockingDeque-2", blockQueue);
		readRunnable2.start();
		assertTrue(this.blockQueue.size() == 0);
		jobs = new JobDemoDeque[] { readRunnable1, readRunnable2 };
		WriteJobDemoBlockingDeque writeRunnable1 = new WriteJobDemoBlockingDeque("WriteJobDemoBlockingDeque-1",
				blockQueue, jobWrite, capacity);
		WriteJobDemoBlockingDeque writeRunnable2 = new WriteJobDemoBlockingDeque("WriteJobDemoBlockingDeque-2",
				blockQueue, jobWrite1, capacity);
		WriteJobDemoBlockingDeque writeRunnable3 = new WriteJobDemoBlockingDeque("WriteJobDemoBlockingDeque-3",
				blockQueue, jobWrite, capacity);
		WriteJobDemoBlockingDeque writeRunnable4 = new WriteJobDemoBlockingDeque("WriteJobDemoBlockingDeque-4",
				blockQueue, jobWrite1, capacity);
		jobs = new JobDemoDeque[] { writeRunnable1, writeRunnable2, writeRunnable3,
				writeRunnable4 };
		execution();
	}

	private void execution() {
		for (JobDemoDeque jobDemo : jobs) {

			jobDemo.start();

		}
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void threadsReadWriteTest() {
		System.out.println("/////// threadsReadTest  TEST //////////");
		jobWrite = new Job('a', 'b');
		WriteJobDemoBlockingDeque writeRunnable1 = new WriteJobDemoBlockingDeque("WriteJobDemoBlockingDeque-1",
				blockQueue, jobWrite, capacity);
		WriteJobDemoBlockingDeque writeRunnable2 = new WriteJobDemoBlockingDeque("WriteJobDemoBlockingDeque-2",
				blockQueue, jobWrite1, capacity);
		WriteJobDemoBlockingDeque writeRunnable3 = new WriteJobDemoBlockingDeque("WriteJobDemoBlockingDeque-3",
				blockQueue, jobWrite2, capacity);
		ReadJobDemoBlockingDeque readRunnable1 = new ReadJobDemoBlockingDeque("ReadJobDemoBlockingDeque-1", blockQueue);
		WriteJobDemoBlockingDeque writeRunnable4 = new WriteJobDemoBlockingDeque("WriteJobDemoBlockingDeque-4",
				blockQueue, jobWrite3, capacity);
		ReadJobDemoBlockingDeque readRunnable2 = new ReadJobDemoBlockingDeque("ReadJobDemoBlockingDeque-2", blockQueue);
		jobs = new JobDemoDeque[] { writeRunnable1, writeRunnable2, writeRunnable3,
				readRunnable1, writeRunnable4, readRunnable2 };
		execution();
	}

	@After
	public void tearDown() {
		System.out.println("///////   tearDown //////////");
		System.out.println("jobs list capacity in tearDown() "
				+ this.blockQueue.size());
		assertTrue(this.blockQueue.size() == 2);
		this.cleanUpJobDemos(jobs);
		assertTrue(this.blockQueue.size() == 2);
	}
}
