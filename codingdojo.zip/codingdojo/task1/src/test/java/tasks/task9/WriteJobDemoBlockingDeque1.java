package tasks.task9;

import java.util.concurrent.BlockingDeque;

class WriteJobDemoBlockingDeque1 extends JobDemoDeque implements Runnable {
	private Thread t;
	private String threadName;
	private Job jobWrite;
	private int capacity;
	

	public WriteJobDemoBlockingDeque1(String name,
			BlockingDeque<Job> blockQueue, Job jobWrite, int capacity) {
		super(blockQueue);
		threadName = name;
		System.out.println("Creating " + threadName);
		this.jobWrite = jobWrite;
		this.capacity = capacity;
	}

	public void run() {
		System.out.println("Running " + threadName);
		while (!this.blockingQueue.offerFirst(jobWrite) && !this.stop) {
			try {
				Thread.sleep(500);
				System.out.println(Thread.currentThread().getName()
						+ " waiting in add");
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		if (!this.stop) {
			System.out.println(Thread.currentThread().getName()
					+ " adds a Job to BlockingDeque");
		}
		System.out.println("Thread " + threadName + " exiting run method.");
	}

	public void start() {
		System.out.println("Starting " + threadName);
		if (t == null) {
			t = new Thread(this, threadName);
			t.start();
		}
	}

	public JobDemoDeque add() {
		while (!this.blockingQueue.offerFirst(jobWrite) && !this.stop) {
			try {
				Thread.sleep(500);
				System.out.println(Thread.currentThread().getName()
						+ " waiting in add");
			} catch (InterruptedException e) {
				System.out.println(Thread.currentThread().getName() +" interrupted");
				this.stop = true;
			}
		}
		if (!this.stop) {
			System.out.println(Thread.currentThread().getName()
					+ " adds a Job to BlockingDeque");
		}
		System.out.println("Thread " + threadName + " exiting run method.");
		return this;
	}

}
