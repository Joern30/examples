package tasks.task9;

public abstract class JobDemo extends Thread {

	protected volatile boolean stop = false;
	protected volatile boolean wroteQueue = false;
	protected volatile boolean removedQueue = false;
	protected BoundedBlockingQueue<Job> blockingQueue;
	protected Runnable r;
	public JobDemo() {
	}

	public JobDemo(final BoundedBlockingQueue<Job> blockQueue) {
		this.blockingQueue = blockQueue;
	}

	public void requestStop() {
		this.stop = true;
		this.blockingQueue.setReleaseWaitingThreads(this.stop);
		
	}
	public void resetStop() {
		this.stop = false;
		this.blockingQueue.setReleaseWaitingThreads(this.stop);
		
	}
}
