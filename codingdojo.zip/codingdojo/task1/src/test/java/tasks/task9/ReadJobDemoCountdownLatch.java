package tasks.task9;

import java.util.concurrent.CountDownLatch;

class ReadJobDemoCountdownLatch extends ReadJobDemo implements Runnable {
	private Thread t;
	private String threadName;
	private CountDownLatch latch;

	public ReadJobDemoCountdownLatch(String name,
			BoundedBlockingQueue<Job> blockQueue, CountDownLatch latch) {
		super(name, blockQueue);
		threadName = name;
		this.latch = latch;
	}

	public void run() {
		super.run();
		this.latch.countDown();

	}

	public void start() {
		System.out.println("Starting " + threadName);
		if (t == null) {
			t = new Thread(this, threadName);
			t.start();
		}
	}

}
