package tasks.task9;

import java.util.concurrent.BlockingDeque;

class ReadJobDemoBlockingDeque extends JobDemoDeque implements Runnable {
	private Thread t;
	private String threadName;
	private Job jobRead;

	public ReadJobDemoBlockingDeque(final String name,
			final BlockingDeque<Job> blockQueue) {
		super(blockQueue);
		threadName = name;
		System.out.println("Creating " + threadName);
	}

	public void run() {
		System.out.println("Running " + threadName);
		synchronized (blockingQueue) {
			try {

				while (this.blockingQueue.size() == 0 && !this.stop) {
					System.out.println(Thread.currentThread().getName()
							+ " waiting in remove");

					try {
						this.blockingQueue.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				if (!this.stop) {
					System.out.println(Thread.currentThread().getName()
							+ " removes a Job from BlockingDeque");
				}

				this.jobRead = this.blockingQueue.remove();
			} finally {
				this.blockingQueue.notifyAll();
			}
		}
	}

	public void start() {
		System.out.println("Starting " + threadName);
		if (t == null) {
			t = new Thread(this, threadName);
			t.start();
		}
	}

	public JobDemoDeque take() {
		System.out.println("Running take " + threadName);
		lock.lock();
		System.out.println(Thread.currentThread().getName()
				+ " blockingQueue.size(): " + blockingQueue.size());
		try {
			while (this.blockingQueue.isEmpty() && !this.stop) {
				try {
					System.out.println(Thread.currentThread().getName()
							+ " waiting in remove");
					notEmpty.await();
				} catch (InterruptedException e) {
				}
			}

			if (!this.stop) {
				// head
				this.jobRead = this.blockingQueue.removeFirst();
				System.out.println(this.jobRead + " removed by "
						+ Thread.currentThread().getName());

				System.out.println("jobs list capacity "
						+ this.blockingQueue.size());
				// if (oldCount == this.capacity) {
				System.out.println("call notFull.signal() in remove "
						+ Thread.currentThread().getName());
			}
			printReleaseMessage();
			notFull.signalAll();
			return this;
		} finally {
			lock.unlock();
		}

	}
}
