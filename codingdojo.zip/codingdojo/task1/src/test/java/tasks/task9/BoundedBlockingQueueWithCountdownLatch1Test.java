package tasks.task9;

import static org.junit.Assert.assertTrue;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * BoundedBlockingQueueWithCountdownLatchTest with CountdownLatch using thread
 * execution and old school sychronized JobBoundedBlockingQueue methods
 * 
 * @author Jörn Scheffler
 *
 */

public class BoundedBlockingQueueWithCountdownLatch1Test {

	private final int capacity = 2;

	private BoundedBlockingQueue<Job> blockQueue;
	private Job jobWrite;
	private Job jobWrite1;
	private Job jobWrite2;
	private Job jobWrite3;
	private JobDemo[] jobs;
	private CountDownLatch latch;

	@Before
	public void setUp() {
		System.out
				.println("///// in  BoundedBlockingQueueWithCountdownLatchTest with CountdownLatch using thread execution and old school sychronized JobBoundedBlockingQueue methods setUp //////");
		blockQueue = new JobBoundedBlockingQueue(capacity);
		jobWrite = new Job('a', 'b');
		jobWrite1 = new Job('b', 'c');
		jobWrite2 = new Job('d', 'd');
		jobWrite3 = new Job('e', 'f');
	}

	@Test
	public void threadsWriteTest() {
		System.out.println(Thread.currentThread().getName() + " is started");
		System.out.println("///////  threadsWriteTest TEST //////////");

		WriteJobDemo writeRunnable1 = null;
		WriteJobDemo writeRunnable2 = null;
		WriteJobDemo writeRunnable3 = null;
		WriteJobDemo writeRunnable4 = null;
		jobs = new JobDemo[] { writeRunnable1, writeRunnable2, writeRunnable3,
				writeRunnable4 };
		this.latch = new CountDownLatch(jobs.length);
		writeRunnable1 = new WriteJobDemoCountdownLatch(
				"WriteJobDemoCountdownLatch-1", blockQueue, jobWrite, latch);
		writeRunnable2 = new WriteJobDemoCountdownLatch(
				"WriteJobDemoCountdownLatch-2", blockQueue, jobWrite1, latch);
		writeRunnable3 = new WriteJobDemoCountdownLatch(
				"WriteJobDemoCountdownLatch-3", blockQueue, jobWrite2, latch);
		writeRunnable4 = new WriteJobDemoCountdownLatch(
				"WriteJobDemoCountdownLatch-4", blockQueue, jobWrite3, latch);
		jobs = new JobDemo[] { writeRunnable1, writeRunnable2, writeRunnable3,
				writeRunnable4 };
		execution();

	}

	@Test
	public void threadsReadTest() {
		System.out.println("/////// threadsReadTest  TEST //////////");
		jobWrite = new Job('a', 'b');
		ReadJobDemoCountdownLatch readRunnable1 = null;
		ReadJobDemoCountdownLatch readRunnable2 = null;
		WriteJobDemo writeRunnable1 = null;
		WriteJobDemo writeRunnable2 = null;
		WriteJobDemo writeRunnable3 = null;
		WriteJobDemo writeRunnable4 = null;
		jobs = new JobDemo[] { readRunnable1, readRunnable2, writeRunnable1,
				writeRunnable2, writeRunnable3, writeRunnable4 };
		this.latch = new CountDownLatch(jobs.length);
		readRunnable1 = new ReadJobDemoCountdownLatch(
				"ReadJobDemoCountdownLatch-1", blockQueue, latch);
		readRunnable2 = new ReadJobDemoCountdownLatch(
				"ReadJobDemoCountdownLatch-2", blockQueue, latch);
		assertTrue(((JobBoundedBlockingQueue) this.blockQueue).size() == 0);
		jobs = new JobDemo[] { readRunnable1, readRunnable2 };
		writeRunnable1 = new WriteJobDemoCountdownLatch("WriteJobDemoCountdownLatch-1", blockQueue,
				jobWrite, latch);
		writeRunnable2 = new WriteJobDemoCountdownLatch("WriteJobDemoCountdownLatch-2", blockQueue,
				jobWrite1, latch);
		writeRunnable3 = new WriteJobDemoCountdownLatch("WriteJobDemoCountdownLatch-3", blockQueue,
				jobWrite, latch);
		writeRunnable4 = new WriteJobDemoCountdownLatch("WriteJobDemoCountdownLatch-4", blockQueue,
				jobWrite1, latch);
		jobs = new JobDemo[] { readRunnable1, readRunnable2, writeRunnable1,
				writeRunnable2, writeRunnable3, writeRunnable4 };
		execution();
	}

	@Test
	public void threadsReadWriteTest() {
		System.out.println("/////// threadsReadWriteTest  TEST //////////");
		jobWrite = new Job('a', 'b');
		ReadJobDemoCountdownLatch readRunnable1 = null;
		ReadJobDemoCountdownLatch readRunnable2 = null;
		WriteJobDemo writeRunnable1 = null;
		WriteJobDemo writeRunnable2 = null;
		WriteJobDemo writeRunnable3 = null;
		WriteJobDemo writeRunnable4 = null;
		jobs = new JobDemo[] { readRunnable1, readRunnable2, writeRunnable1,
				writeRunnable2, writeRunnable3, writeRunnable4 };
		this.latch = new CountDownLatch(jobs.length);
		writeRunnable1 = new WriteJobDemoCountdownLatch("WriteJobDemoCountdownLatch-1",
				blockQueue, jobWrite, latch);
		writeRunnable2 = new WriteJobDemoCountdownLatch("WriteJobDemoCountdownLatch-2",
				blockQueue, jobWrite1, latch);
		writeRunnable3 = new WriteJobDemoCountdownLatch("WriteJobDemoCountdownLatch-3",
				blockQueue, jobWrite2, latch);
		readRunnable1 = new ReadJobDemoCountdownLatch(
				"ReadJobDemoCountdownLatch-1", blockQueue, latch);
		writeRunnable4 = new WriteJobDemoCountdownLatch("WriteJobDemoCountdownLatch-4",
				blockQueue, jobWrite3, latch);
		readRunnable2 = new ReadJobDemoCountdownLatch(
				"ReadJobDemoCountdownLatch-2", blockQueue, latch);
		jobs = new JobDemo[] { writeRunnable1, writeRunnable2, writeRunnable3,
				readRunnable1, writeRunnable4, readRunnable2 };
		execution();
	}

	private void execution() {
		for (JobDemo jobDemo : jobs) {

			jobDemo.start();

		}
		try {
			while (latch.getCount() > 0) {
				Thread.sleep(5);
				System.out.println("latch.getCount() called:"
						+ latch.getCount());
				this.latch.await(1, TimeUnit.MILLISECONDS);
				this.cleanUpJobDemos(jobs);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	private void cleanUpJobDemos(final JobDemo[] jobs) {

		for (JobDemo jobDemo : jobs) {

			jobDemo.requestStop();
			synchronized (blockQueue) {
				blockQueue.notifyAll();
			}

		}

	}

	@After
	public void tearDown() {
		System.out.println("///////   tearDown //////////");
		System.out.println("jobs list capacity in tearDown() "
				+ this.blockQueue.size());
		assertTrue(this.blockQueue.size() == 2);
		this.cleanUpJobDemos(jobs);
		assertTrue(this.blockQueue.size() == 2);
	}
}
