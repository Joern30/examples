package tasks.task9;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * BoundedBlockingQueueConcurrentWithExecutorTest using Executor framework and
 * JobBoundedBlockingQueueConcurrent using locks from java.concurrent package
 * 
 * @author Jörn Scheffler
 *
 */
public class BoundedBlockingQueueConcurrentCallableWithExecutorTest 
		 {

	private final int capacity = 2;

	private BlockingDeque<Job> blockQueue;
	private Job jobWrite;
	private Job jobWrite1;
	private Job jobWrite2;
	private Job jobWrite3;
	private List<String> jobs;
	private List<String> jobsRead;
	private List<JobDemoDeque> jobDemoDeques;

	private ExecutorService executor;
	private Random random;

	@Before
	public void setUp() {
		System.out
				.println("///// in BoundedBlockingQueueConcurrentCallableWithExecutorTest using Executor framework and"
						+ System.getProperty("line.separator")
						+ "LinkedBlockingDeque using locks from java.concurrent package setUp //////");
		blockQueue = new LinkedBlockingDeque<Job>(capacity);
		jobDemoDeques = new ArrayList<JobDemoDeque>();

		jobWrite = new Job('a', 'b');
		jobWrite1 = new Job('b', 'c');
		jobWrite2 = new Job('d', 'd');
		jobWrite3 = new Job('e', 'f');
		// Create an executor of thread pool size 3
		executor = Executors.newFixedThreadPool(20);
		random = new Random();

	}

	@Test
	public void threadsWriteTestWithExecutionSubmit() {
		System.out.println(Thread.currentThread().getName() + " is started");
		System.out
				.println("///////  threadsWriteTestWithExecutionSubmit() TEST //////////");

		this.jobs = new ArrayList<String>();
		for (int i = 1; i <= 4; i++) {

			this.jobs.add("WriteJobDemoDeque-" + i);
		}

		// Sum up wait times to know when to shutdown
		int waitTime = 600;
		this.executionSubmit(waitTime);

	}

	@Test
	public void threadsReadTestWithExecutionSubmit() {
		System.out
				.println("/////// threadsReadTestWitExecutionSubmit  TEST //////////");
		jobWrite = new Job('a', 'b');
		this.jobs = new ArrayList<String>();
		this.jobsRead = new ArrayList<String>();
		for (int i = 1; i <= 7; i++) {

			this.jobs.add("WriteJobDemoDeque-" + i);
		}
		for (int i = 1; i <= 4; i++) {

			this.jobsRead.add("ReadJobDemoDeque-" + i);
		}
		// Sum up wait times to know when to shutdown
		int waitTime = 600;
		this.executionSubmit(waitTime);
		this.jobsRead.clear();

	}

	@Test
	public void threadsReadWriteTestWithExecutionSubmit1() throws InterruptedException {
		System.out.println("/////// threadsReadWriteTestWithExecutionSubmit1  TEST //////////");
		final List<Future<JobDemoDeque>> results = new ArrayList<Future<JobDemoDeque>>();

		jobWrite = new Job('a', 'b');
		this.jobs = new ArrayList<String>();
		this.jobsRead = new ArrayList<String>();
		for (int i = 1; i <= 7; i++) {

			this.jobs.add("WriteJobDemoDeque-" + i);
		}
		for (int i = 1; i <= 4; i++) {

			this.jobsRead.add("ReadJobDemoDeque-" + i);
		}
		// Sum up wait times to know when to shutdown
		int waitTime = 600;
		this.executionSubmitTake(waitTime, results);
		this.executionSubmitAdd(waitTime, results);
		this.jobsRead.clear();
		this.jobs.clear();
		for (int i = 5; i <= 7; i++) {

			this.jobsRead.add("ReadJobDemoDeque-" + i);
		}
		this.executionSubmitTake(waitTime, results);
		this.jobsRead.clear();
		this.jobs.clear();
		for (int i = 7; i <= 10; i++) {

			this.jobs.add("WriteJobDemoDeque-" + i);
		}
		this.executionSubmitAdd(waitTime, results);
		this.jobsRead.clear();
		this.jobs.clear();

		try {
			Thread.sleep(waitTime * 10);
			// cleanup waiting threads
			this.cleanUpJobDemos(jobDemoDeques);
			for (Future<JobDemoDeque> future : results) {
				try {
					assertNotNull(future.get(waitTime, TimeUnit.SECONDS));
				} catch (ExecutionException e) {
					e.printStackTrace();
				} catch (TimeoutException e) {
					e.printStackTrace();
				}

			}
		} catch (InterruptedException ignored) {
			ignored.printStackTrace();
		}

		executor.shutdown();
		executor.awaitTermination(waitTime, TimeUnit.MILLISECONDS);

	}

	private void executionSubmit(int waitTime) {

		final List<Future<JobDemoDeque>> results = new ArrayList<Future<JobDemoDeque>>();
		if (this.jobsRead != null) {
			for (final String jobDemo : jobsRead) {
				int time = random.nextInt(500);
				waitTime += time;
				System.out.println("Adding: " + jobDemo + " / " + time);
				results.add(executor.submit(new Callable<JobDemoDeque>() {

					JobDemoDeque jobDeque;

					@Override
					public JobDemoDeque call() throws Exception {
						ReadJobDemoBlockingDeque deque = new ReadJobDemoBlockingDeque(
								jobDemo, blockQueue);
						jobDeque = deque;
						jobDemoDeques.add(jobDeque);
						return deque.take();
					}

				}));
			}
		}

		assertTrue(this.blockQueue.size() == 0);
		for (final String jobDemo : jobs) {
			int time = random.nextInt(500);
			waitTime += time;
			System.out.println("Adding: " + jobDemo + " / " + time);
			results.add(executor.submit(new Callable<JobDemoDeque>() {

				JobDemoDeque jobDeque;

				@Override
				public JobDemoDeque call() throws Exception {
					WriteJobDemoBlockingDeque deque = new WriteJobDemoBlockingDeque(
							jobDemo, blockQueue, jobWrite, capacity);
					jobDeque = deque;
					jobDemoDeques.add(jobDeque);
					return deque.add();
				}

			}));

		}
		try {
			Thread.sleep(waitTime * 10);
			// cleanup waiting threads
			this.cleanUpJobDemos(jobDemoDeques);
			for (Future<JobDemoDeque> future : results) {
				try {
					assertNotNull(future.get(waitTime, TimeUnit.SECONDS));
				} catch (ExecutionException e) {
					e.printStackTrace();
				} catch (TimeoutException e) {
					e.printStackTrace();
				}

			}
			executor.shutdown();
			executor.awaitTermination(waitTime, TimeUnit.MILLISECONDS);
		} catch (InterruptedException ignored) {
			ignored.printStackTrace();
		}
	}

	private void executionSubmitAdd(int waitTime, final List<Future<JobDemoDeque>> results) {

		for (final String jobDemo : jobs) {
			int time = random.nextInt(500);
			waitTime += time;
			System.out.println("Adding: " + jobDemo + " / " + time);
			results.add(executor.submit(new Callable<JobDemoDeque>() {

				JobDemoDeque jobDeque;

				@Override
				public JobDemoDeque call() throws Exception {
					WriteJobDemoBlockingDeque deque = new WriteJobDemoBlockingDeque(
							jobDemo, blockQueue, jobWrite, capacity);
					jobDeque = deque;
					jobDemoDeques.add(jobDeque);
					return deque.add();
				}

			}));

		}
	}

	private void executionSubmitTake(int waitTime, final List<Future<JobDemoDeque>> results) {

		if (this.jobsRead != null) {
			for (final String jobDemo : jobsRead) {
				int time = random.nextInt(500);
				waitTime += time;
				System.out.println("Adding: " + jobDemo + " / " + time);
				results.add(executor.submit(new Callable<JobDemoDeque>() {

					JobDemoDeque jobDeque;

					@Override
					public JobDemoDeque call() throws Exception {
						ReadJobDemoBlockingDeque deque = new ReadJobDemoBlockingDeque(
								jobDemo, blockQueue);
						jobDeque = deque;
						jobDemoDeques.add(jobDeque);
						return deque.take();
					}

				}));
			}
		}

	}

	@After
	public void tearDown() {

		System.out.println("///////   tearDown //////////");
		System.out.println("jobs list capacity in tearDown() "
				+ this.blockQueue.size());
		assertTrue(this.blockQueue.size() == 2);
		this.cleanUpJobDemos(this.jobDemoDeques);
		assertTrue(this.blockQueue.size() == 2);
	}

	private void cleanUpJobDemos(final List<JobDemoDeque> jobs) {

		for (JobDemoDeque jobDemo : jobs) {

			jobDemo.requestStop();
			JobDemoDeque.lock.lock();
			JobDemoDeque.notEmpty.signalAll();
			JobDemoDeque.notFull.signalAll();
			JobDemoDeque.lock.unlock();
		}

	}

}
