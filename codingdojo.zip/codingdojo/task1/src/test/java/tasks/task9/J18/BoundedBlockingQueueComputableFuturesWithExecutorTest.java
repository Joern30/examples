package tasks.task9.J18;

import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.function.Consumer;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import tasks.task9.BoundedBlockingQueue;
import tasks.task9.Job;
import tasks.task9.JobBoundedBlockingQueue;
import tasks.task9.JobDemo;
import tasks.task9.ReadJobDemo;
import tasks.task9.WriteJobDemo;

/**
 * BoundedBlockingQueueWithExecutorTest using Executor framework and old school
 * sychronized JobBoundedBlockingQueue methods
 * 
 * @author Jörn Scheffler
 *
 */
public class BoundedBlockingQueueComputableFuturesWithExecutorTest {

	private final int capacity = 2;

	private final BoundedBlockingQueue<Job> blockQueue = new JobBoundedBlockingQueue(
			capacity);
	private final Job jobWrite = new Job('a', 'b');
	private final Job jobWrite1 = new Job('b', 'c');
	private final Job jobWrite2 = new Job('d', 'd');
	private final Job jobWrite3 = new Job('e', 'f');
	private JobDemo[] jobs;
	private ExecutorService executor;
	private Random random;
	final String threadname1 = "WriteJobDemo-1";
	final String threadname2 = "WriteJobDemo-2";
	final String threadname3 = "WriteJobDemo-3";
	final String threadname4 = "WriteJobDemo-4";
	final String threadnameRead1 = "ReadJobDemo-1";
	final String threadnameRead2 = "ReadJobDemo-2";
	private Runnable writer1;
	private Runnable writer2;
	private Runnable writer3;
	private Runnable writer4;
	private Runnable reader1;
	private Runnable reader2;

	@Before
	public void setUp() {
		System.out
				.println("///// in BoundedBlockingQueueWithExecutorTest using Executor framework and old school sychronized JobBoundedBlockingQueue methods setUp //////");
		// Create an executor of thread pool size 3
		executor = Executors.newFixedThreadPool(3);
		random = new Random();

		writer1 = () -> {
			System.out.println("Running " + threadname1);
			blockQueue.add(jobWrite);
			System.out
					.println("Thread " + threadname1 + " exiting run method.");
		};
		writer2 = () -> {
			System.out.println("Running " + threadname2);
			blockQueue.add(jobWrite1);
			System.out
					.println("Thread " + threadname2 + " exiting run method.");
		};
		writer3 = () -> {
			System.out.println("Running " + threadname3);
			blockQueue.add(jobWrite2);
			System.out
					.println("Thread " + threadname3 + " exiting run method.");
		};
		writer4 = () -> {
			System.out.println("Running " + threadname4);
			blockQueue.add(jobWrite3);
			System.out
					.println("Thread " + threadname4 + " exiting run method.");
		};
		reader1 = () -> {
			System.out.println("Running " + threadnameRead1);
			blockQueue.remove();
		};
		reader2 = () -> {
			System.out.println("Running " + threadnameRead2);
			blockQueue.remove();
		};

	}

	@Test
	public void threadsWriteTest() {
		System.out.println(Thread.currentThread().getName() + " is started");
		System.out.println("///////  threadsWriteTest TEST //////////");
		Runnable[] runnables = new Runnable [] {writer1, writer2, writer3, writer4};
		
		Consumer<Runnable[]> runnableConsumer = list -> {
			Arrays.asList(list).forEach(runnable->{
				try {
					CompletableFuture.runAsync(runnable, executor).get(1, TimeUnit.SECONDS);
				} catch (InterruptedException | ExecutionException | TimeoutException e1) {
					e1.printStackTrace();
				}
			});};
		WriteJobDemo writeRunnable1 = new WriteJobDemo(threadname1, writer1,
				blockQueue);

		WriteJobDemo writeRunnable2 = new WriteJobDemo(threadname2, writer2,
				blockQueue);
		WriteJobDemo writeRunnable3 = new WriteJobDemo(threadname3, writer3,
				blockQueue);
		WriteJobDemo writeRunnable4 = new WriteJobDemo(threadname4, writer4,
				blockQueue);
		jobs = new JobDemo[] { writeRunnable1, writeRunnable2, writeRunnable3, writeRunnable4 };

		runnableConsumer.accept(runnables);
		
	}

	@Test
	public void threadsReadTest() {
		System.out.println("/////// threadsReadTest  TEST //////////");
		Consumer<Runnable[]> runnableConsumer = list -> {
			Arrays.asList(list).forEach(runnable->{
				try {
					CompletableFuture.runAsync(runnable, executor).get(1, TimeUnit.SECONDS);
				} catch (InterruptedException | ExecutionException | TimeoutException e1) {
					e1.printStackTrace();
				}
			});};

		ReadJobDemo readRunnable1 = new ReadJobDemo(threadnameRead1, reader1,
				blockQueue);
		ReadJobDemo readRunnable2 = new ReadJobDemo(threadnameRead2, reader2,
				blockQueue);
		jobs = new JobDemo[] { readRunnable1, readRunnable2 };
		WriteJobDemo writeRunnable1 = new WriteJobDemo(threadname1, writer1,
				blockQueue);

		WriteJobDemo writeRunnable2 = new WriteJobDemo(threadname2, writer2,
				blockQueue);
		WriteJobDemo writeRunnable3 = new WriteJobDemo(threadname3, writer3,
				blockQueue);
		WriteJobDemo writeRunnable4 = new WriteJobDemo(threadname4, writer4,
				blockQueue);
		jobs = new JobDemo[] { writeRunnable1, writeRunnable2, writeRunnable3,
				writeRunnable4 };
		jobs = new JobDemo[] { readRunnable1, readRunnable2, writeRunnable1,
				writeRunnable2, writeRunnable3, writeRunnable4 };
		runnableConsumer.accept(jobs);	
	}

	@Test
	public void threadsReadWriteTest() {
		System.out.println("/////// threadsReadWriteTest TEST //////////");
		Consumer<Runnable[]> runnableConsumer = list -> {
			Arrays.asList(list).forEach(runnable->{
				try {
					CompletableFuture.runAsync(runnable, executor).get(1, TimeUnit.SECONDS);
				} catch (InterruptedException | ExecutionException | TimeoutException e1) {
					e1.printStackTrace();
				}
			});};

		WriteJobDemo writeRunnable1 = new WriteJobDemo(threadname1, writer1,
				blockQueue);

		WriteJobDemo writeRunnable2 = new WriteJobDemo(threadname2, writer2,
				blockQueue);
		WriteJobDemo writeRunnable3 = new WriteJobDemo(threadname3, writer3,
				blockQueue);
		ReadJobDemo readRunnable1 = new ReadJobDemo(threadnameRead1, blockQueue);
		WriteJobDemo writeRunnable4 = new WriteJobDemo(threadname4, writer4,
				blockQueue);
		ReadJobDemo readRunnable2 = new ReadJobDemo(threadnameRead2, blockQueue);
		jobs = new JobDemo[] { writeRunnable1, writeRunnable2, writeRunnable3,
				readRunnable1, writeRunnable4, readRunnable2 };
		runnableConsumer.accept(jobs);	
	}

	@After
	public void tearDown() {
		System.out.println("///////   tearDown //////////");
		System.out.println("jobs list capacity in tearDown() "
				+ this.blockQueue.size());
		assertTrue(this.blockQueue.size() == 2);
		this.cleanUpJobDemos(jobs);
		assertTrue(this.blockQueue.size() == 2);
	}

	private void cleanUpJobDemos(final JobDemo[] jobs) {

		for (JobDemo jobDemo : jobs) {

			jobDemo.requestStop();
			synchronized (blockQueue) {
				blockQueue.notifyAll();
			}

		}

	}

	protected void executionSubmit(int waitTime, final ExecutorService service,
			final JobDemo[] jobs) {

		this.executor = service;
		this.jobs = jobs;
		this.random = this.createRandom();

		this.executionSubmit(waitTime);
	}

	private void executionSubmit(int waitTime) {

		final List<Future<?>> results = new ArrayList<Future<?>>();
		for (JobDemo jobDemo : jobs) {

			int time = random.nextInt(500);
			waitTime += time;
			System.out.println("Adding: " + jobDemo.getName() + " / " + time);
			results.add(executor.submit(jobDemo));

		}
		try {
			Thread.sleep(waitTime * 10);
			// cleanup waiting threads
			this.cleanUpJobDemos(jobs);
			for (Future<?> future : results) {
				try {
					assertNull(future.get(waitTime, TimeUnit.SECONDS));
				} catch (ExecutionException e) {
					e.printStackTrace();
				} catch (TimeoutException e) {
					e.printStackTrace();
				}

			}
			executor.shutdown();
			executor.awaitTermination(waitTime, TimeUnit.MILLISECONDS);
		} catch (InterruptedException ignored) {
			ignored.printStackTrace();
		}
	}

	protected void execution(int waitTime, final ExecutorService service,
			final JobDemo[] jobs) {

		this.executor = service;
		this.jobs = jobs;
		this.random = this.createRandom();
		this.execution(waitTime);
	}

	private void execution(int waitTime) {
		for (JobDemo jobDemo : jobs) {

			int time = random.nextInt(500);
			waitTime += time;
			System.out.println("Adding: " + jobDemo.getName() + " / " + time);
			executor.execute(jobDemo);

		}
		try {
			Thread.sleep(waitTime);
			executor.shutdown();
			executor.awaitTermination(waitTime, TimeUnit.MILLISECONDS);
		} catch (InterruptedException ignored) {
			ignored.printStackTrace();
		}
	}

	protected Random createRandom() {
		return new Random();
	}
}
