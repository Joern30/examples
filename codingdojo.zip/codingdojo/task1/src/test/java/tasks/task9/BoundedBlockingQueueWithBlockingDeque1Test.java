package tasks.task9;

import static org.junit.Assert.assertTrue;

import java.util.concurrent.BlockingDeque;
import java.util.concurrent.LinkedBlockingDeque;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * BoundedBlockingQueueWithBlockingDeque1Test using thread execution and
 * LinkedBlockingDeque
 * 
 * @author Jörn Scheffler
 *
 */

public class BoundedBlockingQueueWithBlockingDeque1Test {

	private final int capacity = 2;

	private BlockingDeque<Job> blockQueue;
	private Job jobWrite;
	private Job jobWrite1;
	private Job jobWrite2;
	private Job jobWrite3;
	private JobDemoDeque[] jobs;

	@Before
	public void setUp() {
		System.out
				.println("///// in  BoundedBlockingQueueWithBlockingDeque1Test using thread execution and not synchronized LinkedBlockingDeque setUp //////");
		blockQueue = new LinkedBlockingDeque<Job>(capacity);
		jobWrite = new Job('a', 'b');
		jobWrite1 = new Job('b', 'c');
		jobWrite2 = new Job('d', 'd');
		jobWrite3 = new Job('e', 'f');
	}

	@Test
	public void threadsWriteTest() {
		System.out.println(Thread.currentThread().getName() + " is started");
		System.out.println("///////  threadsWriteTest TEST //////////");

		WriteJobDemoBlockingDeque1 writeRunnable1 = new WriteJobDemoBlockingDeque1(
				"WriteJobDemoBlockingDeque1-1", blockQueue, jobWrite, capacity);
		WriteJobDemoBlockingDeque1 writeRunnable2 = new WriteJobDemoBlockingDeque1(
				"WriteJobDemoBlockingDeque1-2", blockQueue, jobWrite1, capacity);
		WriteJobDemoBlockingDeque1 writeRunnable3 = new WriteJobDemoBlockingDeque1(
				"WriteJobDemoBlockingDeque1-3", blockQueue, jobWrite2, capacity);
		WriteJobDemoBlockingDeque1 writeRunnable4 = new WriteJobDemoBlockingDeque1(
				"WriteJobDemoBlockingDeque1-4", blockQueue, jobWrite3, capacity);
		jobs = new JobDemoDeque[] { writeRunnable1, writeRunnable2,
				writeRunnable3, writeRunnable4 };
		execution();

	}

	private void cleanUpJobDemos(final JobDemoDeque[] jobs) {

		for (JobDemoDeque jobDemo : jobs) {

			jobDemo.requestStop();

		}

	}

	@Test
	public void threadsReadTest() {
		System.out.println("/////// threadsReadTest  TEST //////////");
		jobWrite = new Job('a', 'b');
		ReadJobDemoBlockingDeque1 readRunnable1 = new ReadJobDemoBlockingDeque1(
				"ReadJobDemoBlockingDeque1-1", blockQueue);
		readRunnable1.start();
		ReadJobDemoBlockingDeque1 readRunnable2 = new ReadJobDemoBlockingDeque1(
				"ReadJobDemoBlockingDeque1-2", blockQueue);
		readRunnable2.start();
		assertTrue(this.blockQueue.size() == 0);
		jobs = new JobDemoDeque[] { readRunnable1, readRunnable2 };
		WriteJobDemoBlockingDeque1 writeRunnable1 = new WriteJobDemoBlockingDeque1(
				"WriteJobDemoBlockingDeque1-1", blockQueue, jobWrite, capacity);
		WriteJobDemoBlockingDeque1 writeRunnable2 = new WriteJobDemoBlockingDeque1(
				"WriteJobDemoBlockingDeque1-2", blockQueue, jobWrite1, capacity);
		WriteJobDemoBlockingDeque1 writeRunnable3 = new WriteJobDemoBlockingDeque1(
				"WriteJobDemoBlockingDeque1-3", blockQueue, jobWrite, capacity);
		WriteJobDemoBlockingDeque1 writeRunnable4 = new WriteJobDemoBlockingDeque1(
				"WriteJobDemoBlockingDeque1-4", blockQueue, jobWrite1, capacity);
		WriteJobDemoBlockingDeque1 writeRunnable5 = new WriteJobDemoBlockingDeque1(
				"WriteJobDemoBlockingDeque1-5", blockQueue, jobWrite1, capacity);
		jobs = new JobDemoDeque[] { writeRunnable1, writeRunnable2,
				writeRunnable3, writeRunnable4, writeRunnable5 };
		execution();
	}

	private void execution() {
		for (JobDemoDeque jobDemo : jobs) {

			jobDemo.start();

		}
		try {
			Thread.sleep(15000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void threadsReadWriteTest() {
		System.out.println("/////// threadsReadWriteTest  TEST //////////");
		jobWrite = new Job('a', 'b');
		WriteJobDemoBlockingDeque1 writeRunnable1 = new WriteJobDemoBlockingDeque1(
				"WriteJobDemoBlockingDeque1-1", blockQueue, jobWrite, capacity);
		WriteJobDemoBlockingDeque1 writeRunnable2 = new WriteJobDemoBlockingDeque1(
				"WriteJobDemoBlockingDeque1-2", blockQueue, jobWrite1, capacity);
		WriteJobDemoBlockingDeque1 writeRunnable3 = new WriteJobDemoBlockingDeque1(
				"WriteJobDemoBlockingDeque1-3", blockQueue, jobWrite2, capacity);
		ReadJobDemoBlockingDeque1 readRunnable1 = new ReadJobDemoBlockingDeque1(
				"ReadJobDemoBlockingDeque1-1", blockQueue);
		WriteJobDemoBlockingDeque1 writeRunnable4 = new WriteJobDemoBlockingDeque1(
				"WriteJobDemoBlockingDeque1-4", blockQueue, jobWrite3, capacity);
		ReadJobDemoBlockingDeque1 readRunnable2 = new ReadJobDemoBlockingDeque1(
				"ReadJobDemoBlockingDeque1-2", blockQueue);
		WriteJobDemoBlockingDeque1 writeRunnable5 = new WriteJobDemoBlockingDeque1(
				"WriteJobDemoBlockingDeque1-4", blockQueue, jobWrite3, capacity);
		jobs = new JobDemoDeque[] { writeRunnable1, writeRunnable2,
				writeRunnable3, readRunnable1, writeRunnable4, writeRunnable5,
				readRunnable2 };
		execution();
	}

	@After
	public void tearDown() {
		System.out.println("///////   tearDown //////////");
		System.out.println("jobs list capacity in tearDown() "
				+ this.blockQueue.size());
		assertTrue(this.blockQueue.size() == capacity);
		this.cleanUpJobDemos(jobs);
		assertTrue(this.blockQueue.size() == capacity);
	}
}
