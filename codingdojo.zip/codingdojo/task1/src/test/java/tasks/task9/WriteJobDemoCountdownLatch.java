package tasks.task9;

import java.util.concurrent.CountDownLatch;

class WriteJobDemoCountdownLatch extends WriteJobDemo implements Runnable {
	private Thread t;
	private String threadName;
	private CountDownLatch latch;

	public WriteJobDemoCountdownLatch(String name,
			BoundedBlockingQueue<Job> blockQueue, Job jobWrite,
			CountDownLatch latch) {
		super(name, blockQueue, jobWrite);
		threadName = name;
		this.latch = latch;
	}

	public void run() {
		super.run();
		this.latch.countDown();
	}

	public void start() {
		System.out.println("Starting " + threadName);
		if (t == null) {
			t = new Thread(this, threadName);
			t.start();
		}
	}

}
