package tasks.task9;

import java.util.concurrent.BlockingDeque;

class ReadJobDemoBlockingDeque1 extends JobDemoDeque implements Runnable {
	private Thread t;
	private String threadName;

	public ReadJobDemoBlockingDeque1(final String name,
			final BlockingDeque<Job> blockQueue) {
		super(blockQueue);
		threadName = name;
		System.out.println("Creating " + threadName);
	}

	public void run() {
		System.out.println("Running " + threadName);

		while (this.blockingQueue.pollLast() == null && !this.stop) {

			try {
				Thread.sleep(500);
				System.out.println(Thread.currentThread().getName()
						+ " waiting in remove");
			} catch (InterruptedException e) {
				System.out.println(Thread.currentThread().getName() +" interrupted");
				this.stop = true;
			}
		}
		if (!this.stop) {
			System.out.println(Thread.currentThread().getName()
					+ " removes a Job from BlockingDeque");
		}
	}

	public void start() {
		System.out.println("Starting " + threadName);
		if (t == null) {
			t = new Thread(this, threadName);
			t.start();
		}
	}

	public JobDemoDeque take() {
		System.out.println("Running " + threadName);

		while (this.blockingQueue.pollLast() == null && !this.stop) {

			try {
				Thread.sleep(500);
				System.out.println(Thread.currentThread().getName()
						+ " waiting in remove");
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		if (!this.stop) {
			System.out.println(Thread.currentThread().getName()
					+ " removes a Job from BlockingDeque");
		}
		return this;

	}
}
