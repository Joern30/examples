package tasks.task9;

public class WriteJobDemo extends JobDemo implements Runnable {
	private Thread t;
	private String threadName;
	private Job jobWrite;

	public WriteJobDemo(String name, BoundedBlockingQueue<Job> blockQueue,
			Job jobWrite) {
		super(blockQueue);
		threadName = name;
		System.out.println("Creating " + threadName);
		this.jobWrite = jobWrite;
	}

	public WriteJobDemo(String name, Runnable run,
			BoundedBlockingQueue<Job> blockQueue) {
		super(blockQueue);
		threadName = name;
		this.r = run;
		System.out.println("Creating " + threadName + "with Runnable");
	}

	public void run() {
		if (this.r == null) {
			System.out.println("Running " + threadName);
			this.blockingQueue.add(this.jobWrite);
			System.out.println("Thread " + threadName + " exiting run method.");
		} else {
			this.r.run();
		}
	}

	public void start() {
		System.out.println("Starting " + threadName);
		if (t == null) {
			t = new Thread(this, threadName);
			t.start();
		}
	}

}
