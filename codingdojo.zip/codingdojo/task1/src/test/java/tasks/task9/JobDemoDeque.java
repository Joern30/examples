package tasks.task9;

import java.util.concurrent.BlockingDeque;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public abstract class JobDemoDeque extends Thread {

	protected volatile boolean stop = false;
	protected volatile boolean wroteQueue = false;
	protected volatile boolean removedQueue = false;
	protected BlockingDeque<Job> blockingQueue;
	protected final static Lock lock = new ReentrantLock();
	protected final static Condition notFull = lock.newCondition();
	protected final static Condition notEmpty = lock.newCondition();

	public JobDemoDeque() {
	}

	public JobDemoDeque(final BlockingDeque<Job> blockQueue) {
		this.blockingQueue = blockQueue;
	}

	public void requestStop() {
		this.stop = true;

	}

	protected void printReleaseMessage() {
		if (this.stop) {
			System.out.println(Thread.currentThread().getName()
					+ " released from wait()");
		}
	}

}
