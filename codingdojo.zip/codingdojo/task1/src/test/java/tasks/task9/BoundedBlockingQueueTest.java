package tasks.task9;

import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 *  BoundedBlockingQueueTest using thread execution and old school sychronized JobBoundedBlockingQueue methods
 *  
 * @author Jörn Scheffler
 *
 */

public class BoundedBlockingQueueTest {

	private final int capacity = 2;

	private BoundedBlockingQueue<Job> blockQueue;
	private Job jobWrite;
	private Job jobWrite1;
	private Job jobWrite2;
	private Job jobWrite3;
	private JobDemo[] jobs;

	@Before
	public void setUp() {
		System.out.println("///// in  BoundedBlockingQueueTest using thread execution and old school sychronized JobBoundedBlockingQueue methods setUp //////");
		blockQueue = new JobBoundedBlockingQueue(capacity);
		jobWrite = new Job('a', 'b');
		jobWrite1 = new Job('b', 'c');
		jobWrite2 = new Job('d', 'd');
		jobWrite3 = new Job('e', 'f');
	}

	@Test
	public void threadsWriteTest() {
		System.out.println(Thread.currentThread().getName() + " is started");
		System.out.println("///////  threadsWriteTest TEST //////////");

		WriteJobDemo writeRunnable1 = new WriteJobDemo("WriteJobDemo-1",
				blockQueue, jobWrite);
		WriteJobDemo writeRunnable2 = new WriteJobDemo("WriteJobDemo-2",
				blockQueue, jobWrite1);
		WriteJobDemo writeRunnable3 = new WriteJobDemo("WriteJobDemo-3",
				blockQueue, jobWrite2);
		WriteJobDemo writeRunnable4 = new WriteJobDemo("WriteJobDemo-4",
				blockQueue, jobWrite3);
		jobs = new JobDemo[] { writeRunnable1, writeRunnable2, writeRunnable3,
				writeRunnable4 };
		execution();

	}

	private void cleanUpJobDemos(final JobDemo[] jobs) {

		for (JobDemo jobDemo : jobs) {

			jobDemo.requestStop();
			synchronized (blockQueue) {
				blockQueue.notifyAll();
			}

		}

	}

	@Test
	public void threadsReadTest() {
		System.out.println("/////// threadsReadTest  TEST //////////");
		jobWrite = new Job('a', 'b');
		ReadJobDemo readRunnable1 = new ReadJobDemo("ReadJobDemo-1", blockQueue);
		readRunnable1.start();
		ReadJobDemo readRunnable2 = new ReadJobDemo("ReadJobDemo-2", blockQueue);
		readRunnable2.start();
		assertTrue(((JobBoundedBlockingQueue) this.blockQueue).size() == 0);
		jobs = new JobDemo[] { readRunnable1, readRunnable2 };
		WriteJobDemo writeRunnable1 = new WriteJobDemo("WriteJobDemo-1",
				blockQueue, jobWrite);
		WriteJobDemo writeRunnable2 = new WriteJobDemo("WriteJobDemo-2",
				blockQueue, jobWrite1);
		WriteJobDemo writeRunnable3 = new WriteJobDemo("WriteJobDemo-3",
				blockQueue, jobWrite);
		WriteJobDemo writeRunnable4 = new WriteJobDemo("WriteJobDemo-4",
				blockQueue, jobWrite1);
		jobs = new JobDemo[] { writeRunnable1, writeRunnable2, writeRunnable3,
				writeRunnable4 };
		execution();
	}

	private void execution() {
		for (JobDemo jobDemo : jobs) {

			jobDemo.start();

		}
		try {
			Thread.sleep(5);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void threadsReadWriteTest() {
		System.out.println("/////// threadsReadWriteTest  TEST //////////");
		jobWrite = new Job('a', 'b');
		WriteJobDemo writeRunnable1 = new WriteJobDemo("WriteJobDemo-1",
				blockQueue, jobWrite);
		WriteJobDemo writeRunnable2 = new WriteJobDemo("WriteJobDemo-2",
				blockQueue, jobWrite1);
		WriteJobDemo writeRunnable3 = new WriteJobDemo("WriteJobDemo-3",
				blockQueue, jobWrite2);
		ReadJobDemo readRunnable1 = new ReadJobDemo("ReadJobDemo-1", blockQueue);
		WriteJobDemo writeRunnable4 = new WriteJobDemo("WriteJobDemo-4",
				blockQueue, jobWrite3);
		ReadJobDemo readRunnable2 = new ReadJobDemo("ReadJobDemo-2", blockQueue);
		jobs = new JobDemo[] { writeRunnable1, writeRunnable2, writeRunnable3,
				readRunnable1, writeRunnable4, readRunnable2 };
		execution();
	}

	@After
	public void tearDown() {
		System.out.println("///////   tearDown //////////");
		System.out.println("jobs list capacity in tearDown() "
				+ this.blockQueue.size());
		assertTrue(this.blockQueue.size() == 2);
		this.cleanUpJobDemos(jobs);
		assertTrue(this.blockQueue.size() == 2);
	}
}
