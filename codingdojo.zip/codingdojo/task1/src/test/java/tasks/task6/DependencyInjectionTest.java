package tasks.task6;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
 
@Component
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
    "classpath:injection-application-context.xml"})
public class DependencyInjectionTest {
 
	@Autowired 
 	private ServiceA service1;
	@Autowired 
 	private ServiceB service2;
    
	public DependencyInjectionTest() {
		}
	@Test
	public void runComponents () {
		
		assertNotNull(service1); 
		assertTrue(service1.getServiceName().contains(service2.callMe()));
		System.out.println("It is ServiceA calling ServicB.callMe() " + service1.getServiceName());
	}

}




 
