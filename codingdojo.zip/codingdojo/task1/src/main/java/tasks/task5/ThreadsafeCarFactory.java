package tasks.task5;

/**
 * Threadsafe  Version classic
 *
 */

public class ThreadsafeCarFactory extends Factory {
	private static volatile ThreadsafeCarFactory uniqueInstance;
	
	// cars produced
	private static int counter = 0;

	private ThreadsafeCarFactory() {
	}

	public static ThreadsafeCarFactory getUniqueInstance() {
		if (uniqueInstance == null) {
			synchronized (ThreadsafeCarFactory.class) {
				// Double check
				if (uniqueInstance == null) {
					uniqueInstance = new ThreadsafeCarFactory();
					System.out
							.println("Creating a new ThreadsafeCarFactory instance");
				}
			}
		}

		return uniqueInstance;
	}

	public CarType createCars(String selection) {
		if (selection.equalsIgnoreCase("limousine")) {
			return new Limousine();
		} else if (selection.equalsIgnoreCase("miniVan")) {
			return new MiniVan();
		}
		throw new IllegalArgumentException("Selection doesnot exist");
	}
	
	public int counter() {
        counter++;
        System.out.println("DoubleCheckLock.counter()");
        return counter;
}
}

