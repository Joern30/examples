package tasks.task5;

public abstract class Factory {
	public abstract CarType createCars(String selection);
	public abstract int counter() throws Exception;
}