package tasks.task5;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * Threadsafe  Version 1
 *
 */

public class ThreadsafeCarFactory1 extends Factory {
	public  static volatile ThreadsafeCarFactory1 uniqueInstance = new ThreadsafeCarFactory1();
	
	// cars produced
	private AtomicInteger counter = new AtomicInteger(0);

	private ThreadsafeCarFactory1() {
	}

	public CarType createCars(String selection) {
		if (selection.equalsIgnoreCase("limousine")) {
			return new Limousine();
		} else if (selection.equalsIgnoreCase("miniVan")) {
			return new MiniVan();
		}
		throw new IllegalArgumentException("Selection doesnot exist");
	}
	
	public int counter() {
        return counter.incrementAndGet();
}
}

