package tasks.task5;

public interface CarType {
	String print();
}