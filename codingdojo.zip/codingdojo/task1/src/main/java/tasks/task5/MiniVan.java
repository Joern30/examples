package tasks.task5;

public class MiniVan implements CarType {
	@Override
	public String print() {
		System.out.println("Mini Van Created");
		return "miniVan";
	}
}