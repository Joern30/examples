package tasks.task5;

public class Limousine implements CarType {
	@Override
	public String print() {
		System.out.println("Limousine Created");
		return "limousine";
	}
}