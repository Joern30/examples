package tasks.task5;

/**
 * Singlethreaded Version
 *
 */

public class CarFactory extends Factory {
	private static CarFactory uniqueInstance;

	private CarFactory() {
	}

	public static CarFactory getUniqueInstance() {
		if (uniqueInstance == null) {
			uniqueInstance = new CarFactory();
			System.out.println("Creating a new CarFactory instance");
		}
		return uniqueInstance;

	}

	@Override
	public CarType createCars(String selection) {
		if (selection.equalsIgnoreCase("limousine")) {
			return new Limousine();
		} else if (selection.equalsIgnoreCase("miniVan")) {
			return new MiniVan();
		}
		throw new IllegalArgumentException("Selection doesnot exist");
	}

	@Override
	public int counter() throws Exception {
		throw new Exception("not implemented");
	}
}