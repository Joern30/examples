package tasks.task1;

import java.util.Comparator;

public class Student implements Comparable<Student> {

	private int id;
	private String name;

	public Student(final int id, final String name) {
		this.id = id;
		this.name = name;

	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int compareTo(Student compareStudent) {
		final int result = this.name
				.compareToIgnoreCase(((Student) compareStudent).getName());

		return result;
	}

	public static Comparator<Student> StudenttNameComparator = new Comparator<Student>() {

		public int compare(Student student1, Student student2) {

			String studentName1 = student1.getName().toUpperCase();
			String studentName2 = student2.getName().toUpperCase();

			// descending order
			return studentName2.compareTo(studentName1);
		}

	};
}
