package tasks.task9;

import java.util.Deque;
import java.util.LinkedList;
import java.util.concurrent.Semaphore;
import java.util.concurrent.locks.Lock;

public class BlockingQueueSemaphore<E> implements
		BoundedBlockingQueueSemaphore<E> {

	private final Deque<E> queue = new LinkedList<E>();
	private volatile boolean stopFlag;
	private final Semaphore write;
	private final Semaphore read;

	public BlockingQueueSemaphore(int capacity) {
		if (capacity <= 0)
			throw new IllegalArgumentException(
					"The capacity of the queue must be > 0.");
		write = new Semaphore(capacity);
		read = new Semaphore(0);

	}

	public void add(E element) {
		try {
			System.out.println(Thread.currentThread().getName()
					+ " write.acquire()");
			write.acquire();

			if (!this.stopFlag) {
				// bottom
				queue.addLast(element);
				System.out.println(element + " added by "
						+ Thread.currentThread().getName());

				System.out.println("jobs list capacity " + queue.size());

			}
			this.printReleaseMessage();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} finally {
			read.release();
		}
	}

	public E remove() {
		E element = null;
		try {
			System.out.println(Thread.currentThread().getName()
					+ " read.acquire()");
			read.acquire();
			if (!this.stopFlag) {
				// head
				element = queue.removeFirst();
				System.out.println(element + " removed by "
						+ Thread.currentThread().getName());

				System.out.println("jobs list capacity " + queue.size());
			}
			printReleaseMessage();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} finally {
			write.release();
		}
		return element;
	}

	public int size() {

		return this.queue.size();

	}

	@Override
	public void setReleaseWaitingThreads(boolean stopFlag) {
		this.stopFlag = stopFlag;

	}

	private void printReleaseMessage() {
		if (this.stopFlag) {
			System.out.println(Thread.currentThread().getName()
					+ " released from wait()");
		}
	}

	@Override
	public Lock getLock() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Semaphore getReadSemaphore() {
		return this.read;
	}

	@Override
	public Semaphore getWriteSemaphore() {
		return this.write;
	}

}