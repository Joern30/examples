package tasks.task9;

public class JobBoundedBlockingQueueConcurrent extends BlockingQueue<Job> {

	public JobBoundedBlockingQueueConcurrent(int capacity) {
		super(capacity);
	}

}
