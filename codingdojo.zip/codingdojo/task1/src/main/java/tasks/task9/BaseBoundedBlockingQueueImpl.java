package tasks.task9;

import java.util.Deque;
import java.util.LinkedList;
import java.util.NoSuchElementException;
import java.util.concurrent.atomic.AtomicInteger;

public class BaseBoundedBlockingQueueImpl<E> implements BoundedBlockingQueue<E> {
	private final Deque<E> queue = new LinkedList<E>();
	private final int capacity;
	private boolean stopFlag;
	private final AtomicInteger count = new AtomicInteger(0);

	public BaseBoundedBlockingQueueImpl(int capacity) {
		if (capacity <= 0)
			throw new IllegalArgumentException(
					"The capacity of the queue must be > 0.");
		this.capacity = capacity;
	}

	public int size() {
		return count.get();
	}

	@Override
	public void setReleaseWaitingThreads(final boolean stopFlag) {
		this.stopFlag = stopFlag;
	}

	public synchronized void add(E e) throws RuntimeException {
		if (e == null)
			throw new NullPointerException("Null element is not allowed.");

		int oldCount = -1;
		// capacity reached
		while ((count.get() == capacity) && !this.stopFlag) {
			try {
				System.out.println(Thread.currentThread().getName()
						+ " waiting in add");
				this.wait();
			} catch (InterruptedException e1) {
				System.out.println(Thread.currentThread().getName()
						+ "InterruptedException caught in add");
			}
		}
		if (!this.stopFlag) {
			// bottom
			queue.addLast(e);
			System.out.println(e + " added by "
					+ Thread.currentThread().getName());

			oldCount = count.getAndIncrement();
			System.out.println("jobs list capacity " + this.size());

			System.out.println("oldCount: " + oldCount
					+ " ,call notifyAll() in add "
					+ Thread.currentThread().getName());
		}

		printReleaseMessage();

		notifyAll();
	}

	public synchronized E remove() throws NoSuchElementException {
		E e = null;

		int oldCount = -1;
		while ((count.get()) == 0 && !this.stopFlag) {
			try {
				System.out.println(Thread.currentThread().getName()
						+ " waiting in remove");
				wait();
			} catch (InterruptedException e1) {
				System.out.println(Thread.currentThread().getName()
						+ "InterruptedException caught in remove");
			}
		}

		if (!this.stopFlag) {
			// head
			e = queue.removeFirst();
			System.out.println(e + " removed by "
					+ Thread.currentThread().getName());

			oldCount = count.getAndDecrement();
			System.out.println("jobs list capacity " + this.size());
			// if (oldCount == this.capacity) {
			System.out.println("oldCount: " + oldCount
					+ " ,call notifyAll() in remove "
					+ Thread.currentThread().getName());
		}
		printReleaseMessage();
		notifyAll(); // notify other waiting threads (could be producers or
						// consumers)
						// }
		return e;
	}

	private void printReleaseMessage() {
		if (this.stopFlag) {
			System.out.println(Thread.currentThread().getName()
					+ " released from wait()");
		}
	}

	/*
	 * Retrieves, but does not remove, the head of this queue, or returns null
	 * if this queue is empty.
	 */
	public E peek() {
		if (count.get() == 0)
			return null;
		synchronized (this) {
			return queue.peek();
		}
	}
}