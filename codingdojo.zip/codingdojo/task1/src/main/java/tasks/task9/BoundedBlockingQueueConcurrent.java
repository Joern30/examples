package tasks.task9;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

interface BoundedBlockingQueueConcurrent<E> extends BoundedBlockingQueue<E> {
	Lock getLock();

	Condition getConditionNotFull();

	Condition getConditionNotEmpty();
}
