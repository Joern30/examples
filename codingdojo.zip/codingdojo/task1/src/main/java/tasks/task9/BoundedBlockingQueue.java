package tasks.task9;

public interface BoundedBlockingQueue<E> {
	void add(E e) throws RuntimeException;

	E remove();

	void setReleaseWaitingThreads(final boolean stopFlag);
	
	int size();
}
