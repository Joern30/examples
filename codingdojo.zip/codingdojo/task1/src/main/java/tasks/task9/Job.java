package tasks.task9;

import java.util.Comparator;

public class Job {

	private char current;
	private char dependent;

	public Job(char a) {
		this.current = a;
	}

	public Job(char a, char b) {
		this.current = a;
		this.dependent = b;
	}

	public char getCurrent() {
		return current;
	}

	public void setCurrent(char current) {
		this.current = current;
	}

	public char getDependent() {
		return dependent;
	}

	public void setDependent(char dependent) {
		this.dependent = dependent;
	}

	@Override
	public String toString() {
		return "Job [current=" + current + ", dependent=" + dependent + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + current;
		result = prime * result + dependent;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Job other = (Job) obj;
		if (current != other.current)
			return false;
		if (dependent != other.dependent)
			return false;
		return true;
	}
	public static Comparator<Job> JobComparator = new Comparator<Job>() {

		public int compare(Job job1, Job job2) {
			
			Character jobName1 = job1.getCurrent();
			Character jobName2 = job2.getCurrent();
            return jobName1.compareTo(jobName2);
		}
	};

}
