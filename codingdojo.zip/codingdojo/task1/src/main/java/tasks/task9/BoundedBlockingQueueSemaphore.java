package tasks.task9;

import java.util.concurrent.Semaphore;
import java.util.concurrent.locks.Lock;

interface BoundedBlockingQueueSemaphore<E> extends BoundedBlockingQueue<E> {
	Lock getLock();

	Semaphore getWriteSemaphore();

	Semaphore getReadSemaphore();
}
