package tasks.task9;

public class JobBoundedBlockingQueue extends
		BaseBoundedBlockingQueueImpl<Job> {

	public JobBoundedBlockingQueue(int capacity) {
		super(capacity);
	}
	
}
