package tasks.task9;

import java.util.Deque;
import java.util.LinkedList;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class BlockingQueue<E> implements BoundedBlockingQueueConcurrent<E> {

	private final Deque<E> queue = new LinkedList<E>();
	private int capacity;
	private boolean stopFlag;
	private Lock lock = new ReentrantLock();
	private Condition notFull = lock.newCondition();
	private Condition notEmpty = lock.newCondition();

	public BlockingQueue(int capacity) {
		if (capacity <= 0)
			throw new IllegalArgumentException(
					"The capacity of the queue must be > 0.");
		this.capacity = capacity;

	}

	public void add(E element) {
		lock.lock();
		try {
			while (queue.size() == capacity && !this.stopFlag) {
				try {
					System.out.println(Thread.currentThread().getName()
							+ " waiting in add");
					notFull.await();

				} catch (InterruptedException e) {
				}
			}

			if (!this.stopFlag) {
				// bottom
				queue.addLast(element);
				System.out.println(element + " added by "
						+ Thread.currentThread().getName());

				System.out.println("jobs list capacity " + queue.size());

				System.out.println("call notEmpty.signal() in add "
						+ Thread.currentThread().getName());
			}
			this.printReleaseMessage();
			notEmpty.signalAll();
		} finally {
			lock.unlock();
		}
	}

	public E remove() {
		E element = null;
		lock.lock();
		try {
			while (queue.isEmpty() && !this.stopFlag) {
				try {
					System.out.println(Thread.currentThread().getName()
							+ " waiting in remove");
					notEmpty.await();
				} catch (InterruptedException e) {
				}
			}

			if (!this.stopFlag) {
				// head
				element = queue.removeFirst();
				System.out.println(element + " removed by "
						+ Thread.currentThread().getName());

				System.out.println("jobs list capacity " + queue.size());
				// if (oldCount == this.capacity) {
				System.out.println("call notFull.signal() in remove "
						+ Thread.currentThread().getName());
			}
			printReleaseMessage();
			notFull.signalAll();
			return element;
		} finally {
			lock.unlock();
		}
	}

	public int size() {

		return this.queue.size();

	}

	@Override
	public void setReleaseWaitingThreads(boolean stopFlag) {
		this.stopFlag = stopFlag;

	}

	private void printReleaseMessage() {
		if (this.stopFlag) {
			System.out.println(Thread.currentThread().getName()
					+ " released from wait()");
		}
	}

	@Override
	public Lock getLock() {
		return this.lock;
	}

	@Override
	public Condition getConditionNotFull() {
		return this.notFull;
	}

	@Override
	public Condition getConditionNotEmpty() {
		return this.notEmpty;
	}

}