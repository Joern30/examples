package tasks.task10.deadlock;

import java.lang.management.ManagementFactory;
import java.lang.management.ThreadInfo;
import java.lang.management.ThreadMXBean;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class DeadlockDetector {

	private final DeadlockHandler deadlockHandler;
	private final long period;
	private final TimeUnit unit;
	private final ThreadMXBean mbean = ManagementFactory.getThreadMXBean();
	private final ScheduledExecutorService scheduler = Executors
			.newScheduledThreadPool(1);
	
	private final ExecutionStop executionStop = new ExecutionStop ();

	final Runnable deadlockCheck = new Runnable() {
		@Override
		public void run() {
			long[] deadlockedThreadIds = DeadlockDetector.this.mbean
					.findDeadlockedThreads();

			if (deadlockedThreadIds != null) {
				ThreadInfo[] threadInfos = DeadlockDetector.this.mbean
						.getThreadInfo(deadlockedThreadIds);

				DeadlockDetector.this.deadlockHandler
						.handleDeadlock(threadInfos);
			}
		}
	};

	public DeadlockDetector(final DeadlockHandler deadlockHandler,
			final long period, final TimeUnit unit) {
		this.deadlockHandler = deadlockHandler;
		this.period = period;
		this.unit = unit;
	}

	public void start() throws InterruptedException {
		this.scheduler.scheduleAtFixedRate(this.deadlockCheck, this.period,
				this.period, this.unit);
	}

	public void stop() throws InterruptedException {
		
		this.executionStop.stopExecution(this.scheduler);
	}
	
	public static void main(String[] args) throws InterruptedException {
		DeadlockDetector deadlockDetector = new DeadlockDetector(new DeadlockConsoleHandler(), 5, TimeUnit.SECONDS);
		deadlockDetector.start();

		final Object lock1 = new Object();
		final Object lock2 = new Object();

		Thread thread1 = new Thread(new Runnable() {
		  @Override
		  public void run() {
		    synchronized (lock1) {
		      System.out.println("Thread1 acquired lock1");
		      try {
		        TimeUnit.MILLISECONDS.sleep(500);
		      } catch (InterruptedException ignore) {
		      }
		      synchronized (lock2) {
		        System.out.println("Thread1 acquired lock2");
		      }
		    }
		  }

		});
		thread1.start();

		Thread thread2 = new Thread(new Runnable() {
		  @Override
		  public void run() {
		    synchronized (lock2) {
		      System.out.println("Thread2 acquired lock2");
		      synchronized (lock1) {
		        System.out.println("Thread2 acquired lock1");
		      }
		    }
		  }
		});
		thread2.start();
		
		deadlockDetector.stop();
		

	}
}
