package tasks.task10.deadlock;

import java.util.concurrent.ScheduledExecutorService;

public final class ExecutionStop {

	public void stopExecution (final ScheduledExecutorService scheduler) throws InterruptedException {
		Thread.sleep(15000);
		scheduler.shutdown();
		
		System.exit(1);
	}

}
