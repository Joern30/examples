package tasks.task7;

public class RotN {

	private int displacement;

	public RotN(final int displacement) {

		this.displacement = displacement;
	}

	public char rotN(char letter, int displacement) {
		if (!Character.isLetter(letter)) {
			// invalid character, leave it alone
			return letter;
		}

		letter = Character.toLowerCase(letter);
		int letter_int = (int) letter;
		// mapping letters to values.
		int a = 'a';
		int start = ((letter_int - a) + displacement) % 26;
		// map back to the original ASCII character range
		letter = (char) (a + start);
		letter_int = letter;
		return Character.toUpperCase(letter);
	}

	public String rotN(String text) {
		StringBuffer buffer = new StringBuffer();
		for (char next : text.toCharArray()) {
			buffer.append(rotN(next, displacement));
		}
		return buffer.toString();
	}
}
