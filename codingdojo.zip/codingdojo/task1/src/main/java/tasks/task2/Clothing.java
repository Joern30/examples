package tasks.task2;

public class Clothing extends Product {

	private int size;

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		this.material = material;
	}

	private String material;

	public Clothing(int size, String material, final String name,
			final String desc, final double price) {
		super(name, desc, price);
		this.size = size;
		this.material = material;
	}

	@Override
	public String toString() {
		return name + " _ " + description + " _ " + this.material + " _ "
				+ this.size + " _ " + price + " EUR";
	}

}
