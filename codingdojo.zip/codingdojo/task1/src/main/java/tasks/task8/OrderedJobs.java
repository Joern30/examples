package tasks.task8;

interface OrderedJobs {
	void register(char job);

	void register(char job, char dependentJob);

	String sort();
}
