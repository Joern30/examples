package tasks.task8;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

public class OrderedJobsRegistry implements OrderedJobs {

	private List<Job> registeredJobs = new ArrayList<Job>();

	public OrderedJobsRegistry() {
	}

	@Override
	public void register(char job) {
		registeredJobs.add(new Job(job));
	}

	@Override
	public void register(char job, char dependentJob) {
		registeredJobs.add(new Job(job, dependentJob));

	}

	@Override
	public String sort() {
//		For example, registering the following jobs:
//			register('c');
//			register('b', 'a');
//			register('c', 'b');
//			sort() should return this result: "abc". J.S. -> wrong: should be "cba"
//			The same job appeared in multiple registrations just occurs once in the result of sort(). 
//			Jobs with no dependency can occur in any order as long as they are executed before jobs which depend on them. 
//			Circular dependencies between jobs should be reported through an exception (at least in the method sort()).	
			
		List<Job> listWithoutDuplicates = removeDuplicates();
		Collections.sort(listWithoutDuplicates, Job.JobComparator);
		int i = 0;
		System.out.println("listWithoutDuplicates");
		for (Job job : listWithoutDuplicates) {
			System.out.println("Jobs " + ++i + " : " + job.toString());
		}

		SortedSet<Character> setSorted = sortList(listWithoutDuplicates);
		System.out.println("Sorted Set");
		i = 0;
		for (Character charIterator : setSorted) {
			System.out.println("Jobs " + ++i + " : " + charIterator);
		}

		i  = -1;
		char [] returnArray = new char[setSorted.size()] ;
		for (Character charIterator : setSorted) {
			returnArray[++i] = charIterator;
		}
		return new String(returnArray);
	}

	private SortedSet<Character> sortList(List<Job> listWithoutDuplicates) {
		SortedSet<Character> setSorted = new TreeSet<Character>();
		Job circularJob = null;
		for (Job currentJob : listWithoutDuplicates) {
			
			if (currentJob != null) {
				System.out.println("Current Job " + currentJob.toString());
				circularJob = new Job(currentJob.getDependent(),
						currentJob.getCurrent());
				try {
					if (listWithoutDuplicates.contains(circularJob)) {

						throw new Exception(circularJob.toString());
					}
				} catch (Exception e) {
					System.out.println("Exception caught. "
							+ circularJob.toString());
				}
				// every job once, no empty dependent
				setSorted.add(currentJob.getCurrent());
				if (currentJob.getDependent() != 0) {
					setSorted.add(currentJob.getDependent());
				}
			}

		}
		return setSorted;
	}

	private List<Job> removeDuplicates() {
		// remove duplicates
		List<Job> listWithoutDuplicates = new ArrayList<Job>(new HashSet<Job>(
				registeredJobs));
		System.out.println("sorted");
		for (Job theJob : listWithoutDuplicates) {
			System.out.println(theJob);

		}
		return listWithoutDuplicates;
	}

	public List<Job> getRegisteredJobs() {
		return registeredJobs;
	}

	public void setRegisteredJobs(List<Job> registeredJobs) {
		this.registeredJobs = registeredJobs;
	}

}
