package tasks.task6;

import org.springframework.stereotype.Component;


@Component

public class ServiceBImpl implements ServiceB{

		public ServiceBImpl() {
	}

	@Override
	public String callMe() {
		return ServiceBImpl.class.getName() + ".get called";
	}

}
