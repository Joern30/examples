package tasks.task6;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class ServiceAImpl implements ServiceA {

	@Autowired
	ServiceB serviceB;
	public ServiceAImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getServiceName() {
		
		return (serviceB.callMe());
	}

}
