package tasks.task6;

public interface ServiceA {
	
	String getServiceName();

}
