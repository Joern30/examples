package tasks.task6;

public class TestBean {

	public TestBean() {
		// TODO Auto-generated constructor stub
	}

}
