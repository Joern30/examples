package tasks.task6;

public interface ServiceB {
	
	String callMe();

}
